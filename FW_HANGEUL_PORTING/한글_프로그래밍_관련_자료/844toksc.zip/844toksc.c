/*
 *		File 844toksc.c
 *		Font Converter (johab844-1 BDF to ksc5601.1987-0 BDF)
 *		'2002.1.13
 *
 */


#ifdef __WIN32__
#include <conio.h>
#endif

#ifdef __BORLANDC__
#pragma warn -8004
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "libboree.h"

#define MAXLEN	100


//-----------------------------------------------------------------------------
FILE *fp;

byte CharBuff[320];
int ByteCountPerChar, ByteCountX, NibbleCount;
int Size, Width, Height, CharCount;
int DWidth, SWidth;

void (*WriteChar)(int Encoding, bool isFillCode);


//-----------------------------------------------------------------------------
byte HexStringToByte(char *s, int pos);
void CompleteKS_N(int Index);
void ReadChar1(void);
void ReadChar2(void);
void WriteChar1(int Encoding, bool isFillCode);
void WriteChar2(int Encoding, bool isFillCode);
void WriteHeader(void);


//-----------------------------------------------------------------------------
byte HexStringToByte(char *s, int pos)
{
	byte high, low, h, l;

	if (s[pos] >= 'A') high = 'A', h = 0x0A;
	else high = '0', h = 0x00;

	if (s[pos + 1] >= 'A') low = 'A', l = 0x0A;
	else low = '0', l = 0x00;
	
	return (byte)((((s[pos] - high) + h) << 4) + ((s[pos + 1] - low) + l));
}
//-----------------------------------------------------------------------------
void CompleteKS_N(int Index)
{
    int F1, F2, F3, F1B, F2B, F3B;
    bool flag;

    _Hangul.HanByte.Byte0 = (byte)(_JohabHangulTable[Index] >> 8);
    _Hangul.HanByte.Byte1 = (byte)(_JohabHangulTable[Index]);

    F1 = _CodeTable[0][_Hangul.HanCode.F1];
    F2 = _CodeTable[1][_Hangul.HanCode.F2];
    F3 = _CodeTable[2][_Hangul.HanCode.F3];

	F3B = _F3B[F2];
	F2B = _F2B[F1 * 2 + (F3 != 0)];
	F1B = _F1B[F2 * 2 + (F3 != 0)];

	flag = true;
	if (F1) {
		_complete(true, CharBuff, _HanFontN.F1[F1B][F1], ByteCountPerChar / 2);
		flag = false;
	}
	if (F2) {
		_complete(flag, CharBuff, _HanFontN.F2[F2B][F2], ByteCountPerChar / 2);
		flag = false;
	}
	if (F3) {
		_complete(flag, CharBuff, _HanFontN.F3[F3B][F3], ByteCountPerChar / 2);
		flag = false;
	}
}
//-----------------------------------------------------------------------------
void ReadChar1(void)
{
	int Index, i, x, y;
	int F1, F2, F3, F1B, F2B, F3B;
	char row[MAXLEN], sum[100] = "";
	
	for (F1B = 0; F1B < 8; F1B++) {
		for (F1 = 0; F1 < (1 + 19); F1++) {
			for (i = 0; i < 6; i++) fgets(row, MAXLEN, fp);
			for (y = 0; y < Height; y++) {
				fgets(row, MAXLEN, fp);
				row[NibbleCount] = '0';
				strncpy(sum + (y * (NibbleCount + 1)), row, NibbleCount + 1);
			}
			for (x = 0, Index = 0; x < ByteCountPerChar; x++, Index++)
				_HanFontN.F1[F1B][F1][Index] = HexStringToByte(sum, x * 2);
			fgets(row, MAXLEN, fp);
		}
	}

	for (F2B = 0; F2B < 4; F2B++) {
		for (F2 = 0; F2 < (1 + 21); F2++) {
			for (i = 0; i < 6; i++) fgets(row, MAXLEN, fp);
			for (y = 0; y < Height; y++) {
				fgets(row, MAXLEN, fp);
				row[NibbleCount] = '0';
				strncpy(sum + (y * (NibbleCount + 1)), row, NibbleCount + 1);
			}
			for (x = 0, Index = 0; x < ByteCountPerChar; x++, Index++)
				_HanFontN.F2[F2B][F2][Index] = HexStringToByte(sum, x * 2);
			fgets(row, MAXLEN, fp);
		}
	}

	for (F3B = 0; F3B < 4; F3B++) {
		for (F3 = 0; F3 < (1 + 27); F3++) {
			for (i = 0; i < 6; i++) fgets(row, MAXLEN, fp);
			for (y = 0; y < Height; y++) {
				fgets(row, MAXLEN, fp);
				row[NibbleCount] = '0';
				strncpy(sum + (y * (NibbleCount + 1)), row, NibbleCount + 1);
			}
			for (x = 0, Index = 0; x < ByteCountPerChar; x++, Index++)
				_HanFontN.F3[F3B][F3][Index] = HexStringToByte(sum, x * 2);
			fgets(row, MAXLEN, fp);
		}
	}
}
//-----------------------------------------------------------------------------
void ReadChar2(void)
{
	int Index, x, y, i;
	int F1, F2, F3, F1B, F2B, F3B;
	char row[MAXLEN], sum[100] = "";
	
	for (F1B = 0; F1B < 8; F1B++) {
		for (F1 = 0; F1 < (1 + 19); F1++) {
			for (i = 0; i < 6; i++) fgets(row, MAXLEN, fp);
			for (y = 0; y < Height; y++) {
				fgets(row, MAXLEN, fp);
				strncpy(sum + (y * NibbleCount), row, NibbleCount);
			}
			for (x = 0, Index = 0; x < ByteCountPerChar; x++, Index++)
				_HanFontN.F1[F1B][F1][Index] = HexStringToByte(sum, x * 2);
			fgets(row, MAXLEN, fp);
		}
	}

	for (F2B = 0; F2B < 4; F2B++) {
		for (F2 = 0; F2 < (1 + 21); F2++) {
			for (i = 0; i < 6; i++) fgets(row, MAXLEN, fp);
			for (y = 0; y < Height; y++) {
				fgets(row, MAXLEN, fp);
				strncpy(sum + (y * NibbleCount), row, NibbleCount);
			}
			for (x = 0, Index = 0; x < ByteCountPerChar; x++, Index++)
				_HanFontN.F2[F2B][F2][Index] = HexStringToByte(sum, x * 2);
			fgets(row, MAXLEN, fp);
		}
	}

	for (F3B = 0; F3B < 4; F3B++) {
		for (F3 = 0; F3 < (1 + 27); F3++) {
			for (i = 0; i < 6; i++) fgets(row, MAXLEN, fp);
			for (y = 0; y < Height; y++) {
				fgets(row, MAXLEN, fp);
				strncpy(sum + (y * NibbleCount), row, NibbleCount);
			}
			for (x = 0, Index = 0; x < ByteCountPerChar; x++, Index++)
				_HanFontN.F3[F3B][F3][Index] = HexStringToByte(sum, x * 2);
			fgets(row, MAXLEN, fp);
		}
	}
}
//-----------------------------------------------------------------------------
void WriteChar1(int Encoding, bool isFillCode)
{
	int x, y, pos;
	
	fprintf(fp, "STARTCHAR char%X\n", Encoding);
	fprintf(fp, "ENCODING %d\n", Encoding);
	fprintf(fp, "SWIDTH %d 0\n", SWidth);
	fprintf(fp, "DWIDTH %d 0\n", DWidth);
	fprintf(fp, "BBX %d %d 0 -2\n", Width, Height);
	fprintf(fp, "BITMAP\n");

	switch (isFillCode) {
	case false:
		for (pos = 0, y = 0; y < Height; y++) {
			for (x = 0; x < ByteCountX - 1; x++, pos++)
				fprintf(fp, "%02X", CharBuff[pos]);
			fprintf(fp, "%X\n", (CharBuff[pos] >> 4)), pos++;
		}
		break;
	case true:
		for (y = 0; y < Height; y++) {
			for (x = 0; x < NibbleCount; x++) fprintf(fp, "0");
			fprintf(fp, "\n");
		}
		break;
	}
	
	fprintf(fp, "ENDCHAR\n");
}
//-----------------------------------------------------------------------------
void WriteChar2(int Encoding, bool isFillCode)
{
	int x, y, pos;
	
	fprintf(fp, "STARTCHAR char%X\n", Encoding);
	fprintf(fp, "ENCODING %d\n", Encoding);
	fprintf(fp, "SWIDTH %d 0\n", SWidth);
	fprintf(fp, "DWIDTH %d 0\n", DWidth);
	fprintf(fp, "BBX %d %d 0 -2\n", Width, Height);
	fprintf(fp, "BITMAP\n");

	switch (isFillCode) {
	case false:
		for (pos = 0, y = 0; y < Height; y++) {
			for (x = 0; x < ByteCountX; x++, pos++)
				fprintf(fp, "%02X", CharBuff[pos]);
			fprintf(fp, "\n");
		}
		break;
	case true:
		for (y = 0; y < Height; y++) {
			for (x = 0; x < NibbleCount; x++) fprintf(fp, "0");
			fprintf(fp, "\n");
		}
		break;
	}
	
	fprintf(fp, "ENDCHAR\n");
}
//-----------------------------------------------------------------------------
void WriteHeader(void)
{
	fprintf(fp, "STARTFONT 2.1\n");
	fprintf(fp, "FONT -Foundry-FamilyName-medium-r-normal--%d-%d-75-75-c-%d-ksc5601.1987-0\n", Size, Size * 10, Width * 10);
	fprintf(fp, "SIZE %d 75 75\n", Size);
	fprintf(fp, "FONTBOUNDINGBOX %d %d 0 -2\n", Width, Height);
	fprintf(fp, "STARTPROPERTIES 3\n");
	fprintf(fp, "DEFAULT_CHAR 9249\n");
	fprintf(fp, "FONT_ASCENT %d\n", Size - 2);
	fprintf(fp, "FONT_DESCENT 2\n");
	fprintf(fp, "ENDPROPERTIES\n");
	fprintf(fp, "CHARS %d\n", 2350 + (25 * 2) + 96);
}
//-----------------------------------------------------------------------------
int main(int argc, char *argv[])
{
	int Index, Encoding, x, y;
	char row[MAXLEN], temp[MAXLEN];
	char johab844file[30], ksc5601file[30];
	
    if (argc != 3) {
        fprintf(stderr, "\njohab844-1 to ksc5601.1987-0 converter 0.11");
        fprintf(stderr, "\nUsage: 844toksc johab844.bdf ksc5601.bdf\n\n");
        exit(EXIT_FAILURE);
    }

    if ((argv[1][0] == '*') || (argv[2][0] == '*')) {
        fprintf(stderr, "\nDon't use wildcards\n");
        exit(EXIT_FAILURE);
    }
	
    strcpy(johab844file, argv[1]);
    strcpy(ksc5601file, argv[2]);
	
    fprintf(stdout, "\nConverting %s to %s\n\n", johab844file, ksc5601file);
	
	fp = fopen(johab844file, "rt");
	if (fp == NULL)  {
        fprintf(stderr, "\nFatal error: BDF font not found\n");
        exit(EXIT_FAILURE);
		return -1;
	}
	
	//-------------------------------------------------------------------------
	// 0. "SIZE", ������ �ȼ� ������ ã��
	while (1) {
		fgets(row, MAXLEN, fp);
		if (strstr(row, "SIZE ") != NULL) {
			sscanf(row, "%s %d\n", temp, &Size);
			break;
		}
	}
	//-------------------------------------------------------------------------
	// 1. "FONTBOUNDINGBOX", ������ ���� ���� ã��
	while (1) {
		fgets(row, MAXLEN, fp);
		if (strstr(row, "FONTBOUNDINGBOX") != NULL) {
			sscanf(row, "%s %d %d\n", temp, &Width, &Height);
			break;
		}
	}
	//-------------------------------------------------------------------------
	// 2. "CHARS", ������ ���� ã��
	while (1) {
		fgets(row, MAXLEN, fp);
		if (strstr(row, "CHARS ") != NULL) {
			sscanf(row, "%s %d\n", temp, &CharCount);
			break;
		}
	}

	//-------------------------------------------------------------------------
	NibbleCount = Width / 4;
	if (Width % 4 != 0) NibbleCount++;

	ByteCountX = NibbleCount / 2;
	if (NibbleCount % 2 != 0) ByteCountX++;

	ByteCountPerChar = ByteCountX * Height;

	DWidth = Width;
	SWidth = DWidth * 72000 / (Size * 75);

	//-------------------------------------------------------------------------
	if (NibbleCount % 2 != 0)
		ReadChar1(), WriteChar = WriteChar1;
	else
		ReadChar2(), WriteChar = WriteChar2;
	
	fclose(fp);
	
	
	//-------------------------------------------------------------------------
	fp = fopen(ksc5601file, "wt");

	WriteHeader();

	//-------------------------------------------------------------------------
	
	Encoding = 8481 - 1 + (256 * 3);
	WriteChar(Encoding, true), Encoding++;
	for (x = 0; x < 51; x++) {
		memcpy(CharBuff, _HangulJamoN[x], ByteCountPerChar);
		WriteChar(Encoding, false), Encoding++;
	}
	for ( ; x < 94; x++)
		WriteChar(Encoding, true), Encoding++;
	
	WriteChar(Encoding, true), Encoding++;
	
	//-------------------------------------------------------------------------
	Index = 0;
	
	for (y = 0; y < 25; y++) {
		Encoding = 12321 - 1 + (256 * y);
		WriteChar(Encoding, true), Encoding++;
		for (x = 0; x < 94; x++) {
			CompleteKS_N(Index);
			WriteChar(Encoding, false);
			Index++, Encoding++;
		}
		WriteChar(Encoding, true), Encoding++;
	}
	
	fprintf(fp, "ENDFONT\n");
	fclose(fp);
	
	return 0;
}
