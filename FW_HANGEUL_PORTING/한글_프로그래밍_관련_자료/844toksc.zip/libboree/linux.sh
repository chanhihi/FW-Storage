rm -f *.o
gcc -c -Wall *.c
