gcc 844toksc.c libboree/*.o -Ilibboree -Wall -o 844toksc
strip 844toksc
