//bdf2bmf ver.0.03
// bdf(unix) -> bmf(Be)
#include	<Be.h>

struct GLYPH{
	uint16	c;			//unicode
	uint32	p;			//pointer(offset to bitmap-area in bmf)
};

void	setxfertbl();
uint32	unicode(uint cs,uint32 c);
int		xfer(uchar *d,int w,int h,int ox,int oy,char *buf);
void	quit(char *p);

uint16	j2u[2][94][94];
char	f[65536];

main(int ac,char **ag)
{
	if(ac<5)quit("bdf2bmf  ver.0.03\nusage:\tbdf2bmf bmf-file font-family font-style bdf-files");
	int		p=0;
	char	*ifn,*ofn;
	FILE	*ifp,*ofp;
	uint32	ofl;
	int		w,h,ox,oy;
	int		chrs;				//count of bitmap-char
	uint	cs;
	uint32	ltc;
	char	s[256],wb[4096];
	GLYPH	*g=NULL;

	setxfertbl();
	ofn=ag[1];
	cs=0;
	chrs=0;
	for(int i=0;i<65536;i++)f[i]=0;
	for(int i=4;i<ac;i++){
		ifn=ag[i];
//printf("open bdf\n");
		if((ifp=fopen(ifn,"r"))==NULL)quit("cannot open bdf-file");
		while(fgets(s,256,ifp)){
			if(!strncmp(s,"CHARSET_REGISTRY",16)){
				char	f=0;
				char	*sp=s+17;
				while(*sp<=' ')sp++;
				if((!strncmp(sp+1,"JISX0201",8))||(!strncmp(sp+1,"jisx0201",8)))f=1;
				if((!strncmp(sp+1,"JISX0208",8))||(!strncmp(sp+1,"jisx0208",8)))f=2;
				if((!strncmp(sp+1,"JISX0212",8))||(!strncmp(sp+1,"jisx0212",8)))f=3;
				if((!strncmp(sp+1,"JISX0213",8))||(!strncmp(sp+1,"jisx0213",8)))f=4;
				if(f==0)quit("not supported charset");
			}
			if(!strncmp(s,"CHARSET_ENCODING",16)){
				char	*sp=s+17;
				while(*sp<=' ')sp++;
				if(!strncmp(sp,"\"0\"",3))cs=1;
				if(!strncmp(sp,"\"1\"",3))cs=2;
				if(!strncmp(sp,"\"2\"",3))cs=3;
				if(cs==0)quit("not supported encoding");
			}
			if(!strncmp(s,"ENCODING",8)){
				uint32	c,cc;
				sscanf(s+9,"%d",&cc);
				c=unicode(cs,cc);
				if(c==0)printf("undefined code : cs=%d c=%04x\n",cs,cc);
//printf("%04x\n",c);
				else if(f[c]==0){f[c]=i;chrs++;}
			}
			if(!strncmp(s,"PIXEL_SIZE",10)){
				sscanf(s+11,"%d",&p);
			}
			if(!strncmp(s,"ENDFONT",7))break;
		}
		fclose(ifp);
	}
printf("chrs=%d\n",chrs);
	for(ltc=1;ltc<chrs;ltc<<=1);
//printf("ltc=%d\n",ltc);
	if((ofp=fopen(ofn,"wb"))==NULL)quit("cannot open bmf-file");
	uint32	hdl=0x0026+strlen(ag[2])+strlen(ag[3]);
	for(int i=0;i<hdl;i++)wb[i]=0;
	*(uint32*)(wb+0x00)=B_HOST_TO_BENDIAN_INT32(0x7c42653b);
	*(uint32*)(wb+0x04)=B_HOST_TO_BENDIAN_INT32(hdl);
	*(uint16*)(wb+0x08)=B_HOST_TO_BENDIAN_INT16(strlen(ag[2]));
	*(uint16*)(wb+0x0a)=B_HOST_TO_BENDIAN_INT16(strlen(ag[3]));
	*(uint16*)(wb+0x16)=B_HOST_TO_BENDIAN_INT16(ltc-1);
	*(uint16*)(wb+0x18)=B_HOST_TO_BENDIAN_INT16(p);
	*(uint16*)(wb+0x1a)=B_HOST_TO_BENDIAN_INT16(0x300);
	strcpy(wb+0x0024,ag[2]);
	strcpy(wb+0x0025+strlen(ag[2]),ag[3]);
	fwrite(wb,1,hdl,ofp);
	fseek(ofp,ltc*8,1);
	ofl=hdl+ltc*8;
printf("top of bitmap : %08x\n",ofl);
	g=new GLYPH[chrs+1];
	g[0].p=ofl;
	chrs=0;
	for(int i=4;i<ac;i++){
		ifn=ag[i];
		if((ifp=fopen(ifn,"r"))==NULL)quit("cannot open bdf-file");
		while(fgets(s,256,ifp)){
			if(!strncmp(s,"CHARSET_REGISTRY",16)){
				char	f=0;
				char	*sp=s+17;
				while(*sp<=' ')sp++;
				if((!strncmp(sp+1,"JISX0201",8))||(!strncmp(sp+1,"jisx0201",8)))f=1;
				if((!strncmp(sp+1,"JISX0208",8))||(!strncmp(sp+1,"jisx0208",8)))f=2;
				if((!strncmp(sp+1,"JISX0212",8))||(!strncmp(sp+1,"jisx0212",8)))f=3;
				if((!strncmp(sp+1,"JISX0213",8))||(!strncmp(sp+1,"jisx0213",8)))f=4;
				if(f==0)quit("not supported charset");
			}
			if(!strncmp(s,"CHARSET_ENCODING",16)){
				char	*sp=s+17;
				while(*sp<=' ')sp++;
				if(!strncmp(sp,"\"0\"",3))cs=1;
				if(!strncmp(sp,"\"1\"",3))cs=2;
				if(!strncmp(sp,"\"2\"",3))cs=3;
				if(cs==0)quit("not supported encoding");
			}
			if(!strncmp(s,"FONTBOUNDINGBOX",15)){
				int	fbbx,fbby,xoff,yoff;
				sscanf(s+16,"%d %d %d %d",&fbbx,&fbby,&xoff,&yoff);
			}
			if(!strncmp(s,"ENCODING",8)){
				uint32	c,cc;
				sscanf(s+9,"%d",&cc);
//printf("jiscode=%04x\n",cc);
				c=unicode(cs,cc);
//printf("unicode=%04x\n",c);
				if(f[c]==i){	//xfer
//printf("xfer\n");
					while(fgets(s,256,ifp)){
						int	bbw,bbh,bbxoff,bbyoff;
						if(!strncmp(s,"BBX",3)){
							sscanf(s+4,"%d %d %d %d",&bbw,&bbh,&bbxoff,&bbyoff);
						}
						if(!strncmp(s,"BITMAP",6)){
							uchar	*d=new uchar[bbw*bbh];
							for(int iy=0;iy<bbh;iy++){
								fgets(s,256,ifp);
								for(int ix=0;ix<bbw;ix++){
									uchar	hex=s[ix/4]<'A'?s[ix/4]-'0':(s[ix/4]&0xdf)-'A'+10;
									d[bbw*iy+ix]=hex&(8>>(ix%4))?1:0;
								}
							}
							int	len=xfer(d,bbw,bbh,bbxoff,bbyoff,wb);
							delete	d;
//printf("code=%04x  len=%d\n",c,len);
							fwrite(wb,1,len,ofp);
							ofl+=len;
							g[chrs].c=c;
							g[chrs+1].p=g[chrs].p+len;
							chrs++;
						}
						if(!strncmp(s,"ENDCHAR",7))break;
					}
				}
			}
			if(!strncmp(s,"ENDFONT",7))break;
		}
		fclose(ifp);
	}

//printf("loca-table\n");
	uchar	*lt=new uchar[ltc*8];
	for(int i=0;i<ltc;i++){
		*(uint32*)(lt+i*8)=-1;
		*(uint32*)(lt+i*8+4)=0;
	}
	for(int i=0;i<chrs;i++){
		uint16	p=(g[i].c<<3)^(g[i].c>>2);
		p&=ltc-1;
		while(*(uint32*)(lt+p*8)!=-1)p=(p+1)&(ltc-1);
		*(uint32*)(lt+p*8)=B_HOST_TO_BENDIAN_INT32(g[i].p);
		*(uint16*)(lt+p*8+4)=B_HOST_TO_BENDIAN_INT16(g[i].c);
	}
	delete	g;
	fseek(ofp,hdl,0);
	fwrite(lt,8,ltc,ofp);
	delete	lt;
	*(uint32*)wb=B_HOST_TO_BENDIAN_INT32(ofl);
	fseek(ofp,4,0);
	fwrite(wb,4,1,ofp);
	fclose(ofp);

printf("set MIME\n");
	BFile	wf(ofn,B_WRITE_ONLY);
	BAppFileInfo	wfi(&wf);
	wfi.SetType("application/x-vnd.Be-bitmap-font");

	quit("");
}

void setxfertbl()
{
//printf("init tbl\n");
	for(int i=0;i<2;i++)for(int j=0;j<94;j++)for(int k=0;k<94;k++)j2u[i][j][k]=0;
	FILE	*tfp;
	int		chrs;
	char	s[256];
	if((tfp=fopen("jis_uni.txt","r"))==NULL)quit("cannot open < jis_uni.txt >");
	fgets(s,255,tfp);	sscanf(s,"%d",&chrs);
	printf("jis-uni xfer-table : %d chrs\n",chrs);
	while(fgets(s,255,tfp)){
		int		jis,uni;
		sscanf(s,"%x %x",&jis,&uni);
//printf("j2u[%x][%x][%x]=%x\n",jis>>16,((jis>>8)&255)-0x21,(jis&255)-0x21,uni);
		j2u[jis>>16][((jis>>8)&255)-0x21][(jis&255)-0x21]=uni;
	}
	fclose(tfp);
//printf("init tbl ok\n");
}

uint32 unicode(uint cs,uint32 c)
{
	uint32	uc=0;
	if(cs==1){
		if((c>=0x20)&&(c<=0x7e))uc=c;
		if((c>=0xa1)&&(c<=0xdf))uc=c+0xfec0;
		if(c>0xff)uc=j2u[0][((c>>8)&255)-0x21][(c&255)-0x21];
	}
	if(cs==2){
		if((c>=0x20)&&(c<=0x7e))uc=c;
		if((c>=0xa1)&&(c<=0xdf))uc=c+0xfec0;
		if(c>0xff)uc=j2u[0][((c>>8)&255)-0x21][(c&255)-0x21];
	}
	if(cs==3){
		if((c>=0x20)&&(c<=0x7e))uc=c;
		if((c>=0xa1)&&(c<=0xdf))uc=c+0xfec0;
		if(c>0xff)uc=j2u[1][((c>>8)&255)-0x21][(c&255)-0x21];
	}
	return(uc);
}

int xfer(uchar *d,int w,int h,int ox,int oy,char *wb)
{
	wb[0x00]=0x49;	wb[0x01]=0x96;	wb[0x02]=0xb4;	wb[0x03]=0x38;
	wb[0x04]=0x49;	wb[0x05]=0x96;	wb[0x06]=0xb4;	wb[0x07]=0x40;
	wb[0x14]=0x80;	wb[0x15]=0x00;	wb[0x16]=0x00;	wb[0x17]=0x00;
	*(float*)(wb+0x10)=B_HOST_TO_BENDIAN_FLOAT((float)w);
	int16	l,t,r,b;
	l=t=9999;	r=b=-9999;
	for(int y=0;y<h;y++)for(int x=0;x<w;x++){
		if(d[w*y+x]==0)continue;
		if(x<l)l=x;
		if(x>r)r=x;
		if(y<t)t=y;
		if(y>b)b=y;
	}
	int		len=24;
	if(l==9999){	//space
		*(uint16*)(wb+0x08)=0;
		*(uint16*)(wb+0x0a)=0;
		*(uint16*)(wb+0x0c)=-1;
		*(uint16*)(wb+0x0e)=-1;
	}else{			//non-space
		*(uint16*)(wb+0x08)=B_HOST_TO_BENDIAN_INT16(l+ox);
		*(uint16*)(wb+0x0a)=B_HOST_TO_BENDIAN_INT16(t-h-oy);
		*(uint16*)(wb+0x0c)=B_HOST_TO_BENDIAN_INT16(r+ox);
		*(uint16*)(wb+0x0e)=B_HOST_TO_BENDIAN_INT16(b-h-oy);
		for(int iy=t;iy<=b;iy++)for(int ix=l;ix<=r;ix+=2){
			wb[len]=d[w*iy+ix]?0x70:0x00;
			if(ix<r)wb[len]|=d[w*iy+ix+1]?0x07:0x00;
			len++;
		}
	}
	return(len);
}

void quit(char *p)
{
	if(*p)printf("%s\n",p);
	else printf("complete\n");
	exit(0);
}
