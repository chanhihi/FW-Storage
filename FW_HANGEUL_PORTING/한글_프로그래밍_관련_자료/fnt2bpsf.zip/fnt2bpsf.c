/*
 *		File fnt2bpsf.c
 *		Font Converter (DKBB Font to BPSF Converter)
 *		'2002.1.18
 *
 */

#ifdef __WIN32__
#include <conio.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "libboree.h"

//-----------------------------------------------------------------------------
#pragma pack(push, 1)	// ����ü�� 1����Ʈ ������ ����

typedef struct {
	byte psf_header[2];
	byte filemode;
	byte fontheight;
} TBPSF_Header1;

typedef struct {
	byte psf_header[2];
	byte filemode;
	byte charwidth;
	byte charheight;
	dword fontsize;
} TBPSF_Header2;

#pragma pack(pop)

//-----------------------------------------------------------------------------
#define SPC_COUNT		1128	// == 94 x 12 (0xA1A1 ~ 0xACFE)
#define HAN_COUNT		2350	// == 94 x 25 (0xB0A1 ~ 0xC8FE)
#define HANJA_COUNT		4888	// == 94 x 52 (0xCAA1 ~ 0xFDFE)

#define SPC_START		8481	// 1. Ư������ (0xA1A1 ~ 0xACFE)
#define SPC_COUNT_Y		12

#define HAN_START		12321	// 2. �ѱ� (0xB0A1 ~ 0xC8FE)
#define HAN_COUNT_Y		25

#define HANJA_START		18977	// 3. ���� (0xCAA1 ~ 0xFDFE)
#define HANJA_COUNT_Y	52

#define CHAR_COUNT_X	94		// �ι�° ����Ʈ�� ����
#define CHAR_NEXT		256		// ���� �������� �ǳʶٱ� ���� ������


//-----------------------------------------------------------------------------
char FillBitmap[94] = {0x00, }; 

TBPSF_Header2 BPSF_Header2 = {
	{0x36, 0x04},	// magic number
	0x04,	// filemode 4 : big charset, no unicode_data
	0x10,	// charwidth (== 16)
	0x10,	// charheight (== 16)
	8836	// fontsize (== 94 x 94)
};

//-----------------------------------------------------------------------------
int main(int argc, char *argv[])
{
	FILE *fp;
	char dkbbfontfile[30], bpsffile[30];

    if (argc != 3) {
		fprintf(stderr, "\nDKBB Font To BPSF Font 0.1");
		fprintf(stderr, "\nUsage: fnt2bpsf dkbb.fnt kscm-16.bpsf\n\n");
		exit(EXIT_FAILURE);
	}

    if ((argv[1][0] == '*') || (argv[2][0] == '*')) {
        fprintf(stderr, "\nDon't use wildcards\n");
        exit(EXIT_FAILURE);
    }

    strcpy(dkbbfontfile, argv[1]);
    strcpy(bpsffile, argv[2]);

    fprintf(stdout, "\nConverting %s to %s\n\n", dkbbfontfile, bpsffile);

	memcpy(_SpcFont, _LinkedIn_SpcFont, sizeof(_SpcFont));
	memcpy(_HanjaFont, _LinkedIn_HanjaFont, sizeof(_HanjaFont));
	
	if (LoadHanFont(dkbbfontfile) == false) {
		fprintf(stderr, "\nFatal error: DKBB Hangul font not found\n");
		exit(EXIT_FAILURE);
	}
	
	CompleteKS2350();
	
	//-------------------------------------------------------------------------
	fp = fopen(bpsffile, "wb");
	fwrite(&BPSF_Header2, sizeof(TBPSF_Header2), 1, fp);
	fwrite(_SpcFont, sizeof(_SpcFont), 1, fp);
	fwrite(FillBitmap, sizeof(FillBitmap) * 3 * 32, 1, fp);
	fwrite(_HanFontKS, sizeof(_HanFontKS), 1, fp);
	fwrite(FillBitmap, sizeof(FillBitmap) * 1 * 32, 1, fp);
	fwrite(_HanjaFont, sizeof(_HanjaFont), 1, fp);
	fwrite(FillBitmap, sizeof(FillBitmap) * 1 * 32, 1, fp);
	fclose(fp);

	return 0;
}

