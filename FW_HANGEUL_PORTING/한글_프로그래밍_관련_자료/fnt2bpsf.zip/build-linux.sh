gcc fnt2bpsf.c libboree/*.o -Ilibboree -Wall -o fnt2bpsf
strip fnt2bpsf
