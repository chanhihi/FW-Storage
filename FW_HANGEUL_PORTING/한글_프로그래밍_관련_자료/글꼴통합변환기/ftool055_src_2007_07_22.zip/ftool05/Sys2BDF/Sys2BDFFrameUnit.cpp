//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include "Common.h"
#include "SystemEngFont.h"
#include "SystemHanFont.h"
#include "BDF.h"
#include "PreviewFrameUnit.h"

#include "Sys2BDFFrameUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma link "BrowseDr"
#pragma resource "*.dfm"
TSys2BDFFrame *Sys2BDFFrame;
//---------------------------------------------------------------------------
__fastcall TSys2BDFFrame::TSys2BDFFrame(TComponent* Owner)
    : TFrame(Owner)
{
}
//---------------------------------------------------------------------------
void TSys2BDFFrame::InitPreviewFrame()
{
    SysFontList = new TStringList();
    SysFontList->Sorted = true;

    dfsBrowseDirectoryDlg1->Selection = ExtractFilePath(Application->ExeName);
    lbe_SavePath->Text = ExtractFilePath(Application->ExeName);
}
//---------------------------------------------------------------------------
void TSys2BDFFrame::SystemFontToBDF()
{
    int Result, Count = 0;
    String FontName, FontSize, SaveFileName, LoadFileName, s;
    TTextMetric TextMetric1;
    //-----------------------------------------------------------------------
    if (lv_SrcList->Items->Count == 0)
        {ShowMessage2("BDF�� ��ȯ�� �ý��� �۲��� ��Ͽ� �߰��ϼ���!"); return;}

    String Msg = IntToStr(lv_SrcList->Items->Count) + "���� �ý��� �۲��� "
        + cbx_Encoding->Text + " Encoding�� BDF�� ��ȯ�Ͻðڽ��ϱ�?";
    if (ShowYesNoMsgDlg(Msg) == mrNo) return;
    //-----------------------------------------------------------------------
    _IsWorking = true;
    DisableUserInput();
    //-----------------------------------------------------------------------
    for (int i = 0; i < lv_SrcList->Items->Count; i++) {
        FontName = lv_SrcList->Items->Item[i]->Caption;
        FontSize = lv_SrcList->Items->Item[i]->SubItems->Strings[0];

        pb_FontTest->Canvas->Font->Name = FontName;
        pb_FontTest->Canvas->Font->Size = StrToInt(FontSize);
        GetTextMetrics(pb_FontTest->Canvas->Handle, &TextMetric1);

        SaveFileName = lbe_SavePath->Text + FontName + FontSize + "_" + cbx_Encoding->Text + ".bdf";
        LoadFileName = FontName + ", " + FontSize + " Point, " + cbx_Encoding->Text;

        AddCnvtMsg(mm_ProgressMsg, SaveFileName, LoadFileName, i + 1, lv_SrcList->Items->Count);

        if (cbx_Encoding->Text == "iso8859-1")
            Result = SysEngFontToBDF(SaveFileName, _WriteMode[cbx_CRLF->ItemIndex], pb_FontTest->Canvas->Font, &TextMetric1);
        else
            Result = SysHanFontToBDF(SaveFileName, _WriteMode[cbx_CRLF->ItemIndex], pb_FontTest->Canvas->Font, &TextMetric1, cbx_Encoding->Text,
                cbx_IncludeEngFont->Checked,
                cbx_IncludeSpcFont->Checked,
                cbx_IncludeHanFont->Checked,
                cbx_IncludeHanjaFont->Checked);
        if (CurBDFHeader != NULL) mm_ProgressMsg->Lines->Add("XLFD: " + GetXLFD(CurBDFHeader));
        mm_ProgressMsg->Lines->Add("----------------------------------------------------------------------------------------------------");
        if (!Result) {s = "���� ����!\n\n" + SaveFileName; goto Error1;}

        Count++;
        if (!_IsWorking) goto End1;
    }

    s = AddResultMsg(mm_ProgressMsg, cbx_Encoding->Text + "�� .bdf", "�ý��� �۲�", Count);
    ShowMessage(s);
    goto End1;
Error1:
    s = AddErrorMsg(mm_ProgressMsg, s);
    ShowErrorMessage(s);
End1:
    EnableUserInput();
    _IsWorking = false;
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::btn_SelSystemFontClick(TObject *Sender)
{
    if (FontDialog1->Execute()) {
        ChangeFont(FontDialog1->Font);
        PreviewFrame1->ts_SystemFontInfo->Show();        
    }
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::btn_SavePathClick(TObject *Sender)
{
    dfsBrowseDirectoryDlg1->Selection = lbe_SavePath->Text;
    if (dfsBrowseDirectoryDlg1->Execute()) {
        if (dfsBrowseDirectoryDlg1->Selection == "") return;
        lbe_SavePath->Text = dfsBrowseDirectoryDlg1->Selection;
        lbe_SavePath->Text = AddPathDelimiter(lbe_SavePath->Text);
    }
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::btn_AddFontListClick(TObject *Sender)
{
    int StartSize = se_SizeMin->Value;
    int EndSize = se_SizeMax->Value;
    if (StartSize > EndSize) {
        StartSize = se_SizeMax->Value;
        EndSize = se_SizeMin->Value;
    }

    for (int i = StartSize; i <= EndSize; i++) {
        char size[2+1];
        sprintf(size, "%02d", i);
        SysFontList->Add(lb_SelectedSystemFontName->Caption + size);
    }

    lv_SrcList->Items->BeginUpdate();
    lv_SrcList->Items->Clear();
    for (int i = 0; i < SysFontList->Count; i++) {
        String s = SysFontList->Strings[i];
        String FontSize = s.SubString(s.Length() - 1, 2);
        String FontName = s.SubString(1, s.Length() - 2);

        TListItem *ListItem1 = lv_SrcList->Items->Add();
        ListItem1->Caption = FontName;
        ListItem1->SubItems->Add(FontSize);
    }
    lv_SrcList->Items->EndUpdate();
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::se_SizeMinChange(TObject *Sender)
{
    if (!IsNumString(se_SizeMin->Text) || (se_SizeMin->Value < 8))
        {se_SizeMin->Text = "8"; return;}

    PreviewFrame1->ts_SystemFontInfo->Show();
    PreviewFrame1->PreviewSystemFontMinSize(se_SizeMin->Value);
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::se_SizeMaxChange(TObject *Sender)
{
    if (!IsNumString(se_SizeMax->Text) || (se_SizeMax->Value < 8))
        {se_SizeMax->Text = "8"; return;}

    PreviewFrame1->ts_SystemFontInfo->Show();
    PreviewFrame1->PreviewSystemFontMaxSize(se_SizeMax->Value);
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::btn_DeleteFontListClick(TObject *Sender)
{
    lv_SrcList->Items->BeginUpdate();
    while (lv_SrcList->SelCount) lv_SrcList->Items->Delete(lv_SrcList->Selected->Index);
    lv_SrcList->Items->EndUpdate();

    SysFontList->Clear();
    for (int i = 0; i < lv_SrcList->Items->Count; i++) {
        SysFontList->Add(
            lv_SrcList->Items->Item[i]->Caption +
            lv_SrcList->Items->Item[i]->SubItems->Strings[0]
        );
    }
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::bitbtn_ConvertToBDFClick(TObject *Sender)
{
    SystemFontToBDF();
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::cbx_EncodingChange(TObject *Sender)
{
    switch (cbx_Encoding->ItemIndex) {
    case 0: // iso10646-1
        cbx_IncludeEngFont->Enabled = true;
        cbx_IncludeHanFont->Enabled = true;
        cbx_IncludeSpcFont->Enabled = true;
        cbx_IncludeHanjaFont->Enabled = true;
        break;
    case 1: // iso8859-1
        cbx_IncludeEngFont->Enabled = true;
        cbx_IncludeHanFont->Enabled = false;
        cbx_IncludeSpcFont->Enabled = false;
        cbx_IncludeHanjaFont->Enabled = false;

        cbx_IncludeEngFont->Checked = true;
        break;
    case 2: //ksc5601.1987-0
    case 3: //ksc5601.1987-1
        cbx_IncludeEngFont->Enabled = false;
        cbx_IncludeHanFont->Enabled = true;
        cbx_IncludeSpcFont->Enabled = true;
        cbx_IncludeHanjaFont->Enabled = true;

        cbx_IncludeEngFont->Checked = false;
        break;
    }
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::bitbtn_StopConvertingClick(TObject *Sender)
{
    if (ShowYesNoMsgDlg("��ȯ�� �ߴ��Ͻðڽ��ϱ�?") == mrYes) {
        _IsWorking = false;
        ShowErrorMessage("�۾��� �ߴ��Ͽ����ϴ�!");
        mm_ProgressMsg->Lines->Add("\r\n\r\n�������۾��� �ߴ��Ͽ����ϴ�!\r\n\r\n");
        return;
    }
}
//---------------------------------------------------------------------------
void TSys2BDFFrame::DisableUserInput()
{
    lv_SrcList->Enabled = false;
    pn_AddOrDeleteSrcList->Enabled = false;
    pn_SysFontOption->Enabled = false;
    pn_SavePath->Enabled = false;
    bitbtn_ConvertToBDF->Enabled = false;

    spl_SrcList->Enabled = false;
    spl_ProgressMsg->Enabled = false;

    bitbtn_StopConverting->Enabled = true;
}
//---------------------------------------------------------------------------
void TSys2BDFFrame::EnableUserInput()
{
    lv_SrcList->Enabled = true;
    pn_AddOrDeleteSrcList->Enabled = true;
    pn_SysFontOption->Enabled = true;
    pn_SavePath->Enabled = true;
    bitbtn_ConvertToBDF->Enabled = true;

    spl_SrcList->Enabled = true;
    spl_ProgressMsg->Enabled = true;

    bitbtn_StopConverting->Enabled = false;
}
//---------------------------------------------------------------------------
void TSys2BDFFrame::ChangeFont(TFont *AFont)
{
    lb_SelectedSystemFontName->Caption = AFont->Name;

    TTextMetric TextMetric1;
    pb_FontTest->Canvas->Font->Assign(AFont);
    GetTextMetrics(pb_FontTest->Canvas->Handle, &TextMetric1);

    PreviewFrame1->lb_FontInfo->Items->Clear();
    PreviewFrame1->lb_FontInfo->Items->Add("�۲� �̸�: " + AFont->Name);
    if (isFixedPitchFont(&TextMetric1))
        PreviewFrame1->lb_FontInfo->Items->Add("�۲��� ��: ������");
    else
        PreviewFrame1->lb_FontInfo->Items->Add("�۲��� ��: ������");

    PreviewFrame1->PreviewSystemFont(AFont);
    se_SizeMin->Value = FontDialog1->Font->Size;
    se_SizeMax->Value = FontDialog1->Font->Size;
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::mi_DeleteSourceListClick(TObject *Sender)
{
    btn_DeleteFontListClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::mi_SelectSourceListAllClick(TObject *Sender)
{
    lv_SrcList->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::lv_SrcListDblClick(TObject *Sender)
{
    if (lv_SrcList->SelCount != 1) return;

    FontDialog1->Font->Name =  lv_SrcList->Selected->Caption;
    FontDialog1->Font->Size =  StrToInt(lv_SrcList->Selected->SubItems->Strings[0]);
    ChangeFont(FontDialog1->Font);
    PreviewFrame1->ts_SystemFontInfo->Show();
}
//---------------------------------------------------------------------------
void __fastcall TSys2BDFFrame::lv_SrcListKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{
    if (Key == VK_RETURN) lv_SrcListDblClick(Sender);
}
//---------------------------------------------------------------------------
