//---------------------------------------------------------------------------
#include <vcl.h>
#include <ComCtrls.hpp>
#pragma hdrstop

#include "..\hanlib\hanlib.h"
#include "Common.h"
#include "BBX.h"
#include "BDF.h"

#include "SystemHanFont.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//------------------------------------------------------------------------------
bool SysHanFontToBDFBody_ksc5601(String ASaveFileName, String AWriteMode,
    TFont *AFont, TTextMetric *ATextMetric, String AEncoding,
    bool ASpcFont, bool AHanFont, bool AHanjaFont)
{
    FILE *fp = fopen(ASaveFileName.c_str(), AWriteMode.c_str());
    if (fp == NULL) return false;
    //--------------------------------------------------------------------------
    TStringList *StringList1 = new TStringList();
    TImage *Image1 = new TImage(NULL);

    Image1->Width = ATextMetric->tmMaxCharWidth;
    Image1->Height = ATextMetric->tmHeight;
    Image1->Canvas->Brush->Color = clBlack;
    Image1->Canvas->Brush->Style = bsSolid;
    Image1->Canvas->FillRect(Image1->ClientRect);
    Image1->Canvas->Font->Assign(AFont);
    Image1->Canvas->Font->Color = clWhite;
    Image1->Picture->Bitmap->PixelFormat = pf8bit;
    //--------------------------------------------------------------------------
    int MSB = 0;
    String Han = "  ";

    if (AEncoding == "ksc5601.1987-0") MSB = 0x8080;
    // 1. Ư������		(����: 0XA1~0XAC, ����: 0XA1~0XFE)
    if (ASpcFont) {
        for (int High = 0xA1; High <= 0xAC; High++) {   //  0xA1 ~ 0xAC���� 12�� (12������)
            for (int Low = 0xA1; Low <= 0xFE; Low++) {  //  0xA1 ~ 0xFE���� 94�� (�������� 94��)
                int Encoding = (High << 8) + Low;
                Han[1] = High, Han[2] = Low;
                String s = GetCharBBXInfo(StringList1, Image1, ATextMetric, 0, 0, Han, Encoding - MSB);
                fwrite(s.c_str(), strlen(s.c_str()), 1, fp);
            }
            if (!_IsWorking) {fclose(fp); return true;}
            Application->ProcessMessages();
        }
    }
    // 2. �ѱ�			(����: 0XB0~0XC8, ����: 0XA1~0XFE)
    if (AHanFont) {
        if (!ASpcFont) {
            for (int Low = 0xA1; Low < 0xA1 + 51; Low++) {  //  0xA1 ~ 0xFE���� 94�� (�������� 94��)
                int Encoding = (0xA4 << 8) + Low;
                Han[1] = 0xA4, Han[2] = Low;
                String s = GetCharBBXInfo(StringList1, Image1, ATextMetric, 0, 0, Han, Encoding - MSB);
                fwrite(s.c_str(), strlen(s.c_str()), 1, fp);
            }
        }
        for (int High = 0xB0; High <= 0xC8; High++) {   //  0xB0 ~ 0xC8���� 25�� (25������)
            for (int Low = 0xA1; Low <= 0xFE; Low++) {  //  0xA1 ~ 0xFE���� 94�� (�������� 94��)
                int Encoding = (High << 8) + Low;
                Han[1] = High, Han[2] = Low;
                String s = GetCharBBXInfo(StringList1, Image1, ATextMetric, 0, 0, Han, Encoding - MSB);
                fwrite(s.c_str(), strlen(s.c_str()), 1, fp);
            }
            if (!_IsWorking) {fclose(fp); return true;}
            Application->ProcessMessages();
        }
    }
    // 3. ����			(����: 0XCA~0XFD, ����: 0XA1~0XFE)
    if (AHanjaFont) {
        for (int High = 0xCA; High <= 0xFD; High++) {   //  0xCA ~ 0xFD���� 52�� (52������)
            for (int Low = 0xA1; Low <= 0xFE; Low++) {  //  0xA1 ~ 0xFE���� 94�� (�������� 94��)
                int Encoding = (High << 8) + Low;
                Han[1] = High, Han[2] = Low;
                String s = GetCharBBXInfo(StringList1, Image1, ATextMetric, 0, 0, Han, Encoding - MSB);
                fwrite(s.c_str(), strlen(s.c_str()), 1, fp);
            }
            if (!_IsWorking) {fclose(fp); return true;}
            Application->ProcessMessages();
        }
    }

    delete StringList1;
    delete Image1;

    fprintf(fp, "ENDFONT\n");
    fclose(fp);

    return true;
}
//------------------------------------------------------------------------------
bool SysHanFontToBDFBody_iso10646(String ASaveFileName, String AWriteMode,
    TFont *AFont, TTextMetric *ATextMetric,
    bool AEngFont, bool ASpcFont, bool AHanFont, bool AHanjaFont)
{
    FILE *fp = fopen(ASaveFileName.c_str(), AWriteMode.c_str());
    if (fp == NULL) return false;
    //--------------------------------------------------------------------------
    TStringList *StringList1 = new TStringList();
    TImage *Image1 = new TImage(NULL);

    Image1->Width = ATextMetric->tmMaxCharWidth;
    Image1->Height = ATextMetric->tmHeight;
    Image1->Canvas->Brush->Color = clBlack;
    Image1->Canvas->Brush->Style = bsSolid;
    Image1->Canvas->FillRect(Image1->ClientRect);
    Image1->Canvas->Font->Assign(AFont);
    Image1->Canvas->Font->Color = clWhite;
    Image1->Picture->Bitmap->PixelFormat = pf8bit;
    //--------------------------------------------------------------------------
    if (AEngFont) {
        for (int Index = 0; Index < 128; Index++) {
            String s = GetCharBBXInfo(StringList1, Image1, ATextMetric, 0, 0, (char)Index, Index);
            fwrite(s.c_str(), strlen(s.c_str()), 1, fp);
        }
    }
    //--------------------------------------------------------------------------
    for (int i = 256; i < 17304 + 67; i++) {	// 0.55 ����
        switch (CP949CodeTable[i].CodeType) {
        case CODETABLE_SPC:
            if (ASpcFont) break;
            else continue;
        case CODETABLE_HANGUL_SYLLABLE:
        case CODETABLE_HANGUL:
            if (AHanFont) break;
            else continue;
        case CODETABLE_CJK:
            if (AHanjaFont) break;
            else continue;
        }
        WideChar Unicode[2] = {0, 0};
        Unicode[0] = CP949CodeTable[i].Unicode;
        String s = GetCharBBXInfo(StringList1, Image1, ATextMetric, 0, 0, WideCharToString(Unicode), Unicode[0]);
        fwrite(s.c_str(), strlen(s.c_str()), 1, fp);

        if (!_IsWorking) {fclose(fp); return true;}
        if (i % 100 == 0) Application->ProcessMessages();
    }
    //--------------------------------------------------------------------------
    delete StringList1;
    delete Image1;

    fprintf(fp, "ENDFONT\n");
    fclose(fp);

    return true;
}
//------------------------------------------------------------------------------
bool SysHanFontToBDF(String ASaveFileName, String AWriteMode,
    TFont *AFont, TTextMetric *ATextMetric, String AEncoding,
    bool AEngFont, bool ASpcFont, bool AHanFont, bool AHanjaFont)
{
	static TBDFHeader BDFHeader1;

    int MSB = 0;
    if (AEncoding == "ksc5601.1987-0") MSB = 0x8080;

    BDFHeader1.Size_PointSize		= IntToStr(ATextMetric->tmHeight);
    BDFHeader1.Size_Xres			= IntToStr(ATextMetric->tmDigitizedAspectX);
    BDFHeader1.Size_Yres			= IntToStr(ATextMetric->tmDigitizedAspectY);
    BDFHeader1.FontBoundingBox_FBBx = IntToStr(ATextMetric->tmMaxCharWidth);
    BDFHeader1.FontBoundingBox_FBBy	= IntToStr(ATextMetric->tmHeight);
    BDFHeader1.FontBoundingBox_Xoff	= "0";
    BDFHeader1.FontBoundingBox_Yoff	= IntToStr(-ATextMetric->tmDescent);
    BDFHeader1.Foundry			    = "Windows";
    BDFHeader1.Family_Name		    = AFont->Name;
    BDFHeader1.Weight_Name		    = "medium";	// or "bold"
    BDFHeader1.Slant			    = "r";		// or "i"
    BDFHeader1.SetWidth_Name	    = "normal";
    BDFHeader1.Add_Style_Name	    = "";
    BDFHeader1.Pixel_Size 		    = IntToStr(ATextMetric->tmHeight);
    BDFHeader1.Point_Size 		    = IntToStr(AFont->Size * 10);
    BDFHeader1.Resolution_X 	    = IntToStr(ATextMetric->tmDigitizedAspectX);
    BDFHeader1.Resolution_Y 	    = IntToStr(ATextMetric->tmDigitizedAspectY);
    BDFHeader1.Spacing			    = (isFixedPitchFont(ATextMetric) ? "m" : "p");              // �������� "m"
    BDFHeader1.Average_Width 	    = IntToStr(ATextMetric->tmMaxCharWidth * 10);            // ���� �۲��� 80
    BDFHeader1.CharSet_Registry	    = AEncoding.SubString(1, AEncoding.Length() - 2);   // ��) ksc5601.1987-1 -> "ksc5601.1987"
    BDFHeader1.CharSet_Encoding	    = AEncoding[AEncoding.Length()];    // ��) ksc5601.1987-1 -> �� �κ��� "1"
    BDFHeader1.Default_Char 	    = IntToStr(0xA1A1 - MSB);
    BDFHeader1.Font_Ascent		    = IntToStr(ATextMetric->tmAscent);
    BDFHeader1.Font_Descent	 	    = IntToStr(ATextMetric->tmDescent);

    if (AEncoding == "iso10646-1") {
        int CharsCount = 0;
        if (AEngFont) CharsCount += 128;
        if (ASpcFont) CharsCount += (988 - 51);
        if (AHanFont) CharsCount += (11172 + 51 + 67);	// 0.55 ����
        if (AHanjaFont) CharsCount += 4888;
        BDFHeader1.Default_Char = "12288";
        BDFHeader1.CharsCount = IntToStr(CharsCount);
    } else {    // ksc5601.1987-?
        int CharsCount = 0;
        if (ASpcFont) CharsCount += 1128;
        if (AHanFont) {
            CharsCount += 2350;
            if (!ASpcFont) CharsCount += 51;
        }
        if (AHanjaFont) CharsCount += 4888;
        BDFHeader1.CharsCount = IntToStr(CharsCount);   // == 8366
    }

    BDFHeader1.Font	= GetXLFD(&BDFHeader1);

    String TmpHeadFile = GetTempFullPathAndFileName("HEAD");
    String TmpBodyFile = GetTempFullPathAndFileName("BODY");
    bool result = WriteBDF_Header(TmpHeadFile, AWriteMode, &BDFHeader1);
    if (!result) {
        ShowMessage("���� ������ �ۼ��ϴ� �� ������ �߻��Ͽ����ϴ�.\n\n" + TmpHeadFile);
        CurBDFHeader = NULL; return result;
    }

    CurBDFHeader = &BDFHeader1;

    if (AEncoding == "iso10646-1")
        result = SysHanFontToBDFBody_iso10646(TmpBodyFile, AWriteMode, AFont, ATextMetric,
            AEngFont, ASpcFont, AHanFont, AHanjaFont);
    else
        result = SysHanFontToBDFBody_ksc5601(TmpBodyFile, AWriteMode, AFont, ATextMetric,
            AEncoding, ASpcFont, AHanFont, AHanjaFont);

    if (!result) {ShowMessage("���� ������ �ۼ��ϴ� �� ������ �߻��Ͽ����ϴ�.\n\n" + TmpBodyFile); return result;}

    FileMerge_Two2One(ASaveFileName, TmpHeadFile, TmpBodyFile);

    return true;
}
//------------------------------------------------------------------------------
