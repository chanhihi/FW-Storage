//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include "BDF.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TBDFHeader *CurBDFHeader = NULL;
//---------------------------------------------------------------------------
bool WriteBDF_Header(String ASaveFileName, String AWriteMode, TBDFHeader *ABDFHeader)
{
	ABDFHeader->FI_STARTFONT		= "STARTFONT 2.1";
	ABDFHeader->FI_FONT				= "FONT "				+ ABDFHeader->Font;
	ABDFHeader->FI_SIZE				= "SIZE "				+ ABDFHeader->Size_PointSize		+ " "
															+ ABDFHeader->Size_Xres				+ " "
															+ ABDFHeader->Size_Yres;
	ABDFHeader->FI_FONTBOUNDINGBOX	= "FONTBOUNDINGBOX "	+ ABDFHeader->FontBoundingBox_FBBx	+ " "
															+ ABDFHeader->FontBoundingBox_FBBy	+ " "
															+ ABDFHeader->FontBoundingBox_Xoff	+ " "
															+ ABDFHeader->FontBoundingBox_Yoff;
	ABDFHeader->FI_STARTPROPERTIES	= "STARTPROPERTIES 17";
    ABDFHeader->FI_FOUNDRY			= "FOUNDRY \""			+ ABDFHeader->Foundry			+ "\"";
    ABDFHeader->FI_FAMILY_NAME		= "FAMILY_NAME \""		+ ABDFHeader->Family_Name		+ "\"";
    ABDFHeader->FI_WEIGHT_NAME		= "WEIGHT_NAME \""		+ ABDFHeader->Weight_Name		+ "\"";
    ABDFHeader->FI_SLANT			= "SLANT \""			+ ABDFHeader->Slant				+ "\"";
    ABDFHeader->FI_SETWIDTH_NAME	= "SETWIDTH_NAME \""	+ ABDFHeader->SetWidth_Name		+ "\"";
    ABDFHeader->FI_ADD_STYLE_NAME	= "ADD_STYLE_NAME \""	+ ABDFHeader->Add_Style_Name	+ "\"";
    ABDFHeader->FI_PIXEL_SIZE		= "PIXEL_SIZE "			+ ABDFHeader->Pixel_Size;
    ABDFHeader->FI_POINT_SIZE		= "POINT_SIZE "			+ ABDFHeader->Point_Size;
	ABDFHeader->FI_RESOLUTION_X		= "RESOLUTION_X "		+ ABDFHeader->Resolution_X;
	ABDFHeader->FI_RESOLUTION_Y		= "RESOLUTION_Y "		+ ABDFHeader->Resolution_Y;
	ABDFHeader->FI_SPACING			= "SPACING \""			+ ABDFHeader->Spacing			+ "\"";
	ABDFHeader->FI_AVERAGE_WIDTH	= "AVERAGE_WIDTH "		+ ABDFHeader->Average_Width;
	ABDFHeader->FI_CHARSET_REGISTRY	= "CHARSET_REGISTRY \""	+ ABDFHeader->CharSet_Registry	+ "\"";
	ABDFHeader->FI_CHARSET_ENCODING	= "CHARSET_ENCODING \""	+ ABDFHeader->CharSet_Encoding	+ "\"";
	ABDFHeader->FI_DEFAULT_CHAR		= "DEFAULT_CHAR "		+ ABDFHeader->Default_Char;
	ABDFHeader->FI_FONT_ASCENT		= "FONT_ASCENT "		+ ABDFHeader->Font_Ascent;
	ABDFHeader->FI_FONT_DESCENT		= "FONT_DESCENT "		+ ABDFHeader->Font_Descent;
	ABDFHeader->FI_ENDPROPERTIES	= "ENDPROPERTIES";
	ABDFHeader->FI_CHARS			= "CHARS "				+ ABDFHeader->CharsCount;
	//--------------------------------------------------------------------------
	String BDFHeader =	ABDFHeader->FI_STARTFONT		+ "\n" +
						ABDFHeader->FI_FONT				+ "\n" +
						ABDFHeader->FI_SIZE				+ "\n" +
						ABDFHeader->FI_FONTBOUNDINGBOX	+ "\n" +
						ABDFHeader->FI_STARTPROPERTIES	+ "\n" +
						ABDFHeader->FI_FOUNDRY			+ "\n" +
						ABDFHeader->FI_FAMILY_NAME		+ "\n" +
						ABDFHeader->FI_WEIGHT_NAME		+ "\n" +
						ABDFHeader->FI_SLANT			+ "\n" +
						ABDFHeader->FI_SETWIDTH_NAME	+ "\n" +
						ABDFHeader->FI_ADD_STYLE_NAME	+ "\n" +
						ABDFHeader->FI_PIXEL_SIZE		+ "\n" +
						ABDFHeader->FI_POINT_SIZE		+ "\n" +
						ABDFHeader->FI_RESOLUTION_X		+ "\n" +
						ABDFHeader->FI_RESOLUTION_Y		+ "\n" +
						ABDFHeader->FI_SPACING			+ "\n" +
						ABDFHeader->FI_AVERAGE_WIDTH	+ "\n" +
						ABDFHeader->FI_CHARSET_REGISTRY	+ "\n" +
						ABDFHeader->FI_CHARSET_ENCODING	+ "\n" +
						ABDFHeader->FI_DEFAULT_CHAR		+ "\n" +
						ABDFHeader->FI_FONT_ASCENT		+ "\n" +
						ABDFHeader->FI_FONT_DESCENT		+ "\n" +
						ABDFHeader->FI_ENDPROPERTIES	+ "\n" +
						ABDFHeader->FI_CHARS			+ "\n";
	//--------------------------------------------------------------------------
    FILE *fp = fopen(ASaveFileName.c_str(), AWriteMode.c_str());	// ���� ����
    if (fp == NULL) {
    	ShowMessage("���� ������ �ۼ��ϴ� �� ������ �߻��Ͽ����ϴ�!\n\n" + ASaveFileName);
        return false;
    }
    fwrite(BDFHeader.c_str(), strlen(BDFHeader.c_str()), 1, fp);
    fclose(fp);	// ���� �ݱ�

    return true;
}
//---------------------------------------------------------------------------
String GetXLFD(TBDFHeader *ABDFHeader)
{
	String XLFD =	"-" +
    				ABDFHeader->Foundry				+ "-" +
		    	   	ABDFHeader->Family_Name			+ "-" +
			       	ABDFHeader->Weight_Name			+ "-" +
			       	ABDFHeader->Slant				+ "-" +
			       	ABDFHeader->SetWidth_Name		+ "-" +
                    								+ "-" +
			        ABDFHeader->Pixel_Size			+ "-" +
			        ABDFHeader->Point_Size			+ "-" +
					ABDFHeader->Resolution_X		+ "-" +
					ABDFHeader->Resolution_Y		+ "-" +
			    	ABDFHeader->Spacing				+ "-" +
			    	ABDFHeader->Average_Width		+ "-" +
			        ABDFHeader->CharSet_Registry	+ "-" +
			        ABDFHeader->CharSet_Encoding;
    return XLFD;
}
//---------------------------------------------------------------------------
