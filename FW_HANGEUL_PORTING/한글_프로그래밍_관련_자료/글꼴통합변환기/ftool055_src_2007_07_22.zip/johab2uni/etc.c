//---------------------------------------------------------------------------
#ifdef __BORLANDC__
#pragma warn -8004
#endif

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "..\hanlib\hanlib.h"
#include "etc.h"
//---------------------------------------------------------------------------
char *ExtractFileName(char *AFullPath)
{
    static char filename[256];
    char *p;

    p = strrchr(AFullPath, '\\');
    if (p) {strcpy(filename, p + 1); return filename;}

    p = strrchr(AFullPath, '/');
    if (p) {strcpy(filename, p + 1); return filename;}

    return AFullPath;
}
//---------------------------------------------------------------------------
char *ExtractFileExt(char *AFileName)
{
    static char ext[128];
    char *p = strrchr(AFileName, '.');
    if (p) {strcpy(ext, p); return ext;}

    return NULL;
}
//---------------------------------------------------------------------------
char *ExtractFileNameOnly(char *AFullPath)
{
    static char filename[128];
    char *p;

    strcpy(filename, ExtractFileName(AFullPath));
    p = strrchr(filename, '.');
    *p = '\0';

    return filename;
}
//---------------------------------------------------------------------------
bool IsEngFont(int ASize)
{
    switch (ASize) {
    case 2048: case 4096: case 4112: return true;
    default: return false;
    }
}
//---------------------------------------------------------------------------
bool IsHanFont(int ASize)
{
    switch (ASize) {
    case 3616: case 3776: case 6176: case 11008: case 11520: case 12224: case 12800: case 13056: return true;
    default: return false;
    }
}
//---------------------------------------------------------------------------
bool IsSpcFont(int ASize)
{
    switch (ASize) {
    case 36096: case 33696: return true;
    default: return false;
    }
}
//---------------------------------------------------------------------------
bool IsHanjaFont(int ASize)
{
    return ((ASize == 156416) ? true : false);
}
//---------------------------------------------------------------------------
void HyphenToUnderline(char *s)
{
	unsigned i;

	for (i = 0; i < strlen(s); i++) 
		if (s[i] == '-') s[i] = '_';
}
//---------------------------------------------------------------------------
bool ishangul1st(byte *s, int pos)
{
    int i;

    if (pos < 0 || (unsigned)pos > strlen((char *)s) - 2 || s[pos] < 128) return false;

    for (i = 0; i < pos; )
        if (isascii(s[i])) i++;
        else i += 2;

    return ((i == pos) ? true : false);
}
//---------------------------------------------------------------------------
bool ishangul2nd(byte *s, int pos)
{
    int i;

    if (pos < 1 ||  (unsigned)pos > strlen((char *)s) - 1 || s[pos - 1] < 128) return false;

    for (i = 0; i < pos; )
        if (isascii(s[i])) i++;
        else i += 2;

    return ((i == pos + 1) ? true : false);
}
//---------------------------------------------------------------------------
char *replaceAll(char *result, char *s, const char *olds, const char *news)
{
//    char *result;
    char *sr;
    size_t i, count = 0;
    size_t oldlen, newlen;

    oldlen = strlen(olds);
    if (oldlen < 1) return s;
    newlen = strlen(news);

    if (newlen != oldlen) {
        for (i = 0; s[i] != '\0';) {
            if (memcmp(&s[i], olds, oldlen) == 0) count++, i += oldlen;
            else i++;
        }
    } else i = strlen(s);

    //result = (char *) malloc(i + 1 + count * (newlen - oldlen));
    //if (result == NULL) return NULL;

    sr = result;
    while (*s) {
        if (memcmp(s, olds, oldlen) == 0) {
            memcpy(sr, news, newlen);
            sr += newlen;
            s  += oldlen;
        } else *sr++ = *s++;
    }
    *sr = '\0';

    return result;
}
//---------------------------------------------------------------------------
void RemoveEncodingStr(char *s)
{
    char result[1024];
    replaceAll(result, s, "-iso10646-1", "");     strcpy(s, result);
    replaceAll(result, s, "-iso8859-1", "");      strcpy(s, result);
    replaceAll(result, s, "-johab844-1", "");     strcpy(s, result);
    replaceAll(result, s, "-ksc5601.1987-0", ""); strcpy(s, result);
    replaceAll(result, s, "-ksc5601.1987-1", ""); strcpy(s, result);
}
//---------------------------------------------------------------------------
