//------------------------------------------------------------------------------
#ifndef __ADLIB32_H
#define __ADLIB32_H
//------------------------------------------------------------------------------
#include "datatype.h"
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//------------------------------------------------------------------------------
#include "ADLIB.h"
#include "BNK.h"
#include "FMOPL.h"
#include "IMS.h"
#include "IMSPLAY.h"
#include "OUTCHIP.h"
#include "PLAYER.h"
#include "ROL.h"
#include "ROLPLAY.h"
#include "SETFREQ.h"
#include "waveloop.h"
//------------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif
