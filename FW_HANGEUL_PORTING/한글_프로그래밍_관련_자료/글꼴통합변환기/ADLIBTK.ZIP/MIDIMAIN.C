/*
   This program consisits of 3 C files and 3 assembler files.  The C files
   are midimain.c, midiplay.c and adlib.c.  The three assembler files are
   timer.asm, outchip.asm and setfreq.asm.
   Libraries are provided for the assembler files so that you do not
   need an assembler and you do not need to know assembly language.
   The libraries are named xADLIB.LIB where x is S, M, L for Small, Medium
   and Large model code.


   Microsoft C, v5.1 instructions
   ------------------------------
   We suggest compiling with the following options:
	  cl -AL -Zi -J -Ot -Zp -Gs -c


   QuickC 2.0 Instructions
   -----------------------
   The stack checking must be turned off because the timer interrupt is
   used and the interrupt routines use a different stack.
   The files must be compiled with stack checking off (select "Compiler
   Flags" in the "Make" dialog of the "Options" menu) and they must be
   compiled for the release version ("Make" dialog).  QuickC ignores its
   stack check flag if it is not in release version mode.
   In the "Link Flags" dialog (selected in the "Make" dialog), set the
   global flag to ignore case.  If this is not done, the linker will not
   find the routines in the library.


   Turbo C Instructions
   --------------------
   To compile under Turbo C, go into the file "cflags.h" and de-comment the
   following line so that TURBOC is defined:
	  #define  TURBOC


   The following files must be linked together to make the executable:
	  midimain.obj +
	  midiplay.obj +
	  adlib.obj +
	  timer.obj +
	  outchip.obj +
	  setfreq.obj

*/

#include  "cflags.h"

#include  <stdio.h>
#include  <stdlib.h>
#include  <fcntl.h>
#include  <string.h>
#include  <ctype.h>
#include  <io.h>

/* Keeps track of last change of volume to avoid unnecessary calls to
   change of volume routine. */
extern int current_vol [MAX_VOICES];
extern int volume_flag;


/*-------------------------------------------------------------------------
   Enable or disable the volume, but continue playing the song.
*/
Volume_OnOff (flag)
   int flag;
{
   int n;
   if (flag != volume_flag) {
	  if (!flag)
		 for (n=0; n < MAX_VOICES; n++) {
			SetVoiceVolume (n, 0);
			NoteOff (n);
		 }
	  else
		 for (n=0; n < MAX_VOICES; n++) SetVoiceVolume (n, current_vol [n]);
   }
   volume_flag = flag;
}


/*-------------------------------------------------------------------------
   Read in the midi 1.0 file.
*/
UCHAR *Read_Midi_File (file_name)
   char *file_name;
{
   int file, result;
   UCHAR *c;
   long length;

   file = open (file_name, O_RDONLY + O_BINARY);
   if (file < 0) {
	  fprintf (stderr, "Cannot open file %s \n", file_name);
	  return (NULL);
   }

   length = filelength (file);
   if (length > 65534L) {
	  /* This program will read files <= 64K.  If you wish to read larger
		 files, you will have to use halloc() in Microsoft or farmalloc() in
		 TurboC to allocate memory larger than 64K.  Then you will have to
		 read the file in 64K chunks.  */
	  fprintf (stderr, "File too large.\n");
	  return (NULL);
   }

   /* Allocate buffer for entire file. */
   c = (UCHAR *) malloc (length);
   if (!c) {
	  fprintf (stderr, "Insufficient memory available for reading input file.\n");
	  return (NULL);
   }

   /* Read the file into the buffer. */
   result = read (file, c, length);
   if (length != result) {
	  fprintf (stderr, "Error reading file.\n");
	  free (c);
	  return (NULL);
   }

   close (file);
   return (c);
}

/*-------------------------------------------------------------------------
	Wait until the end of melody (musRunning == 0).
*/
void  WaitEndMelo (file_name)
   char *file_name;
{
   extern char musRunning;
   char c;
   int n;

   printf ("\nWaiting for end of %s.  Press <ESC> to exit.\n", file_name);

   while (musRunning) {
	  #ifndef INT_METHOD
		 Test_Event ();
	  #endif

	  if (kbhit()) {
		  c = getch();
		  if (c == 0x1b) {
			 /* User has pressed ESC.  Shut off all voices.  If they are not
				shut off, instruments that have sustained sounds will
				continue to play. */
			 for (n=0; n < MAX_VOICES; n++) {
				SetVoiceVolume (n, 0);
				NoteOff (n);
			 }
			 Stop_Melo();
			 return;
		  }
		  else {
			 /* User has pressed 'S' to silence the music, but the song
				continues to play.  This is useful in applications where
				you have music playing in the background and you wish to
				allow the user the choice of whether or not he/she wants to
				hear the soundtrack. */
			 c = toupper (c);
			 if (c == 'S') Volume_OnOff (!volume_flag);
		  }
	  }
   }
   printf ("Done\n");
}

/*-------------------------------------------------------------------------
	Midi 1.0 file playback program.
*/
main (argc, argv)
	int argc;
	char * argv[];
{
	extern void Midi_Play (UCHAR *);
	UCHAR *buf;
	int n;

	/* Initalize the low-level sound-driver: */
	if (!SoundColdInit (0x388)) {
		printf ("\nAdlib board not found!");
		exit (1);
	}

	if (argc < 2) {
		fprintf (stderr, "  Format: midiplay midi_file_name [midi_file_name...]\n");
		exit (1);
	}

	/* Perform some initialisations ... */
	Midi_Init();

	for (n=1; n < argc; n++) {

	   /* Read the music file. */
	   buf = Read_Midi_File (argv [n]);
	   if (buf) {
		  /* Start the file playing. */
		  Midi_Play (buf);

		  /* wait until end.... */
		  WaitEndMelo (argv [n]);

		  free (buf);
	   }
	}

	/* Remove the clock driver: */
	Midi_End ();

	exit (0);
}


