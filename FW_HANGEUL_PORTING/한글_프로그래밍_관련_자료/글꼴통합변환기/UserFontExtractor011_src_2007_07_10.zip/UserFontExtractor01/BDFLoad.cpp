//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include <string.h>
#include "BDFLoad.h"
#include "Common.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
static char bdf_engbitmaps[128][4 * 16];
static char bdf_hanbitmaps[17048][6 * 16];
static int bdf_hanencodings[17048];

static String SBIT32File = "";
//---------------------------------------------------------------------------
static bool findrow(FILE *fp, char *buffer, char *s)
{
	char buff[200];

	while (true) {
		if (!fgets(buff, 200, fp)) return false;
		if (strstr(buff, s)) {strcpy(buffer, buff); return true;}
	}
}
//------------------------------------------------------------------------------
static bool getrows(FILE *fp, char *buffer, int n)
{
	char s[200];

    buffer[0] = NULL;
	for (int i = 0; i < n; i++)	{
		if (!fgets(s, 200, fp)) return false;;
		strcat(buffer, s);
	}

    return true;
}
//------------------------------------------------------------------------------
void CreateSBIT32File(void)
{
    SBIT32File = GetTempPathName() + "sbit32.exe";

    if (!FileExists(SBIT32File)) {
        TResourceStream *RS1 = new TResourceStream((int)HInstance, "SBIT32", RT_RCDATA);
        RS1->SaveToFile(SBIT32File);
        delete RS1;
    }
}
//------------------------------------------------------------------------------
bool CreateMETFile(String AMETFile)
{
    FILE *fp = fopen(AMETFile.c_str(), "wt");
    if (fp == NULL)
        {ShowErrorMessage("���� ������ ���� �� Error!\n\n" + AMETFile); return false;}
    fprintf(fp, "PPEM 16\n");
    fclose(fp);

    return true;
}
//------------------------------------------------------------------------------
bool sbit32_x(String ATTFFile, String AMETFile, String AOutBDFFile)
{
    if (!FileExists(SBIT32File)) return false;
    if (!FileExists(ATTFFile))   return false;
    if (!FileExists(AMETFile))   return false;
    if (FileExists(AOutBDFFile)) DeleteFileA(AOutBDFFile);

    String s = SBIT32File + " -x " + ATTFFile + " " + AMETFile + " " + AOutBDFFile;
    winexecAndWait32V2(s.c_str(), 0);

    if (!FileExists(AOutBDFFile)) return false;

    return true;
}
//------------------------------------------------------------------------------
static bool LoadEngBDFFile(String ABDFFileName)
{
   	char buffer[200];
	int Result, Encoding, CharsCount = 0;

	FILE *fp = fopen(ABDFFileName.c_str(), "rt");
    if (fp == NULL) return false;

    if (!findrow(fp, buffer, "CHARS")) {fclose(fp); return false;}
	sscanf(buffer, "CHARS %d", &CharsCount);
    if (CharsCount > 255) {fclose(fp); return false;}

    if (!findrow(fp, buffer, "STARTCHAR")) {fclose(fp); return false;}
	char *p = strchr(buffer, '.');
	sscanf(p+1, "%x", &Encoding);
    if (Encoding != 0x01) {fclose(fp); return false;}

	for (int i = 1; i < 128; i++) {
		if (!findrow(fp, buffer, "BITMAP")) {fclose(fp); return false;}
		if (!getrows(fp, bdf_engbitmaps[i], 16)) {fclose(fp); return false;}
	}
	fclose(fp);

    return true;
}
//------------------------------------------------------------------------------
static bool LoadHanBDFFile(String ABDFFileName)
{
   	char buffer[200] = {0, };
	int Result, Encoding, CharsCount = 0;

	FILE *fp = fopen(ABDFFileName.c_str(), "rt");
    if (fp == NULL) return false;

	if (!findrow(fp, buffer, "CHARS")) {fclose(fp); return false;}
	sscanf(buffer, "CHARS %d", &CharsCount);
    if (CharsCount != 17048) {fclose(fp); return false;}

	for (int i = 0; i < CharsCount; i++) {
		if (!findrow(fp, buffer, "STARTCHAR")) {fclose(fp); return false;}
		char *p = strchr(buffer, '.');
		sscanf(p+1, "%4x", &Encoding);
		bdf_hanencodings[i] = Encoding;
		if (!findrow(fp, buffer, "BITMAP")) {fclose(fp); return false;}
		if (!getrows(fp, bdf_hanbitmaps[i], 16)) {fclose(fp); return false;}
	}
	fclose(fp);

    return true;
}
//------------------------------------------------------------------------------
static bool WriteBDFFile(String ABDFFile)
{
	FILE *fp = fopen(ABDFFile.c_str(), "wt");
    if (fp == NULL) return false;

    fputs(
    	"STARTFONT 2.1\n"							                            \
    	"FONT -16x16-TestFont-medium-r-normal--16-120-96-96-m-160-iso10646-1\n"	\
    	"SIZE 16 96 96\n"							                            \
	    "FONTBOUNDINGBOX 16 16 0 0\n"			                                \
    	"STARTPROPERTIES 17\n"					                                \
    	"FOUNDRY \"16x16\"\n"					                                \
    	"FAMILY_NAME \"TestFont\"\n"                                            \
    	"WEIGHT_NAME \"medium\"\n"				                                \
    	"SLANT \"r\"\n"							                                \
    	"SETWIDTH_NAME \"normal\"\n"			                                \
    	"ADD_STYLE_NAME \"\"\n"					                                \
    	"PIXEL_SIZE 16\n"						                                \
    	"POINT_SIZE 120\n"						                                \
    	"RESOLUTION_X 96\n"						                                \
    	"RESOLUTION_Y 96\n"						                                \
    	"SPACING \"m\"\n"						                                \
    	"AVERAGE_WIDTH 160\n"					                                \
    	"CHARSET_REGISTRY \"iso10646\"\n"		                                \
    	"CHARSET_ENCODING \"1\"\n"				                                \
    	"DEFAULT_CHAR 12288\n"					                                \
    	"FONT_ASCENT 16\n"						                                \
    	"FONT_DESCENT 0\n"						                                \
    	"ENDPROPERTIES\n"                                                       \
    	"CHARS 17176\n",
    fp);

    strcpy(bdf_engbitmaps[0], "00\n00\n00\n00\n00\n00\n00\n00\n00\n00\n00\n00\n00\n00\n00\n00\n");
    for (int i = 0; i < 128; i++) {
        fprintf(fp, "STARTCHAR char0x%02X\n", i);
        fprintf(fp, "ENCODING %d\n", i);
        fprintf(fp, "SWIDTH 666 0\n");
        fprintf(fp, "DWIDTH 8 0\n");
        fprintf(fp, "BBX 8 16 0 0\n");
        fprintf(fp, "BITMAP\n");
        fprintf(fp, "%s", bdf_engbitmaps[i]);
        fprintf(fp, "ENDCHAR\n");
    }

    for (int i = 0; i < 17048; i++) {
        fprintf(fp, "STARTCHAR char0x%04X\n", bdf_hanencodings[i]);
        fprintf(fp, "ENCODING %d\n", bdf_hanencodings[i]);
        fprintf(fp, "SWIDTH 1333 0\n");
        fprintf(fp, "DWIDTH 16 0\n");
        fprintf(fp, "BBX 16 16 0 0\n");
        fprintf(fp, "BITMAP\n");
        fprintf(fp, "%s", bdf_hanbitmaps[i]);
        fprintf(fp, "ENDCHAR\n");
    }
    fprintf(fp, "ENDFONT\n");
	fclose(fp);

    return true;
}
//------------------------------------------------------------------------------
bool MergeEngHanBDFs(String AOutBDFFile, String AEngBDFFile, String AHanBDFFile)
{
    if (!LoadEngBDFFile(AEngBDFFile))
        {ShowErrorMessage("���� ������ �д� �� Error!\n\n" + AEngBDFFile); return false;}
    if (!LoadHanBDFFile(AHanBDFFile))
        {ShowErrorMessage("���� ������ �д� �� Error!\n\n" + AHanBDFFile); return false;}
    if (!WriteBDFFile(AOutBDFFile))
        {ShowErrorMessage("���� ������ ���� �� Error!\n\n" + AOutBDFFile); return false;}

    return true;
}
//------------------------------------------------------------------------------

