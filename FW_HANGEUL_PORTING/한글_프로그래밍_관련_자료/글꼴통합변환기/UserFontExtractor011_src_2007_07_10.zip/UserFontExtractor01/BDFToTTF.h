//---------------------------------------------------------------------------
#ifndef BDFToTTFH
#define BDFToTTFH
//---------------------------------------------------------------------------
typedef struct {
    String ACopyright;
    String AFontname;
    String AVersion;
    String ATrademark;
    String ACopyrightCP;
    String AFontnameCP;
    String ATrademarkCP;
} TTTFIniInfo;

void SaveTTFInfoFile(String ASaveFileName, TTTFIniInfo *ATTFIniInfo);
String ConvertBDF2TTF(String ASaveTTFName, String ALoadBDFName, String AFontName, String AFontVer, String ACopyright);
//---------------------------------------------------------------------------
#endif

