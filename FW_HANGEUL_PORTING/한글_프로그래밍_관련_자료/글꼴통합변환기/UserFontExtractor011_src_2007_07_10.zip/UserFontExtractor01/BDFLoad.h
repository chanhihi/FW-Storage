//---------------------------------------------------------------------------
#ifndef BDFLoadH
#define BDFLoadH
//---------------------------------------------------------------------------
void CreateSBIT32File(void);
bool CreateMETFile(String AMETFile);
bool sbit32_x(String ATTFFile, String AMETFile, String AOutBDFFile);
bool MergeEngHanBDFs(String AOutBDFFile, String AEngBDFFile, String AHanBDFFile);
//---------------------------------------------------------------------------
#endif

