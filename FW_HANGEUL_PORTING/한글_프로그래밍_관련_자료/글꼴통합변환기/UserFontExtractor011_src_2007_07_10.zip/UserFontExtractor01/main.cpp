//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include "main.h"
#include "Common.h"
#include "BDFLoad.h"
#include "BDFToTTF.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    TempPath = GetTempPathName();   // ���ڿ� ���� \ ����.
    CreateDir(TempPath);

    SysFontsPath = GetSysFontsPath();   // ���ڿ� ���� \�� ���� ����.

    RefreshFontList();
}
//------------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
    DeleteDir(TempPath);   // ������ �� ���� ���ϱ��� ��� �����Ѵ�.
                           // ���ڿ� ���� \ �־�� ��.
}
//---------------------------------------------------------------------------
String TForm1::GetDefaultFaceName(void)
{
    String SelEngFontName = lb_EngFontList->Items->Strings[lb_EngFontList->ItemIndex];
    String SelHanFontName = lb_HanFontList->Items->Strings[lb_HanFontList->ItemIndex];

    return SelEngFontName + "(����)+" + SelHanFontName + "(�ѱ�)";
}
//---------------------------------------------------------------------------
void TForm1::RefreshFontList(void)
{
    lb_EngFontList->Clear();
    lb_HanFontList->Clear();

    TFont *Font1 = new TFont();
    for (int i = 0; i < Screen->Fonts->Count; i++) {
        String s = Screen->Fonts->Strings[i];
        if (s.Pos("@")) continue;
        Font1->Name = s;
        if (isFixedFont(Font1, PaintBox1)) lb_EngFontList->Items->Add(s);
    }
    delete Font1;

    lb_HanFontList->Items = lb_EngFontList->Items;

    lb_EngFontList->ItemIndex = 0;
    lb_HanFontList->ItemIndex = 0;
    lb_EngFontListClick(this);
    lb_HanFontListClick(this);

    le_FontName->Text = GetDefaultFaceName();
    le_FontVer->Text = "";
    le_FontCopyright->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::lb_EngFontListClick(TObject *Sender)
{
    SelEngFontName = lb_EngFontList->Items->Strings[lb_EngFontList->ItemIndex];
    SelEngFontFile = GetFontFileName(SelEngFontName);
    mm_EngFontPreview->Font->Name = SelEngFontName;
    lb_SelEngFontName->Caption = SelEngFontName;
    if (SelEngFontFile == "") {
        lb_SelEngFontFile->Caption = "(�� �� ����)";
        lb_SelEngFontFile->Font->Color = clRed;
    } else {
        lb_SelEngFontFile->Caption = SelEngFontFile;
        lb_SelEngFontFile->Font->Color = clWindowText;
    }
    le_FontName->Text = GetDefaultFaceName();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::lb_HanFontListClick(TObject *Sender)
{
    SelHanFontName = lb_HanFontList->Items->Strings[lb_HanFontList->ItemIndex];
    SelHanFontFile = GetFontFileName(SelHanFontName);
    mm_HanFontPreview->Font->Name = SelHanFontName;
    lb_SelHanFontName->Caption = SelHanFontName;
    if (SelHanFontFile == "") {
        lb_SelHanFontFile->Caption = "(�� �� ����)";
        lb_SelHanFontFile->Font->Color = clRed;
    } else {
        lb_SelHanFontFile->Caption = SelHanFontFile;
        lb_SelHanFontFile->Font->Color = clWindowText;
    }
    le_FontName->Text = GetDefaultFaceName();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btn_BuildTTFClick(TObject *Sender)
{
    bool Result;
    if (le_FontName->Text.Length() <= 2)
        {ShowMessage("��ü �̸��� �ּ� 2�� �̻� �Է��ϼ���!"); le_FontName->SetFocus(); return;}
    if (le_FontName->Text.Length() > 32)
        {ShowMessage("��ü �̸��� �ִ� 32 byte������ �Է��ϼ���!"); le_FontName->SetFocus(); return;}

    if (SelEngFontFile == "") {ShowMessage(SelEngFontName + " �۲��� ������ �� �����ϴ�!"); return;}
    if (SelHanFontFile == "") {ShowMessage(SelHanFontName + " �۲��� ������ �� �����ϴ�!"); return;}
    //--------------------------------------------------------------------------
    SaveDialog1->FileName = le_FontName->Text;
    if (!SaveDialog1->Execute()) return;
    double StartTime = GetCurrentTime();
    //--------------------------------------------------------------------------
    String EngBDFFile = TempPath + ExtractFileNameOnly(SelEngFontFile) + ".bdf";
    String HanBDFFile = TempPath + ExtractFileNameOnly(SelHanFontFile) + ".bdf";

    String METFile = TempPath + "ppem16.met";
    if (!CreateMETFile(METFile)) return;

    CreateSBIT32File();
    Result = sbit32_x(SysFontsPath + "\\" + SelEngFontFile, METFile, EngBDFFile);
    if (!Result) {ShowErrorMessage("sbit32.exe ���� �� Error!"); return;}
    Result = sbit32_x(SysFontsPath + "\\" + SelHanFontFile, METFile, HanBDFFile);
    if (!Result) {ShowErrorMessage("sbit32.exe ���� �� Error!"); return;}
    //--------------------------------------------------------------------------
    String OneBDFFile = TempPath + ExtractFileNameOnly(SaveDialog1->FileName) + ".bdf";
    Result = MergeEngHanBDFs(OneBDFFile, EngBDFFile, HanBDFFile);
    if (!Result) {ShowErrorMessage("�� BDF ������ �аų� �����ϴ� �� Error!"); return;}
    //--------------------------------------------------------------------------
    String ResultMsg = ConvertBDF2TTF(SaveDialog1->FileName, OneBDFFile,
        le_FontName->Text, le_FontVer->Text, le_FontCopyright->Text);
    if (ResultMsg != "") {ShowErrorMessage(ResultMsg); return;}
    DeleteFileA(OneBDFFile);
    //--------------------------------------------------------------------------
    String FontFileName = SysFontsPath + "\\" + ExtractFileName(SaveDialog1->FileName);
    if (cb_CopyToFontsFolder->Checked) {
        CopyFileA(SaveDialog1->FileName.c_str(), FontFileName.c_str(), FALSE);
        OpenSysFontsFolderMinimize();
    }
    if (cb_OpenNewTTF->Checked) ShellExec(SaveDialog1->FileName);
    //--------------------------------------------------------------------------
    double EndTime = GetCurrentTime();

    ShowMessage("������ ���ο� TTF �۲� ������ �����Ͽ����ϴ�!\n\n" + SaveDialog1->FileName
        + "\n\n(�ҿ�� �ð�: " + FloatToStr((EndTime - StartTime) / 1000) + "��)");
    if (cb_CopyToFontsFolder->Checked) RefreshFontList();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btn_OpenFontsFolderClick(TObject *Sender)
{
    OpenSysFontsFolderShow();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::lb_EngFontListDblClick(TObject *Sender)
{
    if (SelEngFontFile == "")
        {ShowErrorMessage("������ �۲� �̸����δ� �ش� �۲� ������ �� �� �����ϴ�!"); return;}

    String s = SysFontsPath + "\\" + SelEngFontFile;
    if (!FileExists(s)) {ShowErrorMessage("���� �۲� ������ ã�� �� �����ϴ�!\n\n" + s); return;}

    ShellExec(s);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::lb_HanFontListDblClick(TObject *Sender)
{
    if (SelHanFontFile == "")
        {ShowErrorMessage("������ �۲� �̸����δ� �ش� �۲� ������ �� �� �����ϴ�!"); return;}

    String s = SysFontsPath + "\\" + SelHanFontFile;
    if (!FileExists(s)) {ShowErrorMessage("���� �۲� ������ ã�� �� �����ϴ�!\n\n" + SelHanFontFile); return;}

    ShellExec(s);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::sbtn_RefreshFontListClick(TObject *Sender)
{
    RefreshFontList();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormShow(TObject *Sender)
{
    lb_EngFontList->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::lb_EngFontListKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if (Key == VK_RETURN) lb_EngFontListDblClick(Sender);     
}
//---------------------------------------------------------------------------
void __fastcall TForm1::lb_HanFontListKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if (Key == VK_RETURN) lb_HanFontListDblClick(Sender);
}
//---------------------------------------------------------------------------

