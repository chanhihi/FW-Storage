//---------------------------------------------------------------------------
#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <ImgList.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <jpeg.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TButton *btn_BuildTTF;
    TButton *btn_OpenFontsFolder;
    TCheckBox *cb_CopyToFontsFolder;
    TCheckBox *cb_OpenNewTTF;
    TGroupBox *GroupBox1;
    TGroupBox *GroupBox2;
    TGroupBox *GroupBox3;
    TLabel *Label10;
    TLabel *Label11;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *lb_SelEngFontFile;
    TLabel *lb_SelEngFontName;
    TLabel *lb_SelHanFontFile;
    TLabel *lb_SelHanFontName;
    TLabeledEdit *le_FontCopyright;
    TLabeledEdit *le_FontName;
    TLabeledEdit *le_FontVer;
    TListBox *lb_EngFontList;
    TListBox *lb_HanFontList;
    TMemo *Memo1;
    TMemo *Memo2;
    TMemo *Memo3;
    TMemo *mm_EngFontPreview;
    TMemo *mm_HanFontPreview;
    TPageControl *PageControl1;
    TPaintBox *PaintBox1;
    TSaveDialog *SaveDialog1;
    TSpeedButton *sbtn_RefreshFontList;
    TTabSheet *TabSheet1;
    TTabSheet *TabSheet2;
    TTabSheet *TabSheet3;
    TMemo *Memo4;
    TTabSheet *TabSheet4;
    TImage *Image1;
    TImage *Image2;
    TMemo *Memo5;
    TImage *Image3;
    TTabSheet *TabSheet5;
    TMemo *Memo6;
    TImage *Image4;
    TLabel *Label1;
    TLabel *Label2;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall btn_BuildTTFClick(TObject *Sender);
    void __fastcall btn_OpenFontsFolderClick(TObject *Sender);
    void __fastcall lb_EngFontListClick(TObject *Sender);
    void __fastcall lb_EngFontListDblClick(TObject *Sender);
    void __fastcall lb_HanFontListClick(TObject *Sender);
    void __fastcall lb_HanFontListDblClick(TObject *Sender);
    void __fastcall sbtn_RefreshFontListClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall lb_EngFontListKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall lb_HanFontListKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);

    String SelEngFontFile, SelHanFontFile;
    String SelEngFontName, SelHanFontName;
    String TempPath, SysFontsPath;
    
    String GetDefaultFaceName(void);
    void RefreshFontList(void);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
