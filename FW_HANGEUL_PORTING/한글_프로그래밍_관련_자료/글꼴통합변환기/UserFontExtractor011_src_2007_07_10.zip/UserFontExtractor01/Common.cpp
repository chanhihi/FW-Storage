//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include <dir.h>
#include "Common.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
int ShowErrorMessage(String AErrorMsg)
{
    return MessageDlg(AErrorMsg, mtError, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------
String ExtractFileNameOnly(String AFileName)
{
    AFileName = ExtractFileName(AFileName);

    int Len = AFileName.LastDelimiter(".") - 1;
    AFileName.SetLength(Len);

    return AFileName;
}
//---------------------------------------------------------------------------
String GetTempPathName(void)
{
    char TempPath[MAX_PATH];
    GetTempPath(MAX_PATH, TempPath);

    return String(TempPath) + "UFE01\\";
}
//---------------------------------------------------------------------------
String GetSysFontsPath(void)
{
    char SysRootPath[50];
    GetEnvironmentVariable("SystemRoot", SysRootPath, 50);

    return (String(SysRootPath) + "\\Fonts");
}
//---------------------------------------------------------------------------
void OpenSysFontsFolderMinimize(void)
{
    String s =  GetSysFontsPath();
    ShellExecute(0, NULL, s.c_str(), NULL, NULL, SW_MINIMIZE);
}
//---------------------------------------------------------------------------
void OpenSysFontsFolderShow(void)
{
    String s =  GetSysFontsPath();
    ShellExecute(0, NULL, s.c_str(), NULL, NULL, SW_SHOW);
}
//---------------------------------------------------------------------------
bool isFixedFont(TFont *AFont, TPaintBox *APaintBox)
{
    bool result;
    TTextMetric TextMetric1;

    String FontName = AFont->Name;
    FontName.SetLength(LF_FACESIZE + 1); // LF_FACESIZE = 32
    APaintBox->Canvas->Font->Assign(AFont);
    GetTextFace(APaintBox->Canvas->Handle, LF_FACESIZE - 1, FontName.c_str());
    GetTextMetrics(APaintBox->Canvas->Handle, &TextMetric1);

    if ((TextMetric1.tmPitchAndFamily & TMPF_FIXED_PITCH) == TMPF_FIXED_PITCH)
        result = false;
    else
        result = true;

    return result;
}
//---------------------------------------------------------------------------
void ShellExec(String AFileName)
{
    HINSTANCE hInstance1 = ShellExecute(Application->Handle, "", AFileName.c_str(), "", NULL, SW_SHOWNORMAL);
    if ((int)hInstance1 <= 32)
        {ShowErrorMessage("���� ������ �����ϴ� �� ������ �߻��Ͽ����ϴ�!\n\n" + AFileName); return;}
}
//---------------------------------------------------------------------------
void WaitFor(void *processHandle)
{
    TMsg msg;
    DWORD ret;

    do {
        ret = MsgWaitForMultipleObjects(1, (void * const *)&processHandle, false, INFINITE, QS_PAINT | QS_SENDMESSAGE);
        if (ret == WAIT_FAILED) return;
        if (ret == (WAIT_OBJECT_0 + 1))
            while (PeekMessage(&msg, 0, WM_PAINT, WM_PAINT, PM_REMOVE)) DispatchMessage(&msg);
    } while (ret != WAIT_OBJECT_0);
}

DWORD winexecAndWait32V2(char *FileName, int Visibility)
{
	char zAppName[512];
	TStartupInfo StartupInfo;
	TProcessInformation ProcessInfo;
	ULONG ret = -1;

	strcpy(zAppName, FileName);
	ZeroMemory(&StartupInfo, sizeof(StartupInfo));
	StartupInfo.cb = sizeof(StartupInfo);
	StartupInfo.dwFlags = STARTF_USESHOWWINDOW;
	StartupInfo.wShowWindow = Visibility;
	if (!CreateProcess(NULL, zAppName, NULL, NULL, false, CREATE_NEW_CONSOLE | NORMAL_PRIORITY_CLASS,
        NULL, NULL, &StartupInfo, &ProcessInfo)) return -1;
	else {
		WaitFor(ProcessInfo.hProcess);
		GetExitCodeProcess(ProcessInfo.hProcess, &ret);
		CloseHandle(ProcessInfo.hProcess);
		CloseHandle(ProcessInfo.hThread);
	}
	return ret;
}
//---------------------------------------------------------------------------
void GetAllFile(TStringList *strlstFileName, AnsiString strPath)
{
    // �������� ��� ȭ���̸� ���
    TSearchRec sr;
    try {
        if (FindFirst(strPath + "*.*", faAnyFile, sr) == 0) {
            do {
                if (sr.Name != "." && sr.Name != ".." && sr.Attr != faDirectory) strlstFileName->Add(strPath + sr.Name);
            } while (FindNext(sr) == 0);
        }
    } __finally {
        FindClose(sr);
    }
}
void GetDescendantDir(TStringList *strlstDirNames, AnsiString strPath)
{
    // �θ� �������� ��� �ڽ����� �̸� ��� (��� ȣ��)
    TSearchRec sr;
    try {
        if (FindFirst(strPath + "*.*", faAnyFile, sr) ==0 ) {
            do {
                if (sr.Name != "." && sr.Name != ".." && sr.Attr == faDirectory) {
                    strlstDirNames->Add(strPath + sr.Name + "\\");
                    GetDescendantDir(strlstDirNames, strPath + sr.Name + "\\");
                }
            } while(FindNext(sr) == 0);
        }
    } __finally {
        FindClose(sr);
    }
}
void DeleteDir(AnsiString strPath)
{
    //  GetDescendantDir�� GetAllFile�� �̿��ؼ� ���丮�� �����.
    TStringList *strlstDescPath = new TStringList;
    TStringList *strlstFileName = new TStringList;
    try {
        strlstDescPath->Add(strPath);
        GetDescendantDir(strlstDescPath, strPath);
        while (strlstDescPath->Count) {
            GetAllFile(strlstFileName, strlstDescPath->Strings[strlstDescPath->Count-1]);
            while (strlstFileName->Count) {
                DeleteFile(strlstFileName->Strings[0]);
                strlstFileName->Delete(0);
            }
            RemoveDir(strlstDescPath->Strings[strlstDescPath->Count-1]);
            strlstDescPath->Delete(strlstDescPath->Count-1);
        }
    } __finally {
        delete strlstDescPath;
        delete strlstFileName;
    }
}
//---------------------------------------------------------------------------
#include "..\GetFontFileInfo\GetFontFile.h"
String GetFontFileName(String AFontName)
{
	String DisplayName, FontFileName;

	if (GetFontFile(AFontName.c_str(), DisplayName, FontFileName)) return FontFileName;

    return "";
}
//---------------------------------------------------------------------------

