//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include "BDFToTTF.h"
#include "Common.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
void SaveTTFInfoFile(String ASaveFileName, TTTFIniInfo *ATTFIniInfo)
{
    String s =
        "Copyright = "		+ ATTFIniInfo->ACopyright   + "\n" +
        "Fontname = "		+ ATTFIniInfo->AFontname    + "\n" +
        "Version = "		+ ATTFIniInfo->AVersion     + "\n" +
        "Trademark = "		+ ATTFIniInfo->ATrademark   + "\n" +
        "CopyrightCP = "	+ ATTFIniInfo->ACopyrightCP + "\n" +
        "FontnameCP = "     + ATTFIniInfo->AFontnameCP  + "\n" +
        "TrademarkCP = "	+ ATTFIniInfo->ATrademarkCP;

    s = AnsiToUtf8(s);

    FILE *fp = fopen(ASaveFileName.c_str(), "wb");
    fwrite(s.c_str(), strlen(s.c_str()), 1, fp);
    fclose(fp);
}
//---------------------------------------------------------------------------
#include "..\bdf2ttf20\main.h"
String ConvertBDF2TTF(String ASaveTTFName, String ALoadBDFName, String AFontName, String AFontVer, String ACopyright)
{
    if (AFontName.Length() > 32) AFontName.SetLength(32);

    TTTFIniInfo TTFIniInfo1;
    TTFIniInfo1.ACopyright = ACopyright;
    TTFIniInfo1.AFontname = AFontName;
    TTFIniInfo1.AVersion = AFontVer;

    String SaveIniName = GetTempPathName() + ExtractFileName(ASaveTTFName) + ".ini";
    SaveTTFInfoFile(SaveIniName, &TTFIniInfo1);

    char *argv[6];
    argv[0] = "bdf2ttf.exe";
    argv[1] = ASaveTTFName.c_str();
    argv[2] = SaveIniName.c_str();
    argv[3] = ALoadBDFName.c_str();
    argv[4] = NULL;
    argv[5] = NULL;

    int result = bdf2ttf_main(4, argv);
    if (result == EXIT_FAILURE) return (String)_bdf2ttf_msg;

    return "";
}
//---------------------------------------------------------------------------

