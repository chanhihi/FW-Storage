//---------------------------------------------------------------------------
#ifndef CommonH
#define CommonH
//---------------------------------------------------------------------------
int     ShowErrorMessage(String AErrorMsg);
String  ExtractFileNameOnly(String AFileName);
String  GetTempPathName(void);
String  GetSysFontsPath(void);
void    OpenSysFontsFolderMinimize(void);
void    OpenSysFontsFolderShow(void);
bool    isFixedFont(TFont *AFont, TPaintBox *APaintBox);
void    ShellExec(String AFileName);
DWORD   winexecAndWait32V2(char *FileName, int Visibility);
void    DeleteDir(AnsiString strPath);
String  GetFontFileName(String AFontName);
//---------------------------------------------------------------------------
#endif

