//---------------------------------------------------------------------------
#ifndef BDFToTTFH
#define BDFToTTFH
//---------------------------------------------------------------------------
typedef struct {
    String ACopyright;
    String AFontname;
    String AVersion;
    String ATrademark;
    String ACopyrightCP;
    String AFontnameCP;
    String ATrademarkCP;
} TTTFIniInfo;

String  GetBDFProperty(String ABDFFileName, String AProperty);
char    *GetFontNameFromTTF(char *AFontName, char *ATTFFileName);
String  GetTTFFontName(String ATTFFileName);
bool    SaveTTFInfoFile(String ASaveFileName, TTTFIniInfo *ATTFIniInfo);    // 0.54 ���� : void -> bool
String  ConvertBDF2TTF(String ATTFFileName, String ABDFFileName);
//---------------------------------------------------------------------------
#endif
