//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "..\hanlib\hanlib.h"
#include "..\johab2uni\johab2uni.h"
#include "Common.h"
#include "JohabToUni.h"
#include "BDFToBMP.h"
#include "BDFToTTF.h"

#include "Fnt2BDFFrameUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "BrowseDr"
#pragma resource "*.dfm"
TFnt2BDFFrame *Fnt2BDFFrame;
//---------------------------------------------------------------------------
__fastcall TFnt2BDFFrame::TFnt2BDFFrame(TComponent* Owner)
    : TFrame(Owner)
{
}
//---------------------------------------------------------------------------
void TFnt2BDFFrame::InitPreviewFrame()
{
    SourceList = new TStringList();
    SourceList->Sorted = true;
    SourceList2 = new TStringList();
    SourceList2->Sorted = true;

    dfsBrowseDirectoryDlg1->Selection = ExtractFilePath(Application->ExeName);
    lbe_CurPath->Text = ExtractFilePath(Application->ExeName);
    lbe_SavePath->Text = ExtractFilePath(Application->ExeName);
    lbe_SavePath->Hint = lbe_SavePath->Text;

    RefreshFileList();
}
//---------------------------------------------------------------------------
void TFnt2BDFFrame::RefreshFileList()
{
    if (rb_HanFontOnly->Checked)        {GetFileList(lv_FileList, lbe_CurPath->Text, "", BitmapHanFontFilesSize);   return;}
    if (rb_EngFontOnly->Checked)        {GetFileList(lv_FileList, lbe_CurPath->Text, "", BitmapEngFontFilesSize);   return;}
    if (rb_SpcFontOnly->Checked)        {GetFileList(lv_FileList, lbe_CurPath->Text, "", BitmapSpcFontFilesSize);   return;}
    if (rb_HanjaFontOnly->Checked)      {GetFileList(lv_FileList, lbe_CurPath->Text, "", BitmapHanjaFontFilesSize); return;}
    if (rb_BDFOnly->Checked)            {GetFileList(lv_FileList, lbe_CurPath->Text, ";.bdf;", "");                 return;}
    if (rb_BMPOnly->Checked)            {GetFileList(lv_FileList, lbe_CurPath->Text, ";.bmp;", "");                 return;}
    if (rb_TTFOnly->Checked)            {GetFileList(lv_FileList, lbe_CurPath->Text, ";.ttf;", "");                 return;}
    if (rb_ViewAllFiles->Checked)       {GetFileList(lv_FileList, lbe_CurPath->Text, "", "");                       return;}
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::btn_SelFontPathClick(TObject *Sender)
{
    dfsBrowseDirectoryDlg1->Selection = lbe_CurPath->Text;
    if (dfsBrowseDirectoryDlg1->Execute()) {
        if (dfsBrowseDirectoryDlg1->Selection == "") return;
        lbe_CurPath->Text = dfsBrowseDirectoryDlg1->Selection;
        lbe_CurPath->Text = AddPathDelimiter(lbe_CurPath->Text);
        lbe_CurPath->Hint = lbe_CurPath->Text;

        RefreshFileList();
    }
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::btn_SavePathClick(TObject *Sender)
{
    dfsBrowseDirectoryDlg1->Selection = lbe_SavePath->Text;
    if (dfsBrowseDirectoryDlg1->Execute()) {
        if (dfsBrowseDirectoryDlg1->Selection == "") return;
        lbe_SavePath->Text = dfsBrowseDirectoryDlg1->Selection;
        lbe_SavePath->Text = AddPathDelimiter(lbe_SavePath->Text);
        lbe_SavePath->Hint = lbe_SavePath->Text;
    }
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::btn_AddToSrcList1Click(TObject *Sender)
{
    for (int i = 0; i < lv_FileList->Items->Count; i++) {
        if (lv_FileList->Items->Item[i]->Selected) {
            String FileName = lv_FileList->Items->Item[i]->Caption;
            int FileSize = RemoveComma(lv_FileList->Items->Item[i]->SubItems->Strings[0]);
            if (IsHanFontSize(FileSize))
                SourceList->Add(lbe_CurPath->Text + FileName + "|" + InsertComma(FileSize));
            else if (IsEngFontSize(FileSize)) {
                String FullPath = lbe_CurPath->Text + FileName;
                if (IsSamboSpcFont(FullPath.c_str())) {
                    ShowMessage2(FileName + "�� �ﺸ Ư������ �۲��Դϴ�. (�̸����⸸ ����)");
                    continue;
                }
                SourceList->Add(lbe_CurPath->Text + FileName + "|" + InsertComma(FileSize));
            }
        }
    }

    lv_SrcList1->Items->BeginUpdate();
    lv_SrcList1->Items->Clear();
    for (int i = 0; i < SourceList->Count; i++) {
        String s = SourceList->Strings[i];
        int SepIndex = s.Pos("|");
        String FullPath = s.SubString(1, SepIndex - 1);
        String FileSize = s.SubString(SepIndex + 1, s.Length());
        String FileName = ExtractFileName(FullPath);

        TListItem *ListItem1 = lv_SrcList1->Items->Add();
        ListItem1->Caption = FileName;
        ListItem1->SubItems->Add(FileSize);
        ListItem1->SubItems->Add(FullPath);
    }
    lv_SrcList1->Items->EndUpdate();
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::btn_DeleteSrcList1Click(TObject *Sender)
{
    lv_SrcList1->Items->BeginUpdate();
    while (lv_SrcList1->SelCount)
        lv_SrcList1->Items->Delete(lv_SrcList1->Selected->Index);
    lv_SrcList1->Items->EndUpdate();

    SourceList->Clear();
    for (int i = 0; i < lv_SrcList1->Items->Count; i++) {
        String FullPath = lv_SrcList1->Items->Item[i]->SubItems->Strings[1];
        String FileSize = lv_SrcList1->Items->Item[i]->SubItems->Strings[0];
        SourceList->Add(FullPath + "|" + FileSize);
    }
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::btn_AddToSrcList2Click(TObject *Sender)
{
    if (lv_FileList->SelCount == 0) return;

    TListItem *ListItem1, *ListItem2;

    for (int i = 0; i < lv_FileList->Items->Count; i++) {
        if (lv_FileList->Items->Item[i]->Selected) {
            ListItem1 = lv_FileList->Items->Item[i];
            String FileName = ListItem1->Caption;
            int FileSize = RemoveComma(ListItem1->SubItems->Strings[0]);
            String FullPath = lbe_CurPath->Text + FileName;

            if (IsEngFontSize(FileSize)) {
                if ((FileSize == 4096) && (IsSamboSpcFont(FullPath.c_str()))) {
                    ShowMessage2(FileName + "�� �ﺸ Ư������ �۲��Դϴ�. (�̸����⸸ ����)");
                    return;
                } else ListItem2 = lv_SrcList2->Items->Item[0];
            }
            else if (IsHanFontSize(FileSize)) ListItem2 = lv_SrcList2->Items->Item[1];
            else if (IsSpcFontSize(FileSize)) ListItem2 = lv_SrcList2->Items->Item[2];
            else if (IsHanjaFontSize(FileSize)) ListItem2 = lv_SrcList2->Items->Item[3];
            else continue;

            ListItem2->Caption = FileName;
            ListItem2->SubItems->Strings[0] = InsertComma(FileSize);
            ListItem2->SubItems->Strings[1] = FullPath;
        }
    }
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::btn_DeleteSrcList2Click(TObject *Sender)
{
    for (int i = 0; i < lv_SrcList2->Items->Count; i++) {
        if (lv_SrcList2->Items->Item[i]->Selected) {
            lv_SrcList2->Items->Item[i]->Caption = "";
            lv_SrcList2->Items->Item[i]->SubItems->Strings[0] = "";
            lv_SrcList2->Items->Item[i]->SubItems->Strings[1] = "";
        }
    }
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::lv_SrcList1DblClick(TObject *Sender)
{
    if (lv_SrcList1->SelCount != 1) return;

    int FileSize = RemoveComma(lv_SrcList1->Selected->SubItems->Strings[0]);
    String FileName = lv_SrcList1->Selected->SubItems->Strings[1];

    PreviewFrame1->pg_Char16x->ActivePageIndex = 1;
    PreviewFrame1->PreviewBitmapFont(FileName, FileSize);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::lv_SrcList2DblClick(TObject *Sender)
{
    if (lv_SrcList2->SelCount != 1) return;

    int FileSize = RemoveComma(lv_SrcList2->Selected->SubItems->Strings[0]);
    String FileName = lv_SrcList2->Selected->SubItems->Strings[1];

    PreviewFrame1->pg_Char16x->ActivePageIndex = 1;
    PreviewFrame1->PreviewBitmapFont(FileName, FileSize);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::lv_FileListDblClick(TObject *Sender)
{
    if (lv_FileList->SelCount != 1) return;

    String FullPath = lbe_CurPath->Text + lv_FileList->Selected->Caption;
    int FileSize = RemoveComma(lv_FileList->Selected->SubItems->Strings[0]);
    String FileExt = lv_FileList->Selected->SubItems->Strings[1];

    if ((IsBitmapFontSize(FileSize)) || (FileExt.UpperCase() == ".BMP"))
        PreviewFrame1->PreviewBitmapFont(FullPath, FileSize);
    else ShellExec(FullPath);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::mi_DeleteSourceListClick(TObject *Sender)
{
    btn_DeleteSrcList1Click(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::mi_SelectSourceListAllClick(TObject *Sender)
{
    lv_SrcList1->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::mi_DeleteDefaultFontListClick(TObject *Sender)
{
    btn_DeleteSrcList2Click(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::mi_SelectDefaultFontListAllClick(TObject *Sender)
{
    lv_SrcList2->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::mi_AddFontListClick(TObject *Sender)
{
    btn_AddToSrcList1Click(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::mi_DeleteFontListClick(TObject *Sender)
{
    btn_AddToSrcList2Click(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::mi_SelectFileListAllClick(TObject *Sender)
{
    lv_FileList->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::lv_SrcList1KeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{
    if (Key == VK_RETURN) lv_SrcList1DblClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::lv_SrcList2KeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{
    if (Key == VK_RETURN) lv_SrcList1DblClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::lv_FileListKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{
    if (Key == VK_RETURN) lv_FileListDblClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::bitbtn_StopConvertingClick(TObject *Sender)
{
    if (ShowYesNoMsgDlg("��ȯ�� �ߴ��Ͻðڽ��ϱ�?") == mrYes) {
        _IsWorking = false;
        ShowErrorMessage("�۾��� �ߴ��Ͽ����ϴ�!");
        mm_ProgressMsg->Lines->Add("\r\n\r\n�������۾��� �ߴ��Ͽ����ϴ�!\r\n\r\n");
        return;
    }
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::bitbtn_ConvertToBDFClick(TObject *Sender)
{
    BitmapFontToBDF(".bdf");
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::bitbtn_ConvertToBMPClick(TObject *Sender)
{
    BitmapFontToBDF(".bmp");
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::bitbtn_ConvertToTTFClick(TObject *Sender)
{
    BitmapFontToBDF(".ttf");
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::bitbtn_HelpClick(TObject *Sender)
{
    ShowMessage2(
        "���� ������ �۲��� �����մϴ�.\n\n"

        "- 10x4x4 �۲�: 12,800 byte\n"
        "- 10x4x4 �Ѷ����� �۲�: 12,224 byte\n"
        "- 8x4x4 ������ �۲�: 11,520 byte\n"
        "- 8x4x4 �Ѷ����� �۲�: 11,008 byte\n"
        "- 8x4x4 �̾߱� 6.0 �۲�: 12,800 byte\n"
        "- 8x4x4 �̾߱� 6.1 �̻��� �۲� : 13,056 byte\n"
        "- 6x2x1 �۲�: 6,176 byte\n"
        "- 2x1x2 �۲�: 3,776 byte\n"
        "- 2x1x2 �Ѷ����� �۲�: 3,616 byte\n\n"

        "- ����128 �۲�: 2,048 byte (ASCII 0~127 �Ǵ� 128~255)\n"
        "- ����256 �۲�: 4,096 byte (ASCII 0~255)\n"
        "- �Ѹ� ����256 �۲�: 4,112 byte (ASCII 0~255)\n\n"

        "- KS, KSSM Ư������ �۲�: 36,096 byte, 33,696 byte\n"
        "- �ﺸ Ư������ �۲� : 4,096 byte (�̸����⸸ ����)\n"
        "- ǥ������: 156,416 byte\n\n"

        "�� iso10646-1 Encoding���� ��ȯ�� KSƯ�����ڴ� 1128���߿���\n"
        "    140���� ���鹮�ڸ� ������ 988�ڰ� ���Ե˴ϴ�."
    );

}
//---------------------------------------------------------------------------
void TFnt2BDFFrame::DisableUserInput()
{
    pn_FontPath->Enabled = false;
    pn_SrcList->Enabled = false;
    pn_AddOrDeleteSrcList->Enabled = false;
    lv_FileList->Enabled = false;
    gb_SelectListType->Enabled = false;
    cbx_Encoding->Enabled = false;

    bitbtn_AboutBDF2BMP->Enabled = false;
    bitbtn_AboutBDF2TTF->Enabled = false;
    bitbtn_BDF2BMP->Enabled = false;
    bitbtn_BDF2TTF->Enabled = false;
    bitbtn_ConvertToBDF->Enabled = false;
    bitbtn_ConvertToBMP->Enabled = false;
    bitbtn_ConvertToTTF->Enabled = false;

    pn_SavePath->Enabled = false;
    mm_ProgressMsg->Enabled = false;

    spl_SrcList->Enabled = false;
    spl_FontList->Enabled = false;
    spl_ProgressMsg->Enabled = false;

    PreviewFrame1->Enabled = false;

    bitbtn_StopConverting->Enabled = true;
}
//---------------------------------------------------------------------------
void TFnt2BDFFrame::EnableUserInput()
{
    pn_FontPath->Enabled = true;
    pn_SrcList->Enabled = true;
    pn_AddOrDeleteSrcList->Enabled = true;
    lv_FileList->Enabled = true;
    gb_SelectListType->Enabled = true;
    cbx_Encoding->Enabled = true;

    bitbtn_AboutBDF2BMP->Enabled = true;
    bitbtn_AboutBDF2TTF->Enabled = true;
    bitbtn_BDF2BMP->Enabled = true;
    bitbtn_BDF2TTF->Enabled = true;
    bitbtn_ConvertToBDF->Enabled = true;
    bitbtn_ConvertToBMP->Enabled = true;
    bitbtn_ConvertToTTF->Enabled = true;

    pn_SavePath->Enabled = true;
    mm_ProgressMsg->Enabled = true;

    spl_SrcList->Enabled = true;
    spl_FontList->Enabled = true;
    spl_ProgressMsg->Enabled = true;

    PreviewFrame1->Enabled = true;

    bitbtn_StopConverting->Enabled = false;
}
//---------------------------------------------------------------------------
void TFnt2BDFFrame::BitmapFontToBDF(String ATarget)
{
    int Count = 0, Result, SrcFileSize;
    String SrcFileName, FileNameOnly, SaveName, s;
    String DefEngFontFileName, EngFontFileName = "";
    String DefHanFontFileName, HanFontFileName = "";
    String DefSpcFontFileName, DefHanjaFontFileName;
    //--------------------------------------------------------------------------
    if (lv_SrcList1->Items->Count == 0)
        {ShowMessage2("��ȯ�� �۲��� ���� ��Ͽ� �߰��ϼ���!"); return;}
    //--------------------------------------------------------------------------
    for (int i = 0; i < lv_SrcList1->Items->Count; i++) {
        SrcFileSize = RemoveComma(lv_SrcList1->Items->Item[i]->SubItems->Strings[0]);
        if (!CheckEncoding(SrcFileSize, cbx_Encoding->Text)) {
            ShowErrorMessage(
                "��ȯ�� �۲� ��Ͽ� " + cbx_Encoding->Text + "���� ��ȯ�� �� ���� �۲��� �ֽ��ϴ�.\n\n"
                "��ȯ�� �۲� ������ Encoding�� Ȯ���ϼ���!"
            );
            return;
        }
    }
    //--------------------------------------------------------------------------
    s = IntToStr(lv_SrcList1->Items->Count) + "���� �۲��� "
        + cbx_Encoding->Text + " Encoding�� " + ATarget + "�� ��ȯ�Ͻðڽ��ϱ�?";
    if (ShowYesNoMsgDlg(s) == mrNo) return;
    //--------------------------------------------------------------------------
    _IsWorking = true;
    DisableUserInput();
    //--------------------------------------------------------------------------
    DefEngFontFileName = lv_SrcList2->Items->Item[0]->SubItems->Strings[1];
    DefHanFontFileName = lv_SrcList2->Items->Item[1]->SubItems->Strings[1];
    DefSpcFontFileName = lv_SrcList2->Items->Item[2]->SubItems->Strings[1];
    DefHanjaFontFileName = lv_SrcList2->Items->Item[3]->SubItems->Strings[1];

    for (int i = 0; i < lv_SrcList1->Items->Count; i++) {
        SrcFileName = lv_SrcList1->Items->Item[i]->SubItems->Strings[1];
        SrcFileSize = RemoveComma(lv_SrcList1->Items->Item[i]->SubItems->Strings[0]);
        if (IsEngFontSize(SrcFileSize)) {
            EngFontFileName = SrcFileName;
            HanFontFileName = DefHanFontFileName;
        } else {
            EngFontFileName = DefEngFontFileName;
            HanFontFileName = SrcFileName;
        }
        //----------------------------------------------------------------------
        FileNameOnly = ExtractFileNameOnly(SrcFileName);
        SaveName = lbe_SavePath->Text + FileNameOnly + "-" + cbx_Encoding->Text + ".bdf";
        AddBDFCnvtMsg(mm_ProgressMsg, cbx_Encoding->Text, SaveName, EngFontFileName, HanFontFileName, DefSpcFontFileName, DefHanjaFontFileName, i + 1, lv_SrcList1->Items->Count);

        s = ConvertJohab2Uni(cbx_Encoding->Text, SaveName, EngFontFileName, HanFontFileName, DefSpcFontFileName, DefHanjaFontFileName);
        if (s != "") {s += ("\n\n" + ExtractFileName(SrcFileName)); goto Error1;}

        if (!_IsWorking) goto End1; // "�ߴ��ϱ�" ��ư�� ������ ��
        //----------------------------------------------------------------------
        if (ATarget != ".bdf") {
            SrcFileName = SaveName;
            SaveName = lbe_SavePath->Text + ExtractFileNameOnly(SrcFileName) + ATarget;
        }
        if (ATarget == ".bmp") {
            AddCnvtMsg(mm_ProgressMsg, SaveName, SrcFileName, i + 1, lv_SrcList1->Items->Count);
            s = ConvertBDF2BMP(SaveName, SrcFileName);
            if (s != "") goto Error1;
        } else if (ATarget == ".ttf") {
            AddCnvtMsg(mm_ProgressMsg, SaveName, SrcFileName, i + 1, lv_SrcList1->Items->Count);
            s = ConvertBDF2TTF(SaveName, SrcFileName);
            if (s != "") goto Error1;
        }
        if (!_IsWorking) goto End1; // "�ߴ��ϱ�" ��ư�� ������ ��
        //----------------------------------------------------------------------
        mm_ProgressMsg->Lines->Add("----------------------------------------------------------------------------------------------------");
        Count++;
    }
    s = AddResultMsg(mm_ProgressMsg, ATarget, "��Ʈ�� �۲�", Count);
    ShowMessage(s);
    goto End1;
Error1:
    s = AddErrorMsg(mm_ProgressMsg, s);
    ShowErrorMessage(s);
End1:
    EnableUserInput();
    _IsWorking = false;
}
//---------------------------------------------------------------------------
void TFnt2BDFFrame::ConvertBDF(String ATarget)
{
    int SelListCount, ID, Count = 0;
    String LoadFileName, FileNameOnly, SaveFileName, s;

    SelListCount = GetSelectedListCount(lv_FileList, ".bdf");
    if (SelListCount == 0) {ShowMessage2("���� ��Ͽ��� ��ȯ�� .bdf ������ ��� �����ϼ���!"); return;}

    ID = ShowYesNoMsgDlg(IntToStr(SelListCount) + "���� .bdf�� " + ATarget + "�� ��ȯ�ұ��?");
    if (ID == mrNo) return;
    //--------------------------------------------------------------------------
    _IsWorking = true;
    DisableUserInput();
    //--------------------------------------------------------------------------
    GetSelectedListItems(SourceList2, lv_FileList, lbe_CurPath->Text, ".bdf");
    for (int i = 0; i < SourceList2->Count; i++) {
        LoadFileName = SourceList2->Strings[i];
        FileNameOnly = ExtractFileNameOnly(LoadFileName);
        SaveFileName = lbe_SavePath->Text + FileNameOnly + ATarget;

        AddCnvtMsg(mm_ProgressMsg, SaveFileName, LoadFileName, i + 1, SourceList2->Count);
        mm_ProgressMsg->Lines->Add("----------------------------------------------------------------------------------------------------");

        if (ATarget == ".bmp")
            s = ConvertBDF2BMP(SaveFileName, LoadFileName);
        else if (ATarget == ".ttf")
            s = ConvertBDF2TTF(SaveFileName, LoadFileName);
        if (s != "") goto Error2;

        Count++;
        if (!_IsWorking) goto End2; // "�ߴ��ϱ�" ��ư�� ������ ��
    }
    //--------------------------------------------------------------------------
    s = AddResultMsg(mm_ProgressMsg, ATarget, ".bdf", Count);
    ShowMessage(s);
    goto End2;
Error2:
    s = AddErrorMsg(mm_ProgressMsg, s);
    ShowErrorMessage(s);
End2:
    EnableUserInput();
    _IsWorking = false;
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::pn_AddOrDeleteSrcListResize(TObject *Sender)
{
    btn_AddToSrcList1->Top = (lv_SrcList1->Height -
        (btn_AddToSrcList1->Height + btn_DeleteSrcList1->Height)) / 2;
    btn_DeleteSrcList1->Top = btn_AddToSrcList1->Top + btn_AddToSrcList1->Height;

    btn_AddToSrcList2->Top = lv_SrcList2->Top;
    btn_DeleteSrcList2->Top = btn_AddToSrcList2->Top + btn_AddToSrcList2->Height;
}
//---------------------------------------------------------------------------
void TFnt2BDFFrame::AddBDFCnvtMsg(TMemo *AMemo, String AEncoding,
    String AOutputName, String AEngFontFileName, String AHanFontFileName, String ASpcFontFileName, String AHanjaFontFileName, int ACurIndex, int ATotalCount)

{
    String s = "";
    if (AEncoding == "iso10646-1") {
        if (AEngFontFileName != "")   s = s + ExtractFileName(AEngFontFileName)   + " + ";
        if (AHanFontFileName != "")   s = s + ExtractFileName(AHanFontFileName)   + " + ";
        if (ASpcFontFileName != "")   s = s + ExtractFileName(ASpcFontFileName)   + " + ";
        if (AHanjaFontFileName != "") s = s + ExtractFileName(AHanjaFontFileName) + " + ";
    } else if (AEncoding == "iso8859-1") {
        if (AEngFontFileName != "") s = s + ExtractFileName(AEngFontFileName) + " + ";
    } else if (AEncoding == "johab844-1") {
        if (AHanFontFileName != "") s = s + ExtractFileName(AHanFontFileName) + " + ";
    } else if (AEncoding.Pos("ksc5601.1987")) {
        if (AHanFontFileName != "")   s = s + ExtractFileName(AHanFontFileName)   + " + ";
        if (ASpcFontFileName != "")   s = s + ExtractFileName(ASpcFontFileName)   + " + ";
        if (AHanjaFontFileName != "") s = s + ExtractFileName(AHanjaFontFileName) + " + ";
    }
    s.SetLength(s.Length() - 3);
    s = s + " �� " + ExtractFileName(AOutputName) + " ��ȯ�ϴ� ��.....";
    s = s + "(" + IntToStr(ACurIndex) + " / " + IntToStr(ATotalCount) + ")";

    AMemo->Lines->Add(s);
    Application->ProcessMessages();
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::sbtn_RefreshFileListClick(TObject *Sender)
{
    RefreshFileList();
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::bitbtn_BDF2BMPClick(TObject *Sender)
{
    ConvertBDF(".bmp");
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::bitbtn_BDF2TTFClick(TObject *Sender)
{
    ConvertBDF(".ttf");
}
//---------------------------------------------------------------------------
bool TFnt2BDFFrame::CheckEncoding(int AFontFileSize, String AEncoding)
{
    if (AEncoding == "iso10646-1")
        return IsBitmapFontSize(AFontFileSize);
    else if (AEncoding == "iso8859-1")
        return IsEngFontSize(AFontFileSize);
    else if (AEncoding == "johab844-1")
        return IsHanFontSize(AFontFileSize);
    else if (AEncoding.Pos("ksc5601.1987")) {
        if (IsHanFontSize(AFontFileSize)) return true;
        if (IsSpcFontSize(AFontFileSize)) return true;
        if (IsHanjaFontSize(AFontFileSize)) return true;
    }

    return false;
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::mi_PreviewFontClick(TObject *Sender)
{
    lv_FileListDblClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::bitbtn_AboutBDF2BMPClick(TObject *Sender)
{
    ShowMessage2("bdf2bmp 0.6 - output all glyphs in a bdf-font to a bmp-image-file\n"
        "author:  ITOU Hiroki (itouh@lycos.ne.jp)");
}
//---------------------------------------------------------------------------
void __fastcall TFnt2BDFFrame::bitbtn_AboutBDF2TTFClick(TObject *Sender)
{
    ShowMessage2("BDF to TTF converter 2.0 (http://kaoriya.net)\n"
        "Written By: MURAOKA Taro <koron@tka.att.ne.jp>");
}
//---------------------------------------------------------------------------
