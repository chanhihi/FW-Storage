//---------------------------------------------------------------------------
#ifndef JohabToUniH
#define JohabToUniH
//---------------------------------------------------------------------------
String ConvertJohab2Uni(String AEncoding, String AOutputName, String AEngFontFileName, String AHanFontFileName, String ASpcFontFileName, String AHanjaFontFileName);
//---------------------------------------------------------------------------
#endif
