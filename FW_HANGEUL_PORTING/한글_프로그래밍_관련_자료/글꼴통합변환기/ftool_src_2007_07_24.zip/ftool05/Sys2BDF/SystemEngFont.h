//---------------------------------------------------------------------------
#ifndef SystemEngFontH
#define SystemEngFontH
//---------------------------------------------------------------------------
bool SysEngFontToBDFBody(String ASaveFileName, String AWriteMode, TFont *AFont, TTextMetric *ATextMetric, bool AEndFont);
bool SysEngFontToBDF(String ASaveFileName, String AWriteMode, TFont *AFont, TTextMetric *ATextMetric);
//---------------------------------------------------------------------------
#endif
