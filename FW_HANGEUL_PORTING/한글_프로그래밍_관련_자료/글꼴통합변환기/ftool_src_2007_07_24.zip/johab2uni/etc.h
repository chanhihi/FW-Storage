//---------------------------------------------------------------------------
#ifndef __etc_h
#define __etc_h
//---------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//---------------------------------------------------------------------------
char *ExtractFileName(char *AFullPath);
char *ExtractFileExt(char *filename);
char *ExtractFileNameOnly(char *AFullPath);
bool IsEngFont(int ASize);
bool IsHanFont(int ASize);
bool IsSpcFont(int ASize);
bool IsHanjaFont(int ASize);
void HyphenToUnderline(char *s);
bool ishangul1st(byte *s, int pos);
bool ishangul2nd(byte *s, int pos);
char *replaceAll(char *result, char *s, const char *olds, const char *news);
void RemoveEncodingStr(char *s);
//---------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif
//---------------------------------------------------------------------------
#endif
