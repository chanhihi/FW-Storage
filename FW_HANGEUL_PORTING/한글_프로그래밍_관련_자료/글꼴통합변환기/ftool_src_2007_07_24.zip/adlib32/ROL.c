#ifdef __BORLANDC__
#pragma warn -8080
#pragma warn -8004
#endif

#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include "rol.h"
#include "player.h"


//------------------------------------------------------------------------------
// ������ ������ ũ�Ⱑ ROLFILE_MAXSIZE (1MB)�� �ʰ��� ���
// Adlib Visual Composor�� �ۼ��� �������� ROL ������
// �ƴ� ���ɼ��� ���ٰ� �����Ͽ� �ε� FAIL ó���� ��.
//------------------------------------------------------------------------------
#define ROLFILE_MAXSIZE	(1024 * 1024)	// == 1MB


//------------------------------------------------------------------------------
//	���� �Լ� ����
//------------------------------------------------------------------------------
static BOOL LoadFromROLFile(TROLFile *R);
static void FreeFromROLFile(TROLFile *R);
static BOOL LoadHeader(TROLFile *R);
static void LoadTempoEventsCount(TROLFile *R);
static BOOL LoadTempoEvents(TROLFile *R);
static void FreeTempoEvents(TROLFile *R);
static void LoadTimeOfLastNote(TROLFile *R, int voice);
static void LoadNoteDurationCount(TROLFile *R, int voice);
static BOOL LoadNoteDuration(TROLFile *R, int voice);
static void FreeNoteDuration(TROLFile *R, int voice);
static void LoadInstrEventsCount(TROLFile *R, int voice);
static BOOL LoadInstrEvents(TROLFile *R, int voice);
static void FreeInstrEvents(TROLFile *R, int voice);
static void LoadVolumeEventsCount(TROLFile *R, int voice);
static BOOL LoadVolumeEvents(TROLFile *R, int voice);
static void FreeVolumeEvents(TROLFile *R, int voice);
static void LoadPitchEventsCount(TROLFile *R, int voice);
static BOOL LoadPitchEvents(TROLFile *R, int voice);
static void FreePitchEvents(TROLFile *R, int voice);

static BOOL LoadUsedInstCount(TROLFile *R);
static void FreeUsedInstCount(TROLFile *R);
static BOOL LoadUsedInstName(TROLFile *R);
static void FreeUsedInstName(TROLFile *R);


//------------------------------------------------------------------------------
//	�ֿ� �Լ� ����
//------------------------------------------------------------------------------
TROLFile *LoadROLFile(char *ROLFileName)
{
	int i;
	TROLFile *R;

	R = (TROLFile *)malloc(sizeof(TROLFile));
	if (R == NULL) return NULL;

	memset(R, 0, sizeof(TROLFile));

	strcpy(R->FileName, ROLFileName);

	if (LoadFromROLFile(R) == FALSE) goto FAIL;
 	if (LoadHeader(R) == FALSE) goto FAIL;
	LoadTempoEventsCount(R);
	if (LoadTempoEvents(R) == FALSE) goto FAIL;

    R->VoiceCount = R->Header.SoundMode ? 11 : 9;
    R->TimeOfLastNote = 0;

	for (i = 0; i < R->VoiceCount; i++) {
		LoadTimeOfLastNote(R, i);
        LoadNoteDurationCount(R, i);
		if (LoadNoteDuration(R, i) == FALSE) goto FAIL;
		LoadInstrEventsCount(R, i);
		if (LoadInstrEvents(R, i) == FALSE) goto FAIL;
		LoadVolumeEventsCount(R, i);
		if (LoadVolumeEvents(R, i) == FALSE) goto FAIL;
		LoadPitchEventsCount(R, i);
		if (LoadPitchEvents(R, i) == FALSE) goto FAIL;
	}

   	if (!LoadUsedInstCount(R)) goto FAIL;
   	if (!LoadUsedInstName(R)) goto FAIL;

//SUCCESS:
	// ROL ������ �̻� ������ Ȯ���ϴ� ������ ����
	//if (CheckROLFileSize(R) == FALSE) goto FAIL;
 	return R;

FAIL:
	FreeROLFile(R);	// �Ҵ��� �޸� �ѹ�
	return NULL;
}
//------------------------------------------------------------------------------
void FreeROLFile(TROLFile *R)
{
	int i;

    if (R == NULL) return;

	FreeUsedInstName(R);
   	FreeUsedInstCount(R);

	for (i = R->VoiceCount - 1; i >= 0; i--) {
		FreePitchEvents(R, i);
		FreeVolumeEvents(R, i);
		FreeInstrEvents(R, i);
		FreeNoteDuration(R, i);
	}

	FreeTempoEvents(R);
	FreeFromROLFile(R);

	memset(R, 0, sizeof(TROLFile));
	free(R);
}
//------------------------------------------------------------------------------
//	���� �Լ� ����
//------------------------------------------------------------------------------
BOOL LoadFromROLFile(TROLFile *R)
{
	FILE *fp;

	fp = fopen(R->FileName, "rb");
	if (fp == NULL) return FALSE;

	fseek(fp, 0, SEEK_END);
	R->FileSize = ftell(fp);
    // ROLFILE_MAXSIZE == 1 MB
	if (R->FileSize > ROLFILE_MAXSIZE) {fclose(fp); return FALSE;}

	R->Raw = (BYTE *)malloc(R->FileSize);
	if (R->Raw == NULL) {fclose(fp); return FALSE;}

	fseek(fp, 0, SEEK_SET);
	fread((BYTE *)(R->Raw), R->FileSize, 1, fp);
	fclose(fp);

	R->RawPtr = R->Raw;	// ����

	return TRUE;
}
//------------------------------------------------------------------------------
void FreeFromROLFile(TROLFile *R)
{
	if (R->Raw) free(R->Raw);
}
//------------------------------------------------------------------------------
BOOL LoadHeader(TROLFile *R)
{
	memcpy(&R->Header, R->RawPtr, sizeof(TROLHeader));
	R->RawPtr += sizeof(TROLHeader);	// ����

	if (strcmp(R->Header.Filler1, "\\roll\\default") != 0) return FALSE;

	return TRUE;
}
//------------------------------------------------------------------------------
void LoadTempoEventsCount(TROLFile *R)
{
	memcpy(&R->TempoCount, R->RawPtr, sizeof(WORD));
	R->RawPtr += sizeof(WORD);	// ����
}
//------------------------------------------------------------------------------
BOOL LoadTempoEvents(TROLFile *R)
{
	int Size;

	if (R->TempoCount == 0) return TRUE;

	Size = sizeof(TTempoEvents) * R->TempoCount;
	R->Tempo = (TTempoEvents *)malloc(Size);
	if (R->Tempo == NULL) return FALSE;

	memcpy(R->Tempo, R->RawPtr, Size);
	R->RawPtr += Size;	// ����

	return TRUE;
}
//------------------------------------------------------------------------------
void FreeTempoEvents(TROLFile *R)
{
	if (R->Tempo) free(R->Tempo);
}
//------------------------------------------------------------------------------
void LoadTimeOfLastNote(TROLFile *R, int voice)
{
	memcpy(&R->Voice[voice].Filler1[0], R->RawPtr, 15);
	R->RawPtr += 15;			// ����
	memcpy(&R->Voice[voice].TimeOfLastNote, R->RawPtr, sizeof(WORD));
	R->RawPtr += sizeof(WORD);	// ����
}
//------------------------------------------------------------------------------
//	1. NoteDuration in Voice
//------------------------------------------------------------------------------
void LoadNoteDurationCount(TROLFile *R, int voice)
{
    WORD NoteNumber, NoteDuration;
    int NoteDurationSum = 0;
	BYTE *p = R->RawPtr;

    R->Voice[voice].NoteCount = 0;

	while (R->Voice[voice].TimeOfLastNote > NoteDurationSum) {
    	memcpy(&NoteNumber, p, sizeof(WORD));
	    p += sizeof(WORD);
        memcpy(&NoteDuration, p, sizeof(WORD));
	    p += sizeof(WORD);
        NoteDurationSum += NoteDuration;
        R->Voice[voice].NoteCount++;
    }
}
//------------------------------------------------------------------------------
BOOL LoadNoteDuration(TROLFile *R, int voice)
{
    int i, NoteDurationSize;
    WORD NoteNumber, NoteDuration;
    WORD NoteDurationSum = 0;

	if (R->Voice[voice].NoteCount == 0) return TRUE;

	NoteDurationSize = sizeof(TNoteDuration) * R->Voice[voice].NoteCount;
	R->Voice[voice].Note = (TNoteDuration *)malloc(NoteDurationSize);
    if (R->Voice[voice].Note == NULL) return FALSE;

    if (R->Voice[voice].TimeOfLastNote > R->TimeOfLastNote)
    	R->TimeOfLastNote = R->Voice[voice].TimeOfLastNote;

    NoteDurationSum = 0;

    for (i = 0; i < R->Voice[voice].NoteCount; i++) {
    	memcpy(&NoteNumber, R->RawPtr, sizeof(WORD));
	    R->RawPtr += sizeof(WORD);
        R->Voice[voice].Note[i].NoteNumber = NoteNumber;
	    memcpy(&NoteDuration, R->RawPtr, sizeof(WORD));
    	R->RawPtr += sizeof(WORD);
        R->Voice[voice].Note[i].NoteDuration = NoteDurationSum;
        NoteDurationSum += NoteDuration;
    }

	return TRUE;
}
//------------------------------------------------------------------------------
void FreeNoteDuration(TROLFile *R, int voice)
{
	if (R->Voice[voice].Note) free(R->Voice[voice].Note);
}
//------------------------------------------------------------------------------
//	2. InstrEvents in Voice
//------------------------------------------------------------------------------
void LoadInstrEventsCount(TROLFile *R, int voice)
{
	memcpy(&R->Voice[voice].Filler2[0], R->RawPtr, 15);
    R->RawPtr += 15;			// ����
	memcpy(&R->Voice[voice].InstrCount, R->RawPtr, sizeof(WORD));
	R->RawPtr += sizeof(WORD);	// ����
}
//------------------------------------------------------------------------------
BOOL LoadInstrEvents(TROLFile *R, int voice)
{
	int Size = sizeof(TInstrEvents) * R->Voice[voice].InstrCount;

    if (R->Voice[voice].InstrCount == 0) return TRUE;

	R->Voice[voice].Instr = (TInstrEvents *)malloc(Size);
	if (R->Voice[voice].Instr == NULL) return FALSE;

	memcpy(R->Voice[voice].Instr, R->RawPtr, Size);
	R->RawPtr += Size;	// ����

	return TRUE;
}
//------------------------------------------------------------------------------
void FreeInstrEvents(TROLFile *R, int voice)
{
	if (R->Voice[voice].Instr) free(R->Voice[voice].Instr);
}
//------------------------------------------------------------------------------
//	3. VolumeEvents in Voice
//------------------------------------------------------------------------------
void LoadVolumeEventsCount(TROLFile *R, int voice)
{
	memcpy(&R->Voice[voice].Filler3[0], R->RawPtr, 15);
	R->RawPtr += 15;			// ����
	memcpy(&R->Voice[voice].VolumeCount, R->RawPtr, sizeof(WORD));
	R->RawPtr += sizeof(WORD);	// ����
}
//------------------------------------------------------------------------------
BOOL LoadVolumeEvents(TROLFile *R, int voice)
{
	int Size;

    if (R->Voice[voice].VolumeCount == 0) return TRUE;

	Size = sizeof(TVolumeEvents) * R->Voice[voice].VolumeCount;

	R->Voice[voice].Volume = (TVolumeEvents *)malloc(Size);
	if (R->Voice[voice].Volume == NULL) return FALSE;

	memcpy(R->Voice[voice].Volume, R->RawPtr, Size);
	R->RawPtr += Size;	// ����

	return TRUE;
}
//------------------------------------------------------------------------------
void FreeVolumeEvents(TROLFile *R, int voice)
{
	if (R->Voice[voice].Volume) free(R->Voice[voice].Volume);
}
//------------------------------------------------------------------------------
//	4. PitchEvents in Voice
//------------------------------------------------------------------------------
void LoadPitchEventsCount(TROLFile *R, int voice)
{
	memcpy(&R->Voice[voice].Filler4[0], R->RawPtr, 15);
	R->RawPtr += 15;			// ����
	memcpy(&R->Voice[voice].PitchCount, R->RawPtr, sizeof(WORD));
	R->RawPtr += sizeof(WORD);	// ����
}
//------------------------------------------------------------------------------
BOOL LoadPitchEvents(TROLFile *R, int voice)
{
	int Size;

    if (R->Voice[voice].PitchCount == 0) return TRUE;

    Size = sizeof(TPitchEvents) * R->Voice[voice].PitchCount;
	R->Voice[voice].Pitch = (TPitchEvents *)malloc(Size);
	if (R->Voice[voice].Pitch == NULL) return FALSE;

	memcpy(R->Voice[voice].Pitch, R->RawPtr, Size);
	R->RawPtr += Size;	// ����

	return TRUE;
}
//------------------------------------------------------------------------------
void FreePitchEvents(TROLFile *R, int voice)
{
	if (R->Voice[voice].Pitch) free(R->Voice[voice].Pitch);
}
//------------------------------------------------------------------------------
BOOL LoadUsedInstCount(TROLFile *R)
{
	int i, j, k, l, UsedInstCount = 0;

    for (i = 0; i < R->VoiceCount; i++) {
    	int InstListSize = sizeof(int) * R->Voice[i].InstrCount;
	    R->Voice[i].InstrIndex = (int *)malloc(InstListSize);
        if (R->Voice[i].InstrIndex == NULL) return FALSE;

		memset(R->Voice[i].InstrIndex, -1, InstListSize);
    }

    for (i = 0; i < R->VoiceCount; i++) {
        for (j = 0; j < R->Voice[i].InstrCount; j++) {
            if (R->Voice[i].InstrIndex[j] == -1) {
	            char *tempptr1;

                R->Voice[i].InstrIndex[j] = UsedInstCount++;
                tempptr1 = R->Voice[i].Instr[j].InstrName;
                for (k = i; k < R->VoiceCount; k++) {
                    for (l = 0; l < R->Voice[k].InstrCount; l++) {
		                char *tempptr2 = R->Voice[k].Instr[l].InstrName;
                        if (stricmp(tempptr1, tempptr2) == 0)
                        	R->Voice[k].InstrIndex[l] = R->Voice[i].InstrIndex[j];
                    }
                }
            }
        }
    }

    R->UsedInstCount = UsedInstCount;

    return TRUE;
}
//------------------------------------------------------------------------------
void FreeUsedInstCount(TROLFile *R)
{
	int i;

    for (i = 0; i < R->VoiceCount; i++)
	    if (R->Voice[i].InstrIndex) free(R->Voice[i].InstrIndex);
}
//------------------------------------------------------------------------------
BOOL LoadUsedInstName(TROLFile *R)
{
	int i, j, k;

    if (R->UsedInstCount == 0) return FALSE;

	R->UsedInstData = (TInstData *)malloc(sizeof(TInstData) * R->UsedInstCount);
    if (R->UsedInstData == NULL) return FALSE;

    for (i = 0; i < R->UsedInstCount; i++) {
        for (j = 0; j < R->VoiceCount; j++) {
            for (k = 0; k < R->Voice[j].InstrCount; k++) {
                if (R->Voice[j].InstrIndex[k] == i) {
                    char *tempptr1 = R->Voice[j].Instr[k].InstrName;
                    strcpy(R->UsedInstData[i].InstName, tempptr1);
                }
            }
        }
    }

    return TRUE;
}
//------------------------------------------------------------------------------
void FreeUsedInstName(TROLFile *R)
{
	if (R->UsedInstData) free(R->UsedInstData);
}
//------------------------------------------------------------------------------







