int KSSM2ExtKS(int Code);
int ExtKS2KSSM(int Code);
int KSSM2KS(int code);
int KS2KSSM(int code);
int ConvertHanCode(char SrcCode, char DestCode, int code);
void ConvertHanCodeStr(char SrcCode, char DestCode, char *str, int size);