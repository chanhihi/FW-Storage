//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Main.h"
#include "hanlib.h"
#include "HanOut.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

THanFont HanFont1;
TEngFont EngFont1;
//---------------------------------------------------------------------------
String GetFontType(int AFileSize)
{
    switch (AFileSize) {
    case 2048: return "����128";
    case 4096: return "����256 �Ǵ� �ﺸ Ư������128";
    case 4112: return "�Ѹ� ����256";

    case 3616: return "2��1��2 (�Ѷ����� �۲�)";
    case 3776: return "2��1��2";
    case 6176: return "6��2��1";
    case 11008: return "8��4��4 (�Ѷ����� �۲�)";
    case 11520: return "8��4��4 (������ �۲�)";
    case 12224: return "10��4��4 (�Ѷ����� �۲�)";
    case 12800: return "8��4��4 (�̾߱� 6.0) �Ǵ� 10��4��4";
    case 13056: return "8��4��4 (�̾߱� 6.1 �̻�)";

    case 33696: return "Ư������1053 (���鹮�� 75���� ���ŵ� ����)";
    case 36096: return "Ư������1128";
    case 156416: return "ǥ������4888";
    }

    return "";
}
//---------------------------------------------------------------------------
String InsertComma(int AValue)
{
    if (AValue == 0) return "0";
    return FormatFloat("#,###", AValue);
}
//---------------------------------------------------------------------------
void GetFileList(TListView *AListView, String ADirPath, String AFileExt, String AFileSize)
{
    TListItem *ListItem1;
    String FileExt, FileSize;
    struct ffblk ffblk1;
    int done1;

    AListView->Items->BeginUpdate();
    AListView->Items->Clear();

    done1 = findfirst(String(ADirPath + "*.*").c_str(), &ffblk1, 0);
    while (!done1) {
        FileExt = ";" + ExtractFileExt(ffblk1.ff_name) + ";";
        if (AFileExt.Pos(FileExt.LowerCase())) goto p1;

        FileSize = ";" + IntToStr(ffblk1.ff_fsize) + ";";
        if (AFileSize.Pos(FileSize.LowerCase())) goto p1;

        if ((AFileExt == "") && (AFileSize == "")) goto p1;
        else goto p2;
p1:
        ListItem1 = AListView->Items->Add();
        ListItem1->Caption = ffblk1.ff_name;
        //ListItem1->SubItems->Add(InsertComma(ffblk1.ff_fsize));
        //ListItem1->SubItems->Add(ExtractFileExt(ffblk1.ff_name));
        //ListItem1->SubItems->Add(GetFontType(ffblk1.ff_fsize));
p2:
        done1 = findnext(&ffblk1);
    }
    AListView->Items->EndUpdate();
}
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
//    SetImageColsRows(Image1, 19+1, 32, 16, 16);
    byte s[] = "�ȳ��ϼ��� Hello, World!";

    SetImageRows(Image1, 10, 20, 16, 16, clBlack);
//    PutsHanFonts(Image1->Canvas, 1, 0, "�ȳ��ϼ���", &HanFont1);
//    PutsHanFonts(Image1->Canvas, 1, 16, "������", &HanFont1);
//    PutsHanFonts(Image1->Canvas, 1, 32, "ũ����", &HanFont1);

    PutsBitmapFonts(ListView1->Canvas, 0, 0, "������");
    PutsBitmapFonts(ListView1->Canvas, 0, 16, "������");
    PutsBitmapFonts(ListView1->Canvas, 0, 32, "������");

}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    EngBitmap = new Graphics::TBitmap();
    EngBitmap->Width = 8;
    EngBitmap->Height = 16;
    EngBitmap->PixelFormat = pf1bit;

    HanBitmap = new Graphics::TBitmap();
    HanBitmap->Width = 16;
    HanBitmap->Height = 16;
    HanBitmap->PixelFormat = pf1bit;

    LoadHanFont(&HanFont1, "dinaru.han");
    LoadEngFont(&EngFont1, "e2.eng");
    pDefEngFont = &EngFont1;
    pDefHanFont = &HanFont1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ScrollBox1MouseWheelDown(TObject *Sender,
      TShiftState Shift, TPoint &MousePos, bool &Handled)
{
    ScrollBox1->VertScrollBar->Position =
        ScrollBox1->VertScrollBar->Position +
        ScrollBox1->VertScrollBar->Increment;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Image1MouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
    ScrollBox1->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ScrollBox1MouseWheelUp(TObject *Sender,
      TShiftState Shift, TPoint &MousePos, bool &Handled)
{
    ScrollBox1->VertScrollBar->Position =
        ScrollBox1->VertScrollBar->Position -
        ScrollBox1->VertScrollBar->Increment;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
    TRect DestRect, SrcRect;
    DestRect = Rect(0,0,200,15+2);
    SrcRect = Rect(0,0,200,15+2);

    Image2->Canvas->CopyRect(DestRect, Image1->Canvas, SrcRect);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
    GetFileList(ListView1, "D:\\font\\", "", BitmapHanFontFilesSize);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ListView1DrawItem(TCustomListView *Sender,
      TListItem *Item, TRect &Rect, TOwnerDrawState State)
{
    byte bitmap32[32];

    byte s[] = {0x88, 0x61, 0};
    CompleteHanChar(bitmap32, s, &HanFont1);
    PutBitmap16x16(ListView1->Canvas, Rect.Left, Rect.Top, bitmap32);
}
//---------------------------------------------------------------------------

