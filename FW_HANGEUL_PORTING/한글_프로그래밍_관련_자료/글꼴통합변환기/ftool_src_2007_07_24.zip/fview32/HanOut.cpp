//---------------------------------------------------------------------------
#include <vcl.h>
#include <Graphics.hpp>
#pragma hdrstop

#include "HanOut.h"

#include "hanlib.h"
#include "Johab.h"
#include "Table10x4x4.h"
#include "Table8x4x4.h"
#include "Table6x2x1.h"
#include "Table2x1x2.h"
#include "CP949Table.h"
#include "KS2JohabTable.h"
#include "CompleteKS.h"

#include "HanCodeConverter.h"

Graphics::TBitmap *EngBitmap, *HanBitmap;   // 0.54 �߰�
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
void PutBitmap8x16(TCanvas *ACanvas, int x, int y, byte *ABitmap16)
{
    for (int i = 0; i < 16; i++) {
        byte *p = (byte *)EngBitmap->ScanLine[i];
        p[0] = ~ABitmap16[i];
    }
    ACanvas->Draw(x, y, EngBitmap);
}
//---------------------------------------------------------------------------
void PutBitmap16x16(TCanvas *ACanvas, int x, int y, byte *ABitmap32)
{
    for (int i = 0; i < 16; i++) {
        byte *p = (byte *)HanBitmap->ScanLine[i];
        p[0] = ~ABitmap32[2*i];
        p[1] = ~ABitmap32[2*i+1];
    }
    ACanvas->Draw(x, y, HanBitmap);
}
//---------------------------------------------------------------------------
void PutBitmap8x16InCell(TCanvas *ACanvas, int ACol, int ARow, byte *ABitmap16)
{
	PutBitmap8x16(ACanvas, ACol * (8 + 1) + 1, ARow * (16 + 1) + 1, ABitmap16);
}
//---------------------------------------------------------------------------
void PutBitmap16x16InCell(TCanvas *ACanvas, int ACol, int ARow, byte *bitmap32)
{
	PutBitmap16x16(ACanvas, ACol * (16 + 1) + 1, ARow * (16 + 1) + 1, bitmap32);
}
//---------------------------------------------------------------------------
void SetImageColsRows(TImage *AImage, int AColCount, int ARowCount, int AColWidth, int ARowWidth)
{
    AImage->Width = ((AColWidth + 1) * AColCount) + 1;
    AImage->Height = ((ARowWidth + 1) * ARowCount) + 1;
    AImage->Picture->Bitmap->Width = AImage->Width;
    AImage->Picture->Bitmap->Height = AImage->Height;

    AImage->Canvas->Pen->Color = clTeal;

    for (int Row = 0; Row < ARowCount + 1; Row++) {
        AImage->Canvas->MoveTo(0, (ARowWidth + 1) * Row);
        AImage->Canvas->LineTo(AImage->Width, (ARowWidth + 1) * Row);
    }

    for (int Col = 0; Col < AColCount + 1; Col++) {
        AImage->Canvas->MoveTo((AColWidth + 1) * Col, 0);
        AImage->Canvas->LineTo((AColWidth + 1) * Col, AImage->Height);
    }
}
//---------------------------------------------------------------------------
void SetImageRows(TImage *AImage, int AColCount, int ARowCount, int AColWidth, int ARowWidth, TColor AGridColor)
{
    AImage->Width = (AColWidth * AColCount) + 1;
    AImage->Height = ((ARowWidth + 1) * ARowCount) + 1;
    AImage->Picture->Bitmap->Width = AImage->Width;
    AImage->Picture->Bitmap->Height = AImage->Height;

    AImage->Canvas->Pen->Color = AGridColor;

    for (int Row = 0; Row < ARowCount + 1; Row++) {
        AImage->Canvas->MoveTo(0, (ARowWidth + 1) * Row);
        AImage->Canvas->LineTo(AImage->Width, (ARowWidth + 1) * Row);
    }

    AImage->Canvas->MoveTo(0, 0);
    AImage->Canvas->LineTo(0, AImage->Height);

    AImage->Canvas->MoveTo(AImage->Width - 1, 0);
    AImage->Canvas->LineTo(AImage->Width - 1, AImage->Height);
}
//---------------------------------------------------------------------------




THanFont *pDefHanFont;
TEngFont *pDefEngFont;
//---------------------------------------------------------------------------
void PutsBitmapFonts(TCanvas *ACanvas, int ALeft, int ATop, byte *s)
{
    ConvertHanCodeStr(1, 2, s, strlen(s));  // �ϼ��� -> ������

    int x = 0;
    for (unsigned i = 0; i < strlen(s); ) {
        if (ishangul1st(s, i)) {
            byte bitmap32[32];
            CompleteHanChar(bitmap32, s + i, pDefHanFont), i += 2;
            PutBitmap16x16(ACanvas, ALeft + x, ATop, bitmap32), x += 16;
        } else
            PutBitmap8x16(ACanvas, ALeft + x, ATop, pDefEngFont->Eng[s[i]]), i++, x += 8;
    }
}
//---------------------------------------------------------------------------
void PutsEngFonts(TCanvas *ACanvas, int ALeft, int ATop, byte *s, TEngFont *AEngFont)
{
    int x = 0;
    for (unsigned i = 0; i < strlen(s); )
        PutBitmap8x16(ACanvas, ALeft + x, ATop, AEngFont->Eng[s[i]]), i++, x += 8;
}
//---------------------------------------------------------------------------
void PutsHanFonts(TCanvas *ACanvas, int ALeft, int ATop, byte *s, THanFont *AHanFont)
{
    ConvertHanCodeStr(1, 2, s, strlen(s));  // �ϼ��� -> ������

    int x = 0;
    for (unsigned i = 0; i < strlen(s); ) {
        if (ishangul1st(s, i)) {
            byte bitmap32[32];
            CompleteHanChar(bitmap32, s + i, AHanFont), i += 2;
            PutBitmap16x16(ACanvas, ALeft + x, ATop, bitmap32), x += 16;
        } else i++, x += 8;
    }
}
//---------------------------------------------------------------------------
void CompleteHanChar(byte *ABuffer32, byte *AHanByte, THanFont *AHanFont)
{
    THangul _Hangul;
	bool flag = true;

    _Hangul.HanByte.Byte0 = AHanByte[0];
    _Hangul.HanByte.Byte1 = AHanByte[1];

    int F1 = _CodeTable[0][_Hangul.HanCode.F1];
    int F2 = _CodeTable[1][_Hangul.HanCode.F2];
    int F3 = _CodeTable[2][_Hangul.HanCode.F3];

    int F3B = AHanFont->pF3B[F2];
    int F2B = AHanFont->pF2B[F1 * 2 + (F3 != 0)];
    int F1B = AHanFont->pF1B[F2 * 2 + (F3 != 0)];

    if (F1) HanComplete(true, ABuffer32, AHanFont->F1[F1B][F1], 32), flag = false;
    if (F2) HanComplete(flag, ABuffer32, AHanFont->F2[F2B][F2], 32), flag = false;
    if (F3)	HanComplete(flag, ABuffer32, AHanFont->F3[F3B][F3], 32), flag = false;
}
//------------------------------------------------------------------------------
#include <ctype.h>
#include <string.h>
//------------------------------------------------------------------------------
bool ishangul1st(byte *s, int pos)
{
    int i;

    if (pos < 0 || (unsigned)pos > strlen(s) - 2 || s[pos] < 128) return false;

    for (i = 0; i < pos; )
        if (isascii(s[i])) i++;
        else i += 2;

    return ((i == pos) ? true : false);
}
//------------------------------------------------------------------------------
bool ishangul2nd(byte *s, int pos)
{
    int i;

    if (pos < 1 || (unsigned)pos > strlen(s) - 1 || s[pos - 1] < 128) return false;

    for (i = 0; i < pos; )
        if (isascii(s[i])) i++;
        else i += 2;

    return ((i == pos + 1) ? true : false);
}








/*
//---------------------------------------------------------------------------
void DrawEngFontTable(TCanvas *ACanvas, TEngFont *AEngFont)
{
    int EngIndex = 0;
    for (int Row = 0; Row < AEngFont->CharCount / 32; Row++) {
    	for (int Col = 0; Col < 32; Col++) {
    		PutBitmap8x16InCell(ACanvas, Col, Row, AEngFont->Eng[EngIndex++]);
        }
    }
}
//---------------------------------------------------------------------------
void DrawHanFontTable(TCanvas *ACanvasF1, TCanvas *ACanvasF2, TCanvas *ACanvasF3, THanFont *AHanFont)
{
    for (int Row = 0; Row < AHanFont->F1BulCount; Row++) {
    	for (int Col = 0; Col < AHanFont->F1Count; Col++)
    		PutBitmap16x16InCell(ACanvasF1, Col, Row, AHanFont->F1[Row][Col + !AHanFont->F_SKIP]);
    }
    for (int Row = 0; Row < AHanFont->F2BulCount; Row++) {
    	for (int Col = 0; Col < AHanFont->F2Count; Col++)
    		PutBitmap16x16InCell(ACanvasF2, Col, Row, AHanFont->F2[Row][Col + !AHanFont->F_SKIP]);
    }
    for (int Row = 0; Row < AHanFont->F3BulCount; Row++) {
    	for (int Col = 0; Col < AHanFont->F3Count; Col++)
    		PutBitmap16x16InCell(ACanvasF3, Col, Row, AHanFont->F3[Row][Col + !AHanFont->F_SKIP]);
    }
}
//---------------------------------------------------------------------------
void DrawSpcFontTable(TCanvas *ACanvas, TSpcFont *ASpcFont, int APage)
{
    int i = 0;

    for (int Row = 0; Row < 1; Row++)
        for (int Col = 1; Col < 16; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, ASpcFont->Spc[APage][i++]);
    for (int Row = 1; Row < 5; Row++)
        for (int Col = 0; Col < 16; Col++)
            PutBitmap16x16InCell(ACanvas, Col, Row, ASpcFont->Spc[APage][i++]);
    for (int Row = 5; Row < 6; Row++)
        for (int Col = 0; Col < 15; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, ASpcFont->Spc[APage][i++]);
}
//---------------------------------------------------------------------------
void DrawHanjaFontTable(TCanvas *ACanvas, THanjaFont *AHanjaFont, int APage)
{
    int i = 0;

    for (int Row = 0; Row < 1; Row++)
        for (int Col = 1; Col < 16; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, AHanjaFont->Hanja[APage][i++]);
    for (int Row = 1; Row < 5; Row++)
        for (int Col = 0; Col < 16; Col++)
            PutBitmap16x16InCell(ACanvas, Col, Row, AHanjaFont->Hanja[APage][i++]);
    for (int Row = 5; Row < 6; Row++)
        for (int Col = 0; Col < 15; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, AHanjaFont->Hanja[APage][i++]);
}
//---------------------------------------------------------------------------
void DrawSamboSpcFontTable(TCanvas *ACanvas, TSpcFont *ASpcFont)
{
    int Index = 0;
    for (int Row = 0; Row < 8; Row++)
    	for (int Col = 0; Col < 16; Col++)
            PutBitmap16x16InCell(ACanvas, Col, Row, ASpcFont->SamboSpc[Index++]);
}
//---------------------------------------------------------------------------
void FloodFill(TCanvas *ACanvas, int ALeft, int ATop, int AWidth, int AHeight, TColor AColor)
{
	TRect FullRect;

    FullRect.Left = ALeft;
    FullRect.Top = ATop;
    FullRect.Right = ALeft + AWidth;
    FullRect.Bottom = ATop + AHeight;
    ACanvas->Brush->Color = AColor;
    ACanvas->FillRect(FullRect);
}
//---------------------------------------------------------------------------
void ClearCanvasGridCell(TCanvas *ACanvas, int ACol, int ARow, int AColWidth, int ARowHeight, TColor AColor)
{
	FloodFill(ACanvas, ACol * (AColWidth + 1) + 1, ARow * (ARowHeight + 1) + 1, AColWidth, ARowHeight, AColor);
}
//---------------------------------------------------------------------------
void ClearCanvasGrid(TCanvas *ACanvas, TColor AColor)
{
    ACanvas->Brush->Color = AColor;
    ACanvas->Brush->Style = bsSolid;
    ACanvas->FillRect(ACanvas->ClipRect);
}
//---------------------------------------------------------------------------
*/

