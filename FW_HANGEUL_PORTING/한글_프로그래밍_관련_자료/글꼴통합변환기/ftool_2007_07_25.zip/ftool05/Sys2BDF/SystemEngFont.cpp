//---------------------------------------------------------------------------
#include <vcl.h>
#include <ComCtrls.hpp>
#pragma hdrstop

#include <stdio.h>
#include "Common.h"
#include "BBX.h"
#include "BDF.h"

#include "SystemEngFont.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//------------------------------------------------------------------------------
bool SysEngFontToBDFBody(String ASaveFileName, String AWriteMode, TFont *AFont, TTextMetric *ATextMetric, bool AEndFont)
{
    FILE *fp = fopen(ASaveFileName.c_str(), AWriteMode.c_str());
    if (fp == NULL) return false;
    //--------------------------------------------------------------------------
    TStringList *StringList1 = new TStringList();
    TImage *Image1 = new TImage(NULL);

    Image1->Width = ATextMetric->tmMaxCharWidth;
    Image1->Height = ATextMetric->tmHeight;
    Image1->Canvas->Brush->Color = clBlack;
    Image1->Canvas->Brush->Style = bsSolid;
    Image1->Canvas->FillRect(Image1->ClientRect);
    Image1->Canvas->Font->Assign(AFont);
    Image1->Canvas->Font->Color = clWhite;
    Image1->Picture->Bitmap->PixelFormat = pf8bit;
    //--------------------------------------------------------------------------
    for (int Encoding = 0; Encoding < 128; Encoding++) {
        String s = GetCharBBXInfo(StringList1, Image1, ATextMetric, 0, 0, (char)Encoding, Encoding);
        fwrite(s.c_str(), strlen(s.c_str()), 1, fp);
    }
    if (AEndFont) fprintf(fp, "ENDFONT\n");
    fclose(fp);

    delete StringList1;
    delete Image1;

    return true;
}
//------------------------------------------------------------------------------
bool SysEngFontToBDF(String ASaveFileName, String AWriteMode, TFont *AFont, TTextMetric *ATextMetric)
{
	static TBDFHeader BDFHeader1;

    BDFHeader1.Size_PointSize		= IntToStr(ATextMetric->tmHeight);
    BDFHeader1.Size_Xres			= "96";
    BDFHeader1.Size_Yres			= "96";
    BDFHeader1.FontBoundingBox_FBBx = IntToStr(ATextMetric->tmMaxCharWidth);
    BDFHeader1.FontBoundingBox_FBBy	= IntToStr(ATextMetric->tmHeight);
    BDFHeader1.FontBoundingBox_Xoff	= "0";
    BDFHeader1.FontBoundingBox_Yoff	= IntToStr(-ATextMetric->tmDescent);
    BDFHeader1.Foundry			    = "Windows";
    BDFHeader1.Family_Name		    = AFont->Name;
    BDFHeader1.Weight_Name		    = "medium";	// or "bold"
    BDFHeader1.Slant			    = "r";		// or "i"
    BDFHeader1.SetWidth_Name	    = "normal";
    BDFHeader1.Add_Style_Name	    = "";
    BDFHeader1.Pixel_Size 		    = ATextMetric->tmHeight;
    BDFHeader1.Point_Size 		    = AFont->Size * 10;
    BDFHeader1.Resolution_X 	    = ATextMetric->tmDigitizedAspectX;
    BDFHeader1.Resolution_Y 	    = ATextMetric->tmDigitizedAspectY;
    BDFHeader1.Spacing			    = (isFixedPitchFont(ATextMetric) ? "m" : "p");
    BDFHeader1.Average_Width 	    = IntToStr(ATextMetric->tmMaxCharWidth * 10);
    BDFHeader1.CharSet_Registry	    = "iso8859";
    BDFHeader1.CharSet_Encoding	    = "1";
    BDFHeader1.Default_Char 	    = IntToStr(ATextMetric->tmDefaultChar);
    BDFHeader1.Font_Ascent		    = IntToStr(ATextMetric->tmAscent);
    BDFHeader1.Font_Descent	 	    = IntToStr(ATextMetric->tmDescent);
    BDFHeader1.CharsCount		    = "128";
    BDFHeader1.Font	= GetXLFD(&BDFHeader1);

    String TmpHeadFile = GetTempFullPathAndFileName("HEAD");
    String TmpBodyFile = GetTempFullPathAndFileName("BODY");
    bool result = WriteBDF_Header(TmpHeadFile, AWriteMode, &BDFHeader1);
    if (!result) {
        ShowMessage("���� ������ �ۼ��ϴ� �� ������ �߻��Ͽ����ϴ�.\n\n" + TmpHeadFile);
        CurBDFHeader = NULL;
        return result;
    }

    CurBDFHeader = &BDFHeader1;

    result = SysEngFontToBDFBody(TmpBodyFile, AWriteMode, AFont, ATextMetric, true);
    if (!result) {ShowMessage("���� ������ �ۼ��ϴ� �� ������ �߻��Ͽ����ϴ�.\n\n" + TmpBodyFile); return result;}

    FileMerge_Two2One(ASaveFileName, TmpHeadFile, TmpBodyFile);

    return true;
}
//------------------------------------------------------------------------------
