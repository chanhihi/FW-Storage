//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include <math.h>
#include "BBX.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
String NibbleToHex(String AValue)
{
    int Len = 4 - AValue.Length();
    for (int i = 0; i < Len; i++) AValue += "0";

    int sum = 0;
    sum += (AValue[1] == '1' ? 8 : 0);
    sum += (AValue[2] == '1' ? 4 : 0);
    sum += (AValue[3] == '1' ? 2 : 0);
    sum += (AValue[4] == '1' ? 1 : 0);

	return IntToHex(sum, 1);
}
//---------------------------------------------------------------------------
String NibblesToHex(String AValue)
{
	int Count = AValue.Length() / 4;
    String HexString = "";

    for (int i = 0; i < Count; i++) {
    	String NibbleString = AValue.SubString(4 * i + 1, 4);
    	HexString += NibbleToHex(NibbleString);
    }

    return HexString;
}
//---------------------------------------------------------------------------
void GetBitmapGlyph(TStringList *AStringList, TImage *AImage, int ALeft, int ATop, int AWidth, int AHeight, bool isHex)
{
	String BitmapString = "";

    int Right = ALeft + AWidth - 1;
    int Bottom = ATop + AHeight - 1;

    for (int y = ATop; y <= Bottom; y++) {
   		byte *p = (byte *)AImage->Picture->Bitmap->ScanLine[y];
        String s = "";
	    for (int x = ALeft; x <= Right; x++) s += (p[x] ? "1" : "0");
        BitmapString += (isHex ? NibblesToHex(s) : s);
        BitmapString += "\n";
    }
	AStringList->Text = BitmapString;
}
//---------------------------------------------------------------------------
int GetBByoff2(TStringList *AStringList)
{
    int BByoff2 = 0;
    for (int i = 0; i < AStringList->Count; i++) {
        if (AStringList->Strings[i].Pos("1")) return BByoff2;
        else BByoff2++;
    }
    return BByoff2;
}
//---------------------------------------------------------------------------
int GetBByoff(TStringList *AStringList)
{
    int BByoff = 0;
    for (int i = AStringList->Count - 1; i >= 0; i--) {
        if (AStringList->Strings[i].Pos("1")) return BByoff;
        else BByoff++;
    }
    return BByoff;
}
//---------------------------------------------------------------------------
int GetBBxoff(TStringList *AStringList)
{
    int BBxoff = 0;
    int TextWidth = AStringList->Strings[0].Length();

    for (int Col = 1; Col <= TextWidth; Col++) {
        for (int Row = 0; Row < AStringList->Count; Row++)
        	if (AStringList->Strings[Row][Col] == '1') return BBxoff;
        BBxoff++;
    }
    return BBxoff;
}
//---------------------------------------------------------------------------
int GetBBxoff2(TStringList *AStringList)
{
    int BBxoff2 = 0;
    int TextWidth = AStringList->Strings[1].Length();

    for (int Col = TextWidth; Col >= 1; Col--) {
        for (int Row = 0; Row < AStringList->Count; Row++)
        	if (AStringList->Strings[Row][Col] == '1') return BBxoff2;
        BBxoff2++;
    }
    return BBxoff2;
}
//---------------------------------------------------------------------------
void GetBitmapGlyphBBX(TStringList *AStringList, int BBxoff, int BByoff, int BBxoff2, int BByoff2)
{
    if (AStringList->Text.Pos("1") == 0) {  //���鹮��
        AStringList->Clear();
        return;
    }

    for (int i = 0; i < AStringList->Count; i++) {
	    AStringList->Strings[i] = AStringList->Strings[i].Delete(1, BBxoff);
        int NewLength = AStringList->Strings[i].Length();
        AStringList->Strings[i] = AStringList->Strings[i].SetLength(NewLength - BBxoff2);
    }

	for (int i = 0; i < BByoff2; i++)
    	AStringList->Delete(0);

    int Index  = AStringList->Count - BByoff;
	for (int i = 0; i < BByoff; i++)
    	AStringList->Delete(Index);
}
//---------------------------------------------------------------------------
void GetBitmapGlyphBBX_Hex(TStringList *AStringList)
{
	if (AStringList->Count == 0) return;

//	int Mod = AStringList->Strings[0].Length() % 4;
	int Mod = AStringList->Strings[0].Length() % 8;
	if (Mod != 0) {
//	    int Count = 4 - Mod;
	    int Count = 8 - Mod;
	    for (int i = 0; i < AStringList->Count; i++)
			for (int j = 0; j < Count; j++)
            	AStringList->Strings[i] = AStringList->Strings[i] + "0";
    }

	for (int i = 0; i < AStringList->Count; i++)
    	AStringList->Strings[i] = NibblesToHex(AStringList->Strings[i]);
}
//---------------------------------------------------------------------------
String GetCharBBXInfo(TStringList *AStringList, TImage *AImage, TTextMetric *ATextMetric, int x, int y, String AText, int AEncoding)
{
	AStringList->Clear();

    // 1. ���̳ʸ� ��Ʈ�� ���ڿ� ���
	AImage->Canvas->TextOut(x, y, AText);
    int TextWidth = AImage->Canvas->TextWidth(AText);
    int TextHeight = AImage->Canvas->TextHeight(AText);
	GetBitmapGlyph(AStringList, AImage, x, y, TextWidth, TextHeight, false);
#ifdef __FTOOL_DEBUG
    String BitmapData1 = "";
    BitmapData1 += "COMMENT --------------------------------\n";
    for (int i = 0; i < AStringList->Count; i++)
    	BitmapData1 += ("COMMENT " + AStringList->Strings[i] + "\n");
#endif
    // 2. ó�� ���� ��Ʈ�ʿ��� �����¿� ���� ���� (���� ���� �簢�� ���� ���ϱ�)
    int BBxoff, BByoff, BBxoff2, BByoff2;
    if (AStringList->Count == 0) {
        BBxoff = 0;
        BByoff = 0;
    } else {
        BBxoff = GetBBxoff(AStringList);
        BByoff = GetBByoff(AStringList);
        BBxoff2 = GetBBxoff2(AStringList);
        BByoff2 = GetBByoff2(AStringList);
        GetBitmapGlyphBBX(AStringList, BBxoff, BByoff, BBxoff2, BByoff2);
    }
#ifdef __FTOOL_DEBUG
    String BitmapData2 = "";
    BitmapData2 += "COMMENT --------------------------------\n";
    for (int i = 0; i < AStringList->Count; i++)
    	BitmapData2 += ("COMMENT " + AStringList->Strings[i] + "\n");
#endif
    // 3. ���� ��Ʈ�� ���ڿ��� 16���� ���ڿ��� ��ȯ
    int BBw, BBh, BBxoff0x, BByoff0y;

    if (AStringList->Count > 0)
    	BBw = AStringList->Strings[0].Length();
    else
    	BBw = 0;
    BBh = AStringList->Count;
    BBxoff0x = BBxoff;
    BByoff0y = BByoff;
    GetBitmapGlyphBBX_Hex(AStringList);
    // 4. ��Ʈ�� ���� ���� �ϼ�
    int DWidth = TextWidth;
    int SWidth = (DWidth * AImage->Canvas->Font->PixelsPerInch * 1000)
    	/ (AImage->Canvas->Font->Size * AImage->Canvas->Font->PixelsPerInch);

    String s = "STARTCHAR char0x" + IntToHex(AEncoding, 4) + "\n"
		+ "ENCODING " + AEncoding + "\n"
        + "SWIDTH " + SWidth + " 0" + "\n"
        + "DWIDTH " + DWidth + " 0" + "\n";
   if (AStringList->Text == "") s += "BBX 0 0 0 0\n";
   else {
    	s = s + "BBX " + IntToStr(BBw) + " " + IntToStr(BBh) + " ";
        s = s + IntToStr(BBxoff0x) + " " + IntToStr(BByoff0y - ATextMetric->tmDescent) + "\n";
    }

    s += "BITMAP\n";
#ifdef __FTOOL_DEBUG
	s += BitmapData1;
	s += BitmapData2;
#endif
    for (int i = 0; i < AStringList->Count; i++)
    	s += (AStringList->Strings[i] + "\n");
    s += "ENDCHAR\n";

    AStringList->Text = s;

    return s;
}
//---------------------------------------------------------------------------
