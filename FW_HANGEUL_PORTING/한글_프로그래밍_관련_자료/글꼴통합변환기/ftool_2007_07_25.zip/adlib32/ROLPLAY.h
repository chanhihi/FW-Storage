//------------------------------------------------------------------------------
#ifndef __ROLPLAY_H
#define __ROLPLAY_H
//------------------------------------------------------------------------------
#include "datatype.h"
#include "rol.h"
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//------------------------------------------------------------------------------
extern int ROLTempo;

void OnTempoEvent(void);
void OnInstrEvent(int voice);
void OnPitchEvent(int voice);
void OnVolumeEvent(int voice);
void OnNoteEvent(int voice);
void RewindROL(void);
int  OnROLPlayEvent(void);
void LoadUsedInstData(TROLFile *, TBNKFile *);
BOOL SelectROLBNK(TROLFile *, TBNKFile *);
BOOL ResetROL(TROLFile *);
//------------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif	//__ROLPLAY_H
