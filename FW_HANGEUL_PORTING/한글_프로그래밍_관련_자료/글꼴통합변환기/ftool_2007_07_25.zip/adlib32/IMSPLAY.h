//------------------------------------------------------------------------------
#ifndef __IMSPLAY_H
#define __IMSPLAY_H
//------------------------------------------------------------------------------
#include "datatype.h"

#include "fmopl.h"
#include "outchip.h"
#include "adlib.h"
#include "bnk.h"
#include "ims.h"
#include "waveloop.h"
#include "player.h"
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//------------------------------------------------------------------------------
extern int IMSTempo;

int  OnIMSPlayEvent(void);
BOOL SelectIMSBNK(TIMSFile *, TBNKFile *);
BOOL ResetIMS(TIMSFile *);
//------------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif	//__IMSPLAY_H
