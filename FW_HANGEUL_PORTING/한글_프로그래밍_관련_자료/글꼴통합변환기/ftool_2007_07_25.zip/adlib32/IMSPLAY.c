#ifdef __BORLANDC__
#pragma warn -8071
#endif

#include <stdio.h>
#include <string.h>

#include "imsplay.h"
#include "player.h"


int IMSTempo = 120;		// ���� ������
int	SongDataIndex = 0;
int TickDelayCount = 0;


//------------------------------------------------------------------------------
void RewindIMS(void)
{
	IMSTempo = _I->Header.nBasicTempo;
	SongDataIndex = 0;
	TickDelayCount = 0;
}
//------------------------------------------------------------------------------
int OnIMSPlayEvent(void)
{
	static BYTE StCode;
	BYTE CurCode;
	int Delay, TickDelay = 0;
	int Voice, Note, Volume, InstrIndex, *paramArray;
	WORD pitchBend;
    int InstrIndexInBNK;

Again0:

	CurCode = _I->SongData[SongDataIndex];

	if (CurCode > 0x7F) {	// 0x7F == 127
		SongDataIndex++;
		StCode = CurCode;
	} else CurCode = StCode;

	Voice = CurCode & 0x0F;	// ������ 4��Ʈ�� ��´� (ä�� ��ȣ)

	switch (CurCode & 0xF0) {	// ���� 4��Ʈ�� �̺�Ʈ ������ ����Ǿ� �ִ�
	case 0x80: // note off
		Note = _I->SongData[SongDataIndex];
		Volume = _I->SongData[SongDataIndex + 1];

		NoteOff(Voice);						//��
		SetVoiceVolume(Voice, Volume);		//��
		NoteOn(Voice, Note);				//��
		SongDataIndex += 2;
		break;
	case 0x90: // note on
		Note = _I->SongData[SongDataIndex];
		Volume = _I->SongData[SongDataIndex + 1];

		NoteOff(Voice);
		if (Volume) {
			SetVoiceVolume(Voice, Volume);	//��
			NoteOn(Voice, Note);			//��
		}
		SongDataIndex += 2;
		break;
	case 0xA0: // Set Volume
		Volume = _I->SongData[SongDataIndex];

		SetVoiceVolume(Voice, Volume);		//��
		SongDataIndex++;
		break;
	case 0xC0: // Set Instrument
		InstrIndex = _I->SongData[SongDataIndex];
        InstrIndexInBNK = _I->UsedInstrIndex[InstrIndex].InstrIndex;
        paramArray = &_I->BNKFile->InstRecord32[InstrIndexInBNK].Op1.KeyScaleLevel;

		SetVoiceTimbre(Voice, paramArray);	//��
		SongDataIndex++;
		break;
	case 0xE0: // Set Pitch
//      pitchBend = _I->SongData[SongDataIndex];
//      pitchBend += (_I->SongData[SongDataIndex + 1] << 8);
//      pitchBend = pitchBend / 2;
//		���� �� �ٰ� �Ʒ��� �� ���� ���� ����� �����Ѵ�.
		memcpy(&pitchBend, &_I->SongData[SongDataIndex], sizeof(WORD));
        pitchBend = pitchBend / 2;

		SetVoicePitch(Voice, pitchBend);	//��
		SongDataIndex += sizeof(WORD);
		break;
	case 0xF0: // Set Tempo
		SongDataIndex += 2;
		IMSTempo = (_I->Header.nBasicTempo * _I->SongData[SongDataIndex]);
		IMSTempo += _I->Header.nBasicTempo * _I->SongData[SongDataIndex + 1] / 128;
		SongDataIndex += 3;
		break;
	}

	while (1) {
		Delay = _I->SongData[SongDataIndex];
		SongDataIndex++;
		if (_I->SongData[SongDataIndex] == 0xFC) {	// IMS ������ ���� �ڵ�
        	RewindIMS();
//			PLAY_MODE = NONE_PLAY_MODE;
            TickDelay += Delay;
        	return TickDelay;
        }

		if (Delay == 0xF8) TickDelay += 240;
		else break;
	}

	TickDelay += Delay;

	if (TickDelay == 0) goto Again0;
	else TickDelayCount += TickDelay;

	return TickDelay;
}
//------------------------------------------------------------------------------
BOOL SelectIMSBNK(TIMSFile *I, TBNKFile *B)
{
	int i, j;

    if (I == NULL) return FALSE;

	for (i = 0; i < I->UsedInstrCount; i++) {
		for (j = 0; j < B->Header.nTotalEntry; j++) {
			if (stricmp(B->NameRecord[j].szName, I->UsedInstrIndex[i].InstrName) == EQUAL_STRING)
//				memcpy(&I->UsedInstData[i].InstData32, &B->InstRecord32[B->NameRecord[j].index], sizeof(TBNKInstRecord32));	// 4 byte x 30�� == 120 byte ����
				I->UsedInstrIndex[i].InstrIndex = B->NameRecord[j].index;
		}
	}

    I->BNKFile = B;

    return TRUE;
}
//------------------------------------------------------------------------------
BOOL ResetIMS(TIMSFile *IMSFile)
{
	int i;

    if (IMSFile == NULL) return FALSE;
    else CurrentIMSFile = IMSFile;

	YM3812ResetChip(ym3812p);

	SndOutput(1, 0x20);	// Enable waveform select (bit 5)
	SetMode(_I->Header.nSoundMode);

	for (i = 0; i < MAXVOICE; i++) {
		NoteOff(i);
		SetVoiceVolume(i, 0);
	}

    RewindIMS();

    PLAY_MODE = IMS_MODE;
    return TRUE;
}
//------------------------------------------------------------------------------

