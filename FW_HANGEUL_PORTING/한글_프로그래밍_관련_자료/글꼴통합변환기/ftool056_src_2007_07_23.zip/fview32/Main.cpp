//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Main.h"
#include "hanlib.h"
#include "HanOut.h"
#include "HanTest.h"
#include "HanCodeConverter.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

THanFont HanFont1;
TEngFont EngFont1;
//---------------------------------------------------------------------------
void HanPuts(TCanvas *ACanvas, int ALeft, int ATop, byte *s)
{
    ConvertHanCodeStr(1, 2, s, strlen(s));  // �ϼ��� -> ������

    int x = 0;
    for (unsigned i = 0; i < strlen(s); ) {
        if (ishangul1st(s, i)) {
            byte bitmap32[32];
            CompleteHanChar(bitmap32, s + i, &HanFont1), i += 2;
            PutBitmap16x16(ACanvas, ALeft + x, ATop, bitmap32), x += 16;
        } else
            PutBitmap8x16(ACanvas, ALeft + x, ATop, EngFont1.Eng[s[i]]), i++, x += 8;
    }
}
//---------------------------------------------------------------------------
void PutsEngFonts(TCanvas *ACanvas, int ALeft, int ATop, byte *s, TEngFont *AEngFont)
{
    int x = 0;
    for (unsigned i = 0; i < strlen(s); )
        PutBitmap8x16(ACanvas, ALeft + x, ATop, AEngFont->Eng[s[i]]), i++, x += 8;
}
//---------------------------------------------------------------------------
void PutsHanFonts(TCanvas *ACanvas, int ALeft, int ATop, byte *s, THanFont *AHanFont)
{
    ConvertHanCodeStr(1, 2, s, strlen(s));  // �ϼ��� -> ������

    int x = 0;
    for (unsigned i = 0; i < strlen(s); ) {
        if (ishangul1st(s, i)) {
            byte bitmap32[32];
            CompleteHanChar(bitmap32, s + i, AHanFont), i += 2;
            PutBitmap16x16(ACanvas, ALeft + x, ATop, bitmap32), x += 16;
        } else i++, x += 8;
    }
}
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
    SetImageColsRows(Image1, 19+1, 32, 16, 16);
    LoadHanFont(&HanFont1, "dinaru.han");
    LoadEngFont(&EngFont1, "e2.eng");

    byte s[] = "��A��B��C��D��E Hello, World!";
    HanPuts(Image1->Canvas, 1, 1, s);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    EngBitmap = new Graphics::TBitmap();
    EngBitmap->Width = 8;
    EngBitmap->Height = 16;
    EngBitmap->PixelFormat = pf1bit;

    HanBitmap = new Graphics::TBitmap();
    HanBitmap->Width = 16;
    HanBitmap->Height = 16;
    HanBitmap->PixelFormat = pf1bit;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::ScrollBox1MouseWheelDown(TObject *Sender,
      TShiftState Shift, TPoint &MousePos, bool &Handled)
{
    ScrollBox1->VertScrollBar->Position =
        ScrollBox1->VertScrollBar->Position +
        ScrollBox1->VertScrollBar->Increment;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Image1MouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
    ScrollBox1->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ScrollBox1MouseWheelUp(TObject *Sender,
      TShiftState Shift, TPoint &MousePos, bool &Handled)
{
    ScrollBox1->VertScrollBar->Position =
        ScrollBox1->VertScrollBar->Position -
        ScrollBox1->VertScrollBar->Increment;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
    SetImageRows(Image1, 10, 20, 16, 16, clBlack);
}
//---------------------------------------------------------------------------

