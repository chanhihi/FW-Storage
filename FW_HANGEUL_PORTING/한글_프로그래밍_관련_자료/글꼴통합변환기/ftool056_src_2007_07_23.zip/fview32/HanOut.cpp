//---------------------------------------------------------------------------
#include <vcl.h>
#include <Graphics.hpp>
#pragma hdrstop

#include "..\hanlib\hanlib.h"
#include "HanOut.h"

Graphics::TBitmap *EngBitmap, *HanBitmap;   // 0.54 �߰�
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
void FloodFill(TCanvas *ACanvas, int ALeft, int ATop, int AWidth, int AHeight, TColor AColor)
{
	TRect FullRect;

    FullRect.Left = ALeft;
    FullRect.Top = ATop;
    FullRect.Right = ALeft + AWidth;
    FullRect.Bottom = ATop + AHeight;
    ACanvas->Brush->Color = AColor;
    ACanvas->FillRect(FullRect);
}
//---------------------------------------------------------------------------
void ClearCanvasGridCell(TCanvas *ACanvas, int ACol, int ARow, int AColWidth, int ARowHeight, TColor AColor)
{
	FloodFill(ACanvas, ACol * (AColWidth + 1) + 1, ARow * (ARowHeight + 1) + 1, AColWidth, ARowHeight, AColor);
}
//---------------------------------------------------------------------------
void ClearCanvasGrid(TCanvas *ACanvas, TColor AColor)
{
    ACanvas->Brush->Color = AColor;
    ACanvas->Brush->Style = bsSolid;
    ACanvas->FillRect(ACanvas->ClipRect);
}
//---------------------------------------------------------------------------
void PutBitmap8x16(TCanvas *ACanvas, int x, int y, byte *ABitmap16)
{
    for (int i = 0; i < 16; i++) {
        byte *p = (byte *)EngBitmap->ScanLine[i];
        p[0] = ~ABitmap16[i];
    }
    ACanvas->Draw(x, y, EngBitmap);
}
//---------------------------------------------------------------------------
void PutBitmap8x16InCell(TCanvas *ACanvas, int ACol, int ARow, byte *ABitmap16)
{
	PutBitmap8x16(ACanvas, ACol * (8 + 1) + 1, ARow * (16 + 1) + 1, ABitmap16);
}
//---------------------------------------------------------------------------
void PutBitmap16x16(TCanvas *ACanvas, int x, int y, byte *ABitmap32)
{
    for (int i = 0; i < 16; i++) {
        byte *p = (byte *)HanBitmap->ScanLine[i];
        p[0] = ~ABitmap32[2*i];
        p[1] = ~ABitmap32[2*i+1];
    }
    ACanvas->Draw(x, y, HanBitmap);
}
//---------------------------------------------------------------------------
void PutBitmap16x16InCell(TCanvas *ACanvas, int ACol, int ARow, byte *bitmap32)
{
	PutBitmap16x16(ACanvas, ACol * (16 + 1) + 1, ARow * (16 + 1) + 1, bitmap32);
}
//---------------------------------------------------------------------------
void SetImageColsRows(TImage *AImage, int AColCount, int ARowCount, int AColWidth, int ARowWidth)
{
    AImage->Width = ((AColWidth + 1) * AColCount) + 1;
    AImage->Height = ((ARowWidth + 1) * ARowCount) + 1;
    AImage->Picture->Bitmap->Width = AImage->Width;
    AImage->Picture->Bitmap->Height = AImage->Height;

    AImage->Canvas->Pen->Color = clTeal;

    for (int Row = 0; Row < ARowCount + 1; Row++) {
        AImage->Canvas->MoveTo(0, (ARowWidth + 1) * Row);
        AImage->Canvas->LineTo(AImage->Width, (ARowWidth + 1) * Row);
    }

    for (int Col = 0; Col < AColCount + 1; Col++) {
        AImage->Canvas->MoveTo((AColWidth + 1) * Col, 0);
        AImage->Canvas->LineTo((AColWidth + 1) * Col, AImage->Height);
    }
}
//---------------------------------------------------------------------------
void SetImageRows(TImage *AImage, int AColCount, int ARowCount, int AColWidth, int ARowWidth, TColor AGridColor)
{
    AImage->Width = (AColWidth * AColCount) + 1;
    AImage->Height = ((ARowWidth + 1) * ARowCount) + 1;
    AImage->Picture->Bitmap->Width = AImage->Width;
    AImage->Picture->Bitmap->Height = AImage->Height;

    AImage->Canvas->Pen->Color = AGridColor;

    for (int Row = 0; Row < ARowCount + 1; Row++) {
        AImage->Canvas->MoveTo(0, (ARowWidth + 1) * Row);
        AImage->Canvas->LineTo(AImage->Width, (ARowWidth + 1) * Row);
    }

    AImage->Canvas->MoveTo(0, 0);
    AImage->Canvas->LineTo(0, AImage->Height);

    AImage->Canvas->MoveTo(AImage->Width - 1, 0);
    AImage->Canvas->LineTo(AImage->Width - 1, AImage->Height);
}
//---------------------------------------------------------------------------




//---------------------------------------------------------------------------
void DrawEngFontTable(TCanvas *ACanvas, TEngFont *AEngFont)
{
    int EngIndex = 0;
    for (int Row = 0; Row < AEngFont->CharCount / 32; Row++) {
    	for (int Col = 0; Col < 32; Col++) {
    		PutBitmap8x16InCell(ACanvas, Col, Row, AEngFont->Eng[EngIndex++]);
        }
    }
}
//---------------------------------------------------------------------------
void DrawHanFontTable(TCanvas *ACanvasF1, TCanvas *ACanvasF2, TCanvas *ACanvasF3, THanFont *AHanFont)
{
    for (int Row = 0; Row < AHanFont->F1BulCount; Row++) {
    	for (int Col = 0; Col < AHanFont->F1Count; Col++)
    		PutBitmap16x16InCell(ACanvasF1, Col, Row, AHanFont->F1[Row][Col + !AHanFont->F_SKIP]);
    }
    for (int Row = 0; Row < AHanFont->F2BulCount; Row++) {
    	for (int Col = 0; Col < AHanFont->F2Count; Col++)
    		PutBitmap16x16InCell(ACanvasF2, Col, Row, AHanFont->F2[Row][Col + !AHanFont->F_SKIP]);
    }
    for (int Row = 0; Row < AHanFont->F3BulCount; Row++) {
    	for (int Col = 0; Col < AHanFont->F3Count; Col++)
    		PutBitmap16x16InCell(ACanvasF3, Col, Row, AHanFont->F3[Row][Col + !AHanFont->F_SKIP]);
    }
}
//---------------------------------------------------------------------------
void DrawSpcFontTable(TCanvas *ACanvas, TSpcFont *ASpcFont, int APage)
{
    int i = 0;

    for (int Row = 0; Row < 1; Row++)
        for (int Col = 1; Col < 16; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, ASpcFont->Spc[APage][i++]);
    for (int Row = 1; Row < 5; Row++)
        for (int Col = 0; Col < 16; Col++)
            PutBitmap16x16InCell(ACanvas, Col, Row, ASpcFont->Spc[APage][i++]);
    for (int Row = 5; Row < 6; Row++)
        for (int Col = 0; Col < 15; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, ASpcFont->Spc[APage][i++]);
}
//---------------------------------------------------------------------------
void DrawHanjaFontTable(TCanvas *ACanvas, THanjaFont *AHanjaFont, int APage)
{
    int i = 0;

    for (int Row = 0; Row < 1; Row++)
        for (int Col = 1; Col < 16; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, AHanjaFont->Hanja[APage][i++]);
    for (int Row = 1; Row < 5; Row++)
        for (int Col = 0; Col < 16; Col++)
            PutBitmap16x16InCell(ACanvas, Col, Row, AHanjaFont->Hanja[APage][i++]);
    for (int Row = 5; Row < 6; Row++)
        for (int Col = 0; Col < 15; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, AHanjaFont->Hanja[APage][i++]);
}
//---------------------------------------------------------------------------
void DrawSamboSpcFontTable(TCanvas *ACanvas, TSpcFont *ASpcFont)
{
    int Index = 0;
    for (int Row = 0; Row < 8; Row++)
    	for (int Col = 0; Col < 16; Col++)
            PutBitmap16x16InCell(ACanvas, Col, Row, ASpcFont->SamboSpc[Index++]);
}
//---------------------------------------------------------------------------
