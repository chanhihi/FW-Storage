//---------------------------------------------------------------------------
#ifndef HanTestH
#define HanTestH


#include "hanlib.h"
void CompleteHanChar(byte *ABuffer32, byte *AHanByte, THanFont *AHanFont);
bool ishangul1st(byte *s, int pos);
bool ishangul2nd(byte *s, int pos);

//---------------------------------------------------------------------------
#endif
