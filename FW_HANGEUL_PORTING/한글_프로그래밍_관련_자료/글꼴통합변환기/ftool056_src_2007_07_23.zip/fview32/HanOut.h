//---------------------------------------------------------------------------
#ifndef HanOutH
#define HanOutH
//---------------------------------------------------------------------------
void FloodFill(TCanvas *ACanvas, int ALeft, int ATop, int AWidth, int AHeight, TColor AColor);
void ClearCanvasGridCell(TCanvas *ACanvas, int ACol, int ARow, int AColWidth, int ARowHeight, TColor AColor);
void ClearCanvasGrid(TCanvas *ACanvas, TColor AColor);
void PutBitmap8(TCanvas *ACanvas, int x, int y, byte ABitmap);
void PutBitmap8x16(TCanvas *ACanvas, int x, int y, byte *ABitmap16);
void PutBitmap8x16InCell(TCanvas *ACanvas, int ACol, int ARow, byte *ABitmap16);
void PutBitmap16x16(TCanvas *ACanvas, int x, int y, byte *ABitmap32);
void PutBitmap16x16InCell(TCanvas *ACanvas, int ACol, int ARow, byte *bitmap32);
void SetImageColsRows(TImage *AImage, int AColCount, int ARowCount, int AColWidth, int ARowWidth);

void PutBitmap8Cell(TCanvas *ACanvas, int ACol, int ARow, TColor Color, TColor BKColor, byte ABitmap);
void PutBitmap8x16Cell(TCanvas *ACanvas, int ACol, int ARow, TColor Color, TColor BKColor, byte *ABitmap16);
void PutBitmap16x16Cell(TCanvas *ACanvas, int ACol, int ARow, byte *ABitmap32);

#include "..\hanlib\hanlib.h"
void DrawEngFontTable(TCanvas *ACanvas, TEngFont *AEngFont);
void DrawHanFontTable(TCanvas *ACanvasF1, TCanvas *ACanvasF2, TCanvas *ACanvasF3, THanFont *AHanFont);
void DrawSpcFontTable(TCanvas *ACanvas, TSpcFont *ASpcFont, int APage);
void DrawHanjaFontTable(TCanvas *ACanvas, THanjaFont *AHanjaFont, int APage);
void DrawSamboSpcFontTable(TCanvas *ACanvas, TSpcFont *ASpcFont);

extern Graphics::TBitmap *EngBitmap, *HanBitmap;    // 0.54 �߰�

void SetImageRows(TImage *AImage, int AColCount, int ARowCount, int AColWidth, int ARowWidth, TColor AGridColor);

//---------------------------------------------------------------------------
#endif
