//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "HanTest.h"

#include "hanlib.h"
#include "Johab.h"
#include "Table10x4x4.h"
#include "Table8x4x4.h"
#include "Table6x2x1.h"
#include "Table2x1x2.h"
#include "CP949Table.h"
#include "KS2JohabTable.h"
#include "CompleteKS.h"

#include "HanCodeConverter.h"


//---------------------------------------------------------------------------

#pragma package(smart_init)


//------------------------------------------------------------------------------
void CompleteHanChar(byte *ABuffer32, byte *AHanByte, THanFont *AHanFont)
{
    THangul _Hangul;
	bool flag = true;

    _Hangul.HanByte.Byte0 = AHanByte[0];
    _Hangul.HanByte.Byte1 = AHanByte[1];

    int F1 = _CodeTable[0][_Hangul.HanCode.F1];
    int F2 = _CodeTable[1][_Hangul.HanCode.F2];
    int F3 = _CodeTable[2][_Hangul.HanCode.F3];

    int F3B = AHanFont->pF3B[F2];
    int F2B = AHanFont->pF2B[F1 * 2 + (F3 != 0)];
    int F1B = AHanFont->pF1B[F2 * 2 + (F3 != 0)];

    if (F1) HanComplete(true, ABuffer32, AHanFont->F1[F1B][F1], 32), flag = false;
    if (F2) HanComplete(flag, ABuffer32, AHanFont->F2[F2B][F2], 32), flag = false;
    if (F3)	HanComplete(flag, ABuffer32, AHanFont->F3[F3B][F3], 32), flag = false;
}
//------------------------------------------------------------------------------
#include <ctype.h>
#include <string.h>

bool ishangul1st(byte *s, int pos)
{
    int i;

    if (pos < 0 || (unsigned)pos > strlen(s) - 2 || s[pos] < 128) return false;

    for (i = 0; i < pos; )
        if (isascii(s[i])) i++;
        else i += 2;

    return ((i == pos) ? true : false);
}

bool ishangul2nd(byte *s, int pos)
{
    int i;

    if (pos < 1 || (unsigned)pos > strlen(s) - 1 || s[pos - 1] < 128) return false;

    for (i = 0; i < pos; )
        if (isascii(s[i])) i++;
        else i += 2;

    return ((i == pos + 1) ? true : false);
}
