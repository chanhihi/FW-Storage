//---------------------------------------------------------------------------
#include <vcl.h>
#include <ComCtrls.hpp>
#include <SysUtils.hpp>
#pragma hdrstop

#include <stdio.h>
#include <dir.h>
#include "..\hanlib\hanlib.h"
#include "Common.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
String GetTempFullPathAndFileName(String APrefixString)
{
    char TempPath[MAX_PATH];
    char TempFullPathAndFileName[MAX_PATH];

    GetTempPath(MAX_PATH, TempPath);
    GetTempFileName(TempPath, APrefixString.c_str(), 0, TempFullPathAndFileName);

    return String(TempFullPathAndFileName);
}
//---------------------------------------------------------------------------
String GetTempPathName(void)
{
    char TempPath[MAX_PATH];

    GetTempPath(MAX_PATH, TempPath);

    return String(TempPath) + "ftool054\\";;
}
//---------------------------------------------------------------------------
bool FileMerge_Two2One(String ADestFile, String ASrcFile1, String ASrcFile2)
{
    String TmpBatchFile = GetTempFullPathAndFileName("") + ".BAT";
    String Cmd = "COPY /B /Y \"" + ASrcFile1 + "\" + \"" + ASrcFile2 +  "\" \"" + ADestFile + "\"";
    FILE *fp = fopen(TmpBatchFile.c_str(), "wt");
    if (fp == NULL) {
        ShowMessage("���� ������ �ۼ��ϴ� �� ������ �߻��Ͽ����ϴ�.\n\n" + TmpBatchFile);
        return false;
    }
    fprintf(fp, "%s", Cmd.c_str());
    fclose(fp);

    WinExec(TmpBatchFile.c_str(), SW_HIDE);

    return true;
}
//---------------------------------------------------------------------------
bool FileMerge_Three2One(String ADestFile, String ASrcFile1, String ASrcFile2, String ASrcFile3)
{
    String TmpBatchFile =  GetTempFullPathAndFileName("") + ".BAT";
    String Cmd = "COPY /B /Y";
    Cmd = Cmd + " \"" + ASrcFile1 + "\" +";
    Cmd = Cmd + " \"" + ASrcFile2 + "\" +";
    Cmd = Cmd + " \"" + ASrcFile3 + "\"";
    Cmd = Cmd + " \"" + ADestFile + "\"";

    FILE *fp = fopen(TmpBatchFile.c_str(), "wt");
    if (fp == NULL) {
        ShowMessage("���� ������ �ۼ��ϴ� �� ������ �߻��Ͽ����ϴ�.\n\n" + TmpBatchFile);
        return false;
    }
    fprintf(fp, "%s", Cmd.c_str());
    fclose(fp);

    WinExec(TmpBatchFile.c_str(), SW_HIDE);

    return true;
}
//---------------------------------------------------------------------------
void ShowMessage2(String AMsg)
{
    MessageDlg(AMsg, mtInformation, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------
int ShowYesNoMsgDlg(String AMsg)
{
    return MessageDlg(AMsg, mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0);
}
//---------------------------------------------------------------------------
int ShowErrorMessage(String AErrorMsg)
{
    return MessageDlg(AErrorMsg, mtError, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------
void ShellExec(String AFileName)
{
    HINSTANCE hInstance1;
    hInstance1 = ShellExecute(Application->Handle, "", AFileName.c_str(), "", NULL, SW_SHOWNORMAL);
    if ((int)hInstance1 <= 32) {
        ShowErrorMessage("���� ������ �����ϴ� �� ������ �߻��Ͽ����ϴ�!\n\n" + AFileName);
        return;
    }
}
//---------------------------------------------------------------------------
bool isFixedPitchFont(TTextMetric *ATextMetric)
{
    if ((ATextMetric->tmPitchAndFamily & TMPF_FIXED_PITCH) == TMPF_FIXED_PITCH)
        return false;

    return true;
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
int RemoveComma(String AText)
{
    if (AText == "") return -1;

    String Result = "";
    for (int i = 1; i <= AText.Length(); i++)
        if (AText.SubString(i, 1) != ",")
            Result += AText.SubString(i, 1);

    return StrToInt(Result);
}
//---------------------------------------------------------------------------
String InsertComma(int AValue)
{
    if (AValue == 0) return "0";
    return FormatFloat("#,###", AValue);
}
//---------------------------------------------------------------------------
String ExtractFileNameOnly(String AFileName)
{
    AFileName = ExtractFileName(AFileName);

    int Len = AFileName.LastDelimiter(".") - 1;
    AFileName.SetLength(Len);

    return AFileName;
}
//---------------------------------------------------------------------------
bool LastCharIsPathDelimiter(String AValue)
{
    int index = AValue.Length();

    return AValue.IsPathDelimiter(index);
}
//---------------------------------------------------------------------------
String AddPathDelimiter(String AValue)
{
    if (!LastCharIsPathDelimiter(AValue))
        return (AValue + "\\");

    return AValue;
}
//---------------------------------------------------------------------------
bool IsNumString(String AValue)
{
    if (AValue == "") return false;

    for (int i = 1; i <= AValue.Length(); i++)
    	if (!isdigit(AValue[i])) return false;

    return true;
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
int GetSelectedListCount(TListView *AListView, String AFileExt)
{
    int SelCount = 0;

    if (AFileExt == ".*") {
        for (int i = 0; i < AListView->Items->Count; i++)
            if (AListView->Items->Item[i]->Selected) SelCount++;
    } else {
        for (int i = 0; i < AListView->Items->Count; i++) {
            if (AListView->Items->Item[i]->Selected) {
                String FileExt = ExtractFileExt(AListView->Items->Item[i]->Caption);
                if (FileExt.LowerCase() == AFileExt.LowerCase()) SelCount++;
            }
        }
    }

    return SelCount;
}
//---------------------------------------------------------------------------
int GetSelectedListItems(TStringList *AStringList, TListView *AListView, String ADirPath, String AFileExt)
{
    AStringList->Clear();

    if (AFileExt == ".*") {
        for (int i = 0; i < AListView->Items->Count; i++) {
            if (AListView->Items->Item[i]->Selected)
                AStringList->Add(ADirPath + AListView->Items->Item[i]->Caption);
        }
    } else {
        for (int i = 0; i < AListView->Items->Count; i++) {
            if (AListView->Items->Item[i]->Selected) {
                String FileExt = ExtractFileExt(AListView->Items->Item[i]->Caption);
                if (FileExt.LowerCase() == AFileExt.LowerCase())
                    AStringList->Add(ADirPath + AListView->Items->Item[i]->Caption);
            }
        }
    }

    return AStringList->Count;
}
//---------------------------------------------------------------------------
void GetFileList(TListView *AListView, String ADirPath, String AFileExt, String AFileSize)
{
    TListItem *ListItem1;
    String FileExt, FileSize;
    struct ffblk ffblk1;
    int done1;

    AListView->Items->BeginUpdate();
    AListView->Items->Clear();

    done1 = findfirst(String(ADirPath + "*.*").c_str(), &ffblk1, 0);
    while (!done1) {
        FileExt = ";" + ExtractFileExt(ffblk1.ff_name) + ";";
        if (AFileExt.Pos(FileExt.LowerCase())) goto p1;

        FileSize = ";" + IntToStr(ffblk1.ff_fsize) + ";";
        if (AFileSize.Pos(FileSize.LowerCase())) goto p1;

        if ((AFileExt == "") && (AFileSize == "")) goto p1;
        else goto p2;
p1:
        ListItem1 = AListView->Items->Add();
        ListItem1->Caption = ffblk1.ff_name;
        ListItem1->SubItems->Add(InsertComma(ffblk1.ff_fsize));
        ListItem1->SubItems->Add(ExtractFileExt(ffblk1.ff_name));
        ListItem1->SubItems->Add(GetFontType(ffblk1.ff_fsize));
p2:
        done1 = findnext(&ffblk1);
    }
    AListView->Items->EndUpdate();
}
//---------------------------------------------------------------------------
bool IsBitmapFontSize(int AFileSize)
{
    if (IsEngFontSize(AFileSize)) return true;
    if (IsHanFontSize(AFileSize)) return true;
    if (IsSpcFontSize(AFileSize)) return true;
    if (IsHanjaFontSize(AFileSize)) return true;

    return false;
}
//---------------------------------------------------------------------------
String GetFontType(int AFileSize)
{
    switch (AFileSize) {
    case 2048: return "����128";
    case 4096: return "����256 �Ǵ� �ﺸ Ư������128";
    case 4112: return "�Ѹ� ����256";

    case 3616: return "2��1��2 (�Ѷ����� �۲�)";
    case 3776: return "2��1��2";
    case 6176: return "6��2��1";
    case 11008: return "8��4��4 (�Ѷ����� �۲�)";
    case 11520: return "8��4��4 (������ �۲�)";
    case 12224: return "10��4��4 (�Ѷ����� �۲�)";
    case 12800: return "8��4��4 (�̾߱� 6.0) �Ǵ� 10��4��4";
    case 13056: return "8��4��4 (�̾߱� 6.1 �̻�)";

    case 33696: return "Ư������1053 (���鹮�� 75���� ���ŵ� ����)";
    case 36096: return "Ư������1128";
    case 156416: return "ǥ������4888";
    }

    return "";
}
//---------------------------------------------------------------------------
void AddCnvtMsg(TMemo *AMemo, String AOutputName, String ABDFFileName, int ACurIndex, int ATotalCount)
{
    String s = "";
    s = ExtractFileName(ABDFFileName) + " �� " + ExtractFileName(AOutputName) + " ��ȯ�ϴ� ��.....";
    s = s + "(" + IntToStr(ACurIndex) + " / " + IntToStr(ATotalCount) + ")";
    AMemo->Lines->Add(s);
    Application->ProcessMessages();
}
//---------------------------------------------------------------------------
String AddResultMsg(TMemo *AMemo, String ADest, String ASrc, int ACount)
{
    String s = "�� " + IntToStr(ACount) + "���� " + ASrc + "�� " + ADest + "�� ��ȯ�Ͽ����ϴ�!";
    AMemo->Lines->Add("\r\n" + s + "\r\n");

    return s;
}
//---------------------------------------------------------------------------
String AddErrorMsg(TMemo *AMemo, String AErrorMsg)
{
    AErrorMsg += "\n\n������ �߻��Ͽ� ��ȯ �۾��� �ߴܵǾ����ϴ�!";
    AErrorMsg = StringReplace(AErrorMsg, "\n", "\r\n", TReplaceFlags() << rfReplaceAll);
    AMemo->Lines->Add("\r\n" + AErrorMsg + "\r\n");

    return AErrorMsg;
}
//---------------------------------------------------------------------------
// 0.54 �߰� - start
void GetAllFile(TStringList *strlstFileName, AnsiString strPath)
{
    // �������� ��� ȭ���̸� ���
    TSearchRec sr;
    try {
        if (FindFirst(strPath + "*.*", faAnyFile, sr) == 0) {
            do {
                if (sr.Name != "." && sr.Name != ".." && sr.Attr != faDirectory) strlstFileName->Add(strPath + sr.Name);
            } while (FindNext(sr) == 0);
        }
    } __finally {
        FindClose(sr);
    }
}

void GetDescendantDir(TStringList *strlstDirNames, AnsiString strPath)
{
    // �θ� �������� ��� �ڽ����� �̸� ��� (��� ȣ��)
    TSearchRec sr;
    try {
        if (FindFirst(strPath + "*.*", faAnyFile, sr) ==0 ) {
            do {
                if (sr.Name != "." && sr.Name != ".." && sr.Attr == faDirectory) {
                    strlstDirNames->Add(strPath + sr.Name + "\\");
                    GetDescendantDir(strlstDirNames, strPath + sr.Name + "\\");
                }
            } while(FindNext(sr) == 0);
        }
    } __finally {
        FindClose(sr);
    }
}

void DeleteDir(AnsiString strPath)
{
    //  GetDescendantDir�� GetAllFile�� �̿��ؼ� ���丮�� �����.
    TStringList *strlstDescPath = new TStringList;
    TStringList *strlstFileName = new TStringList;
    try {
        strlstDescPath->Add(strPath);
        GetDescendantDir(strlstDescPath, strPath);
        while (strlstDescPath->Count) {
            GetAllFile(strlstFileName, strlstDescPath->Strings[strlstDescPath->Count-1]);
            while (strlstFileName->Count) {
                DeleteFile(strlstFileName->Strings[0]);
                strlstFileName->Delete(0);
            }
            RemoveDir(strlstDescPath->Strings[strlstDescPath->Count-1]);
            strlstDescPath->Delete(strlstDescPath->Count-1);
        }
    } __finally {
        delete strlstDescPath;
        delete strlstFileName;
    }
}
// 0.54 �߰� - end
//---------------------------------------------------------------------------
