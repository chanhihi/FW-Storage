//------------------------------------------------------------------------------
#ifndef __PLAYER_H
#define __PLAYER_H
//------------------------------------------------------------------------------
#include <stdio.h>
#include "datatype.h"
#include "bnk.h"
#include "rol.h"
#include "ims.h"
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//------------------------------------------------------------------------------
#define _R	CurrentROLFile
#define _I	CurrentIMSFile

typedef enum {NONE_PLAY_MODE, ROL_MODE, IMS_MODE, SOP_MODE} TPLAY_MODE;
extern TPLAY_MODE PLAY_MODE;

extern TROLFile *CurrentROLFile;
extern TIMSFile *CurrentIMSFile;

extern FILE *fpROLDEBUG;
extern FILE *fpIMSDEBUG;

void InitPlayer(void);
void ResetPlayer(void);
BOOL StartPlay(void);
void StopPlay(void);
//------------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif	//__PLAYER_H
