#ifdef __BORLANDC__
#pragma warn -8057
#pragma warn -8004
#pragma warn -8071
#endif

#include "waveloop.h"
#include "rolplay.h"
#include "imsplay.h"
#include "player.h"

#define WM_PREPARE_NEXTWAVE		(WM_USER+1)
#define BUFFERSIZE				0xFFFF		// 64KB ũ���� ���۸�
#define BUFFERCOUNT				10			// 10�� �غ��Ѵ�

//------------------------------------------------------------------------------
HWAVEOUT		hWaveOut1;
WAVEHDR			WaveHdr1[BUFFERCOUNT];
WAVEFORMATEX	WaveFormatEx1;
char			WaveBuffer[BUFFERCOUNT][BUFFERSIZE];
int				BufferIndex = 0;

BOOL			isWaveActive = FALSE;
int				RemainSamples = 0;

//------------------------------------------------------------------------------
BOOL WaveLoop_Init(void)
{
	int nDevs, i;
	MMRESULT MMResult1;

	hWaveOut1 = NULL;
	isWaveActive = FALSE;

	nDevs = waveOutGetNumDevs();
	if (nDevs == 0) return FALSE;

	WaveFormatEx1.wFormatTag		= WAVE_FORMAT_PCM;
	WaveFormatEx1.nChannels			= 1;					// ä�� �� (1=���, 2=���׷���)
	WaveFormatEx1.wBitsPerSample	= 16;					// ���� �� ��Ʈ �� (8 �Ǵ� 16)
	WaveFormatEx1.nSamplesPerSec	= WAVE_SAMPLING_RATE;	// 44kHz
	WaveFormatEx1.nBlockAlign		= WaveFormatEx1.nChannels * WaveFormatEx1.wBitsPerSample / 8;	// == 1 x 16 / 8 == 2
	WaveFormatEx1.nAvgBytesPerSec	= WaveFormatEx1.nSamplesPerSec * WaveFormatEx1.nBlockAlign;	// == 44100 x 2 == 88200
	WaveFormatEx1.cbSize			= 0;

	for (i = 0; i < nDevs; i++) {
		MMResult1 = waveOutOpen((LPHWAVEOUT)&hWaveOut1, i, (WAVEFORMATEX *)&WaveFormatEx1, (DWORD)waveOutProc, (LPARAM)0L, CALLBACK_FUNCTION);
		if (MMResult1 == MMSYSERR_ALLOCATED) continue;
		if (MMResult1 == MMSYSERR_NOERROR) goto initOK;
	}

	return FALSE;

	initOK://-------------------------------------------------------------------
	memset(WaveHdr1, 0, sizeof(WAVEHDR) * BUFFERCOUNT);
	for (i = 0; i < BUFFERCOUNT; i++) {
		WaveHdr1[i].lpData = WaveBuffer[i];
		WaveHdr1[i].dwBufferLength = BUFFERSIZE;
	}

	return TRUE;
}
//------------------------------------------------------------------------------
void WaveLoop_Release(void)
{
	if (hWaveOut1 != NULL)	{
		waveOutReset(hWaveOut1);
		waveOutClose(hWaveOut1);
		hWaveOut1 = NULL;
	}
}
//------------------------------------------------------------------------------
BOOL WaveLoop_Prepare(void)
{
	int i;
	MMRESULT MMResult1;

	isWaveActive = TRUE;

	waveOutReset(hWaveOut1);
	waveOutPause(hWaveOut1);

	BufferIndex = 0;
	WaveHdr1[0].dwFlags = WHDR_BEGINLOOP;
	WaveHdr1[BUFFERCOUNT - 1].dwFlags = WHDR_ENDLOOP;

	for (i = 0; i < BUFFERCOUNT; i++) {
		MMResult1 = waveOutPrepareHeader(hWaveOut1, &WaveHdr1[i], sizeof(WAVEHDR));
		if (MMResult1 != MMSYSERR_NOERROR) return FALSE;
	}

	return TRUE;
}
//------------------------------------------------------------------------------
void WaveLoop_Stop(void)
{
	int i;

	if (isWaveActive == FALSE) return;
	else isWaveActive = FALSE;

	waveOutPause(hWaveOut1);

	for (i = 0; i < BUFFERCOUNT; i++) {
		if ((WaveHdr1[i].dwFlags & WHDR_PREPARED) != 0) {
			waveOutUnprepareHeader(hWaveOut1, &WaveHdr1[i], sizeof(WAVEHDR));
			WaveHdr1[i].dwFlags = WaveHdr1[i].dwFlags & ~WHDR_PREPARED;
		}
	}

	waveOutReset(hWaveOut1);
}
//------------------------------------------------------------------------------
BOOL WaveLoop_IsActive(void)
{
	return isWaveActive;
}
//------------------------------------------------------------------------------
BOOL PrepareNextWave(void)
{
	int ToWrite, Samples;
	int TickDelay = 0;
	short int *BufferPos;
	MMRESULT MMResult1;

	ToWrite = BUFFERSIZE / 2;

	BufferPos = (short int *)WaveHdr1[BufferIndex].lpData;

	while (ToWrite > 0) {
		if (RemainSamples > 0) Samples = RemainSamples;
		else {
	        TickDelay = 0;
            switch (PLAY_MODE) {
            case ROL_MODE:
            	TickDelay = OnROLPlayEvent();
				Samples = MulDiv(WAVE_SAMPLING_RATE * 60, TickDelay, ROLTempo * 240);
                break;
            case IMS_MODE:
            	TickDelay = OnIMSPlayEvent();
				Samples = MulDiv(WAVE_SAMPLING_RATE * 60, TickDelay, IMSTempo * _I->Header.nTickBeat);
                break;
			case SOP_MODE: break;
			case NONE_PLAY_MODE: break;
            }
		}

		if (Samples > ToWrite) {
			YM3812UpdateOne(ym3812p, BufferPos, ToWrite);
			RemainSamples = Samples - ToWrite;
			break;
		} else {
			YM3812UpdateOne(ym3812p, BufferPos, Samples);
			RemainSamples = 0;
		}

		BufferPos = BufferPos + Samples;
		ToWrite = ToWrite - Samples;
	}

	MMResult1 = waveOutWrite(hWaveOut1, &WaveHdr1[BufferIndex], sizeof(WAVEHDR));
	if (MMResult1 != MMSYSERR_NOERROR) return FALSE;

	BufferIndex++;
	if (BufferIndex >= BUFFERCOUNT) BufferIndex = 0;

	return TRUE;
}
//------------------------------------------------------------------------------
void CALLBACK waveOutProc(HWAVEOUT hwo, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
{
	if (uMsg == MM_WOM_DONE)
    	if (PrepareNextWave() == FALSE) StopPlay();
        
	if (PLAY_MODE == NONE_PLAY_MODE) StopPlay();
}
//------------------------------------------------------------------------------

