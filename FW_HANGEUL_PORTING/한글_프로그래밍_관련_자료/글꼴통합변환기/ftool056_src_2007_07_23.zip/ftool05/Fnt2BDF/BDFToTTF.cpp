//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include "Common.h"
#include "..\..\bdf2ttf20\main.h"

#include "BDFToTTF.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
String GetBDFProperty(String ABDFFileName, String AProperty)
{
    FILE *fp = fopen(ABDFFileName.c_str(), "rt");
    if (fp == NULL) return "";

    int LineCount = 0;
    char s[256], Value[256];
    while (!feof(fp)) {
        fgets(s, 256+1, fp);
        if (strstr(s, AProperty.c_str())) {
            fclose(fp);
            char *s1 = strstr(s, "\"");
            if (!s1) return "";
            char *s2 = strstr(s1 + 1, "\"");
            if (!s1) return "";
            strncpy(Value, s1 + 1, s2 - s1 - 1);
            Value[s2 - s1 - 1] = '\0';
            return (String)Value;
        }
        if (++LineCount > 100) break;
    }

    fclose(fp);
    return "";
}
//---------------------------------------------------------------------------
#define PC_OS
#include "TTFName\fscdefs.h"
#include "TTFName\sfnt.h"
char *GetFontNameFromTTF(char *AFontName, char *ATTFFileName)
{
	static char	namebuf[255];
	unsigned short numNames;
	sfnt_OffsetTable    OffsetTable;
	sfnt_DirectoryEntry Table;
	sfnt_NamingTable    NamingTable;
	sfnt_NameRecord     NameRecord;

    FILE *fp = fopen(ATTFFileName, "rb");
	if (fp == NULL)	return NULL;

	fread(&OffsetTable, sizeof(OffsetTable) - sizeof(sfnt_DirectoryEntry), 1, fp);
	unsigned short cTables = (unsigned short) SWAPW (OffsetTable.numOffsets);

	for (int i = 0; (i < cTables) && (i < 40); i++) {
        size_t items = fread(&Table, sizeof(Table), 1, fp);
        if (items != 1) {
			sprintf(AFontName, "Read failed on table #%d\n", i);
			return NULL;
		}
		if (Table.tag == tag_NamingTable) {
			fseek(fp, SWAPL(Table.offset), SEEK_SET);
			fread(&NamingTable, sizeof(NamingTable), 1, fp);
			numNames = SWAPW(NamingTable.count);
			while (numNames--) {
				fread(&NameRecord, sizeof(NameRecord), 1, fp);
				long curseek = ftell(fp);
				if (SWAPW(NameRecord.platformID) == 1 && SWAPW(NameRecord.nameID) == 4) {
					fseek(fp, SWAPW (NameRecord.offset) + SWAPW(NamingTable.stringOffset) + SWAPL(Table.offset), SEEK_SET);
					fread(namebuf, SWAPW(NameRecord.length), 1, fp);
                    unsigned short LastIndex = SWAPW(NameRecord.length);
					namebuf[LastIndex] = NULL;
					fseek(fp, curseek, SEEK_SET);
				}
			}
			goto cleanup;
		}

	}
	return NULL;

	cleanup:

	strcpy(AFontName, namebuf);
    return namebuf;
}
//---------------------------------------------------------------------------
String GetTTFFontName(String ATTFFileName)
{
    static char FontName[255];

    bool result = GetFontNameFromTTF(FontName, ATTFFileName.c_str());
    if (result) {
        String FontName2 = Utf8ToAnsi(FontName);
        if (FontName2 == "") return FontName;
        else return FontName2;
    }

    return "";
}
//---------------------------------------------------------------------------
bool SaveTTFInfoFile(String ASaveFileName, TTTFIniInfo *ATTFIniInfo)    // 0.54 ���� : void -> bool
{
    String s =
        "Copyright = "		+ ATTFIniInfo->ACopyright   + "\n" +
        "Fontname = "		+ ATTFIniInfo->AFontname    + "\n" +
        "Version = "		+ ATTFIniInfo->AVersion     + "\n" +
        "Trademark = "		+ ATTFIniInfo->ATrademark   + "\n" +
        "CopyrightCP = "	+ ATTFIniInfo->ACopyrightCP + "\n" +
        "FontnameCP = "     + ATTFIniInfo->AFontnameCP  + "\n" +
        "TrademarkCP = "	+ ATTFIniInfo->ATrademarkCP;

    s = AnsiToUtf8(s);

    // 0.54 �߰�
    String TmpPath = GetTempPathName();
    if (!DirectoryExists(TmpPath)) CreateDir(TmpPath);
    //--------------------------------------------------------------------------
    FILE *fp = fopen(ASaveFileName.c_str(), "wb");
    if (fp == NULL) return false;   // 0.54 �߰�
    fwrite(s.c_str(), strlen(s.c_str()), 1, fp);
    fclose(fp);

    return true;    // 0.54 �߰�
}
//---------------------------------------------------------------------------
String ConvertBDF2TTF(String ASaveTTFName, String ALoadBDFName)
{
    String FontName = GetBDFProperty(ALoadBDFName, "FAMILY_NAME");
    if (FontName == "") FontName = ExtractFileNameOnly(ALoadBDFName);
    if (FontName.UpperCase() == "SYSTEM") FontName += "1";
    if (FontName.Length() > 32) FontName.SetLength(32);
    String Copyright = GetBDFProperty(ALoadBDFName, "COPYRIGHT");

    TTTFIniInfo TTFIniInfo1;
    TTFIniInfo1.ACopyright = Copyright + " �� " + ExtractFileName(ASaveTTFName.UpperCase());
    TTFIniInfo1.AFontname = FontName;
    TTFIniInfo1.AVersion = Now();

    String SaveIniName = GetTempPathName() + ExtractFileName(ASaveTTFName) + ".ini";
    if (!SaveTTFInfoFile(SaveIniName, &TTFIniInfo1))            // 0.54 ����
        return "���� ������ ���� �� Error!\n\n" + SaveIniName;  // 0.54 ����

    char *argv[6];
    argv[0] = "bdf2ttf.exe";
    argv[1] = ASaveTTFName.c_str();
    argv[2] = SaveIniName.c_str();
    argv[3] = ALoadBDFName.c_str();
    argv[4] = NULL;
    argv[5] = NULL;

    int result = bdf2ttf_main(4, argv);
    if (result == EXIT_FAILURE) return (String)_bdf2ttf_msg;

    return "";
}
//---------------------------------------------------------------------------
