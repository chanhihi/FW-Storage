//---------------------------------------------------------------------------
#ifndef PreviewFrameUnitH
#define PreviewFrameUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <ComCtrls.hpp>
#include <Controls.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <ExtDlgs.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <Menus.hpp>
#include <StdCtrls.hpp>
#include "CSPIN.h"
#include "BrowseDr.hpp"
#include "dfsSplitter.hpp"
#include "TB2Dock.hpp"
//---------------------------------------------------------------------------
class TPreviewFrame : public TFrame
{
__published:	// IDE-managed Components
    TBevel *Bevel1;
    TCSpinEdit *spe_HanjaFontPage;
    TCSpinEdit *spe_SpcFontPage;
    TGroupBox *GroupBox1;
    TGroupBox *gb_EngFontInfo;
    TGroupBox *gb_HanFontInfo;
    TGroupBox *gb_SamboSpcFontInfo;
    TGroupBox *gb_SpcFontInfo;
    TImage *Image1;
    TImage *img_EngChar16x;
    TImage *img_EngFont;
    TImage *img_HanChar16x;
    TImage *img_HanFontF1;
    TImage *img_HanFontF2;
    TImage *img_HanFontF3;
    TImage *img_HanjaFont;
    TImage *img_SamboSpcFont;
    TImage *img_SpcFont;
    TLabel *Label1;
    TLabel *Label2;
    TListBox *lb_EngFontInfo;
    TListBox *lb_FontInfo;
    TListBox *lb_HanFontInfo;
    TListBox *lb_HanjaFontInfo;
    TListBox *lb_SamboSpcFontInfo;
    TListBox *lb_SpcFontInfo;
    TListBox *lb_TextMetricMaxValue;
    TListBox *lb_TextMetricMinValue;
    TListBox *lb_TextMetricProp;
    TMemo *mm_MaxFontTest;
    TMemo *mm_MinFontTest;
    TMenuItem *BMP1;
    TPageControl *pg_Char16x;
    TPageControl *pg_FontPreview;
    TPaintBox *pb_FontMaxSize;
    TPaintBox *pb_FontMinSize;
    TPanel *Panel1;
    TPopupMenu *PopupMenu1;
    TSavePictureDialog *SavePictureDialog1;
    TScrollBox *sb_BMPFile;
    TScrollBox *sb_HanFont;
    TSplitter *Splitter1;
    TSplitter *Splitter3;
    TTabSheet *TabSheet1;
    TTabSheet *ts_BMPFile;
    TTabSheet *ts_EngFont;
    TTabSheet *ts_HanFont;
    TTabSheet *ts_HanjaFont;
    TTabSheet *ts_SamboSpcFont;
    TTabSheet *ts_SpcFont;
    TTabSheet *ts_SystemFontInfo;
    TTabSheet *ts_ViewChar16x;
    void __fastcall BMP1Click(TObject *Sender);
    void __fastcall img_EngFontContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled);
    void __fastcall img_EngFontMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall img_HanFontF1ContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled);
    void __fastcall img_HanFontF1MouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall img_HanFontF2ContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled);
    void __fastcall img_HanFontF2MouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall img_HanFontF3ContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled);
    void __fastcall img_HanFontF3MouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall img_HanjaFontContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled);
    void __fastcall img_HanjaFontMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall img_SamboSpcFontContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled);
    void __fastcall img_SamboSpcFontMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall img_SpcFontContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled);
    void __fastcall img_SpcFontMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall lb_TextMetricPropClick(TObject *Sender);
    void __fastcall spe_HanjaFontPageChange(TObject *Sender);
    void __fastcall spe_SpcFontPageChange(TObject *Sender);
    void __fastcall ts_EngFontShow(TObject *Sender);
    void __fastcall ts_HanFontShow(TObject *Sender);
    void __fastcall ts_HanjaFontShow(TObject *Sender);
    void __fastcall ts_SamboSpcFontShow(TObject *Sender);
    void __fastcall ts_SpcFontShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TPreviewFrame(TComponent* Owner);

    TImage *CurImage;

	void PreviewBitmapFont(String AFileName, int AFileSize);
    void GetTextMetricProp(TListBox *AListBox, TFont *AFont, TTextMetric *ATextMetric);
    void InitPreviewFrame();
    void PreviewSystemFont(TFont *AFont);
    void PreviewSystemFontMaxSize(int AFontSize);
    void PreviewSystemFontMinSize(int AFontSize);
};
//---------------------------------------------------------------------------
extern PACKAGE TPreviewFrame *PreviewFrame;
//---------------------------------------------------------------------------
#endif
