//---------------------------------------------------------------------------
#ifndef Sys2BDFFrameUnitH
#define Sys2BDFFrameUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include "CSPIN.h"
#include "dfsSplitter.hpp"
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include "BrowseDr.hpp"
#include <Menus.hpp>
#include <ImgList.hpp>
//---------------------------------------------------------------------------
class TSys2BDFFrame : public TFrame
{
__published:	// IDE-managed Components
    TBitBtn *bitbtn_ConvertToBDF;
    TBitBtn *bitbtn_StopConverting;
    TButton *btn_AddFontList;
    TButton *btn_DeleteFontList;
    TButton *btn_SavePath;
    TButton *btn_SelSystemFont;
    TCSpinEdit *se_SizeMax;
    TCSpinEdit *se_SizeMin;
    TCheckBox *cbx_IncludeEngFont;
    TCheckBox *cbx_IncludeHanFont;
    TCheckBox *cbx_IncludeHanjaFont;
    TCheckBox *cbx_IncludeSpcFont;
    TComboBox *cbx_CRLF;
    TComboBox *cbx_Encoding;
    TFontDialog *FontDialog1;
    TGroupBox *gb_IncludeFont;
    TGroupBox *gb_Options;
    TGroupBox *gb_SelSysFont;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label54;
    TLabel *lb_SelectedSystemFontName;
    TLabel *lb_SizeMax0;
    TLabel *lb_SizeMin0;
    TLabeledEdit *lbe_SavePath;
    TListView *lv_SrcList;
    TMemo *mm_ProgressMsg;
    TMenuItem *N8;
    TMenuItem *mi_DeleteSourceList;
    TMenuItem *mi_SelectSourceListAll;
    TPaintBox *pb_FontTest;
    TPanel *Panel3;
    TPanel *pn_AddOrDeleteSrcList;
    TPanel *pn_SavePath;
    TPanel *pn_SysFontOption;
    TPopupMenu *pm_SourceList;
    TSplitter *spl_ProgressMsg;
    TSplitter *spl_SrcList;
    TdfsBrowseDirectoryDlg *dfsBrowseDirectoryDlg1;
    TImageList *ImageList1;
    void __fastcall bitbtn_ConvertToBDFClick(TObject *Sender);
    void __fastcall bitbtn_StopConvertingClick(TObject *Sender);
    void __fastcall btn_AddFontListClick(TObject *Sender);
    void __fastcall btn_DeleteFontListClick(TObject *Sender);
    void __fastcall btn_SavePathClick(TObject *Sender);
    void __fastcall btn_SelSystemFontClick(TObject *Sender);
    void __fastcall cbx_EncodingChange(TObject *Sender);
    void __fastcall lv_SrcListDblClick(TObject *Sender);
    void __fastcall lv_SrcListKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
    void __fastcall mi_DeleteSourceListClick(TObject *Sender);
    void __fastcall mi_SelectSourceListAllClick(TObject *Sender);
    void __fastcall se_SizeMaxChange(TObject *Sender);
    void __fastcall se_SizeMinChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TSys2BDFFrame(TComponent* Owner);

    TStringList *SysFontList;
    TPreviewFrame *PreviewFrame1;

	void InitPreviewFrame();
    void ChangeFont(TFont *AFont);
    void DisableUserInput();
    void EnableUserInput();
    void SystemFontToBDF();
};
//---------------------------------------------------------------------------
extern PACKAGE TSys2BDFFrame *Sys2BDFFrame;
//---------------------------------------------------------------------------
#endif
