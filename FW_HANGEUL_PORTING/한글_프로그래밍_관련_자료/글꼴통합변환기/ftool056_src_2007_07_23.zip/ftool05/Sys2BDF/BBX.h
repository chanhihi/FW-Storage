//---------------------------------------------------------------------------
#ifndef BBXH
#define BBXH
//---------------------------------------------------------------------------
typedef struct {
	int Encoding;
    int SWidth;
	int DWidth;
    int BBw, BBh, BBxoff0x, BByoff0y;
    String Bitmap;
} TCharBBXInfo;

String	NibbleToHex(String AValue);
String	NibblesToHex(String AValue);
void	GetBitmapGlyph(TStringList *AStringList, TImage *AImage, int ALeft, int ATop, int AWidth, int AHeight, bool isHex);
int		GetBByoff(TStringList *AStringList);
int		GetBByoff2(TStringList *AStringList);
int		GetBBxoff(TStringList *AStringList);
int		GetBBxoff2(TStringList *AStringList);
void	GetBitmapGlyphBBX(TStringList *AStringList, int BBxoff, int BByoff, int BBxoff2, int BByoff2);
void	GetBitmapGlyphBBX_Hex(TStringList *AStringList);

String	GetCharBBXInfo(TStringList *AStringList, TImage *AImage, TTextMetric *ATextMetric, int x, int y, String AText, int AEncoding);
String	GetCharBBXInfo2(TStringList *AStringList, TImage *AImage, TTextMetric *ATextMetric, int x, int y, String AText, int AEncoding);
//---------------------------------------------------------------------------
#endif
