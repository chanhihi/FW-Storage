//-----------------------------------------------------------------------------
#ifndef __bdf2bmp_h
#define __bdf2bmp_h
//-----------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif 
//-----------------------------------------------------------------------------
#ifndef __cplusplus
typedef enum {false, true} bool;
#endif

typedef unsigned char byte;
typedef unsigned short int word;
typedef unsigned long int dword;
//-----------------------------------------------------------------------------
extern char _bdf2bmp_msg[4096];
extern bool _is_bdf2bmp_error;
int bdf2bmp_main(int argc, char *argv[]);
//-----------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif 
//-----------------------------------------------------------------------------
#endif
