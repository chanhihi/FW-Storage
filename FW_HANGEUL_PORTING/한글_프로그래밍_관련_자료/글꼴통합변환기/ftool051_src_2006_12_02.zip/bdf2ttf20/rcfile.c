/* vim:set ts=8 sts=4 sw=4 tw=0: */
/*
 * Last Change: 05-Aug-2003.
 * Written By:  MURAOKA Taro <koron@tka.att.ne.jp>
 */

//------------------------------------------------------------------------------
#ifdef __BORLANDC__
#pragma warn -8004
#endif
//------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "rcfile.h"
//------------------------------------------------------------------------------
typedef struct _rcentry_t rcentry_t;

struct _rcentry_t {
    char *key;
    char *value;
    rcentry_t *next;
};

struct _rcfile_t {
    int entry_num;
    rcentry_t *entry_ptr;
};
//------------------------------------------------------------------------------
int is_whitespace(int c)
{
#if 1
    return isspace(c);
#else
    switch (c) {
	default: return 0;
	case 0x09:
	case 0x0a:
	case 0x0b:
	case 0x0c:
	case 0x0d:
	case 0x20:
	    return 1;
    }
#endif
}
//------------------------------------------------------------------------------
rcentry_t **get_entry(rcfile_t *rcfile, char *key)
{
    rcentry_t **p = &rcfile->entry_ptr;

    while (*p) {
		if (strcmp((**p).key, key) == 0) break;
		p = &(**p).next;
    }
    return p;
}
//------------------------------------------------------------------------------
/*
 * Parse rcfile by eachline
 */
//------------------------------------------------------------------------------
void rcfile_load_fp(rcfile_t *rcfile, FILE *fp)
{
    char buf[RC_MAXLINE_LEN];

    if (!rcfile) return;
    while (fgets(buf, sizeof(buf), fp)) {
		unsigned char *p = (unsigned char *)buf;
		unsigned char *key, *value, *tail;
		rcentry_t **entry;

		while (is_whitespace(*p)) ++p;	/* Skip leading white space */
		if (*p == '#' || *p == '\r' || *p == '\n') continue;

		/* Obtain key */
		key = p;
		p = (unsigned char *)strchr((char *)p, '='); /* Find key,value separator */
		if (!p || key == p) continue;

		tail = p++;
		do *tail = '\0';
		while (is_whitespace(*--tail));

		/* Obtain value */
		while (is_whitespace(*p)) ++p;	/* Skip leading white space */
		value = p;
		for (; *p; ++p)
			if (strchr("\r\n", *p)) break;
		tail = p;
		do *tail = '\0';
		while (is_whitespace(*--tail));

		entry = get_entry(rcfile, (char *)key);
		if (!*entry) {
			*entry = (rcentry_t *)malloc(sizeof(rcentry_t));
			if (*entry == NULL) break;
			(**entry).key	= strdup((char *)key);
			(**entry).value	= NULL;
			(**entry).next	= NULL;
		}
		free((**entry).value);
		(**entry).value = strdup((char *)value);
    }
}
//------------------------------------------------------------------------------
rcfile_t *rcfile_open(const char *filename)
{
    FILE *fp;
    rcfile_t *rcfile = NULL;

	fp = fopen(filename, "rt");
    if (fp == NULL) return NULL;
	rcfile = (rcfile_t*)malloc(sizeof(rcentry_t));
    if (!rcfile) return NULL;
    rcfile->entry_num = 0;
    rcfile->entry_ptr = 0;

    rcfile_load_fp(rcfile, fp);

    return rcfile;
}
//------------------------------------------------------------------------------
void rcentry_close(rcentry_t *rcentry)
{
    rcentry_t *p, *next;
    for (p = rcentry; p; p = next) {
		next = p->next;
		free(p->key);
		free(p->value);
		free(p);
    }
}
//------------------------------------------------------------------------------
void rcfile_close(rcfile_t *rcfile)
{
    if (!rcfile) return;
    rcentry_close(rcfile->entry_ptr);
}
//------------------------------------------------------------------------------
char *rcfile_get(rcfile_t *rcfile, char *key)
{
    rcentry_t **p = get_entry(rcfile, key);
    return *p ? (**p).value : NULL;
}
//------------------------------------------------------------------------------
/*
int main(int argc, char **argv)
{
    if (argc > 1) {
		rcfile_t *rcfile = NULL;

		rcfile = rcfile_open(argv[1]);
		if (rcfile) {
		    int i;

			for (i = 2; i < argc; ++i) {
				printf("[%d] key=%s value=%s\n", i - 1, argv[i],
					rcfile_get(rcfile, argv[i]));
		    }
		    rcfile_close(rcfile);
		}
    }

	return 0;
}
//------------------------------------------------------------------------------
*/
