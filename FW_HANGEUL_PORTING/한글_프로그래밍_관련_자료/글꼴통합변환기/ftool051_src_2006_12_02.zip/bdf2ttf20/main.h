//-----------------------------------------------------------------------------
#ifndef MAIN_H
#define MAIN_H
//-----------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif 
//------------------------------------------------------------------------------
#ifndef __cplusplus
typedef enum {false, true} bool;
#endif

typedef unsigned char byte;
typedef unsigned short int word;
typedef unsigned long int dword;
//-----------------------------------------------------------------------------
extern char _bdf2ttf_msg[4096];
extern bool _is_bdf2ttf_error;

void print_msg(char *format, ...);
int  bdf2ttf_main(int argc, char *argv[]);
//------------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif 
//-----------------------------------------------------------------------------
#endif
