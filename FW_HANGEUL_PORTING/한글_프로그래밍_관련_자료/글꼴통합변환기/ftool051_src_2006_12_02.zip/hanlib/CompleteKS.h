//-----------------------------------------------------------------------------
#ifndef CompleteKSH
#define CompleteKSH
//-----------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif 
//-----------------------------------------------------------------------------
void HanComplete(bool mode, byte *dest, byte *src, int nums);
void CompleteKS2350(THanFont *AHanFont);
void CompleteExtKS11172(THanFont *AHanFont);
//-----------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif 
//-----------------------------------------------------------------------------
#endif
