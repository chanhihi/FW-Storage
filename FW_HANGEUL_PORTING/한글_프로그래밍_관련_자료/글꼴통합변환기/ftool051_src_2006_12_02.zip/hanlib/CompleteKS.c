//------------------------------------------------------------------------------
#ifdef __BORLANDC__
#pragma warn -8004
#endif

#include "hanlib.h"

#include "Johab.h"
#include "Table10x4x4.h"
#include "Table8x4x4.h"
#include "Table6x2x1.h"
#include "Table2x1x2.h"
#include "CP949Table.h"
#include "KS2JohabTable.h"

#include "CompleteKS.h"
//-----------------------------------------------------------------------------
void HanComplete(bool mode, byte *dest, byte *src, int nums)
{
	int i;
	if (mode == true) memcpy(dest, src, nums);
	else for (i = 0; i < nums; i++) dest[i] |= src[i];
}
//------------------------------------------------------------------------------
void CompleteKS2350(THanFont *AHanFont)
{
	int i;
	byte *pF1B, *pF2B, *pF3B;

    switch (AHanFont->HanFontType) {
    case HANFONT_10X4X4:
        pF1B = _F1B_10x4x4;
    	pF2B = _F2B_10x4x4;
    	pF3B = _F3B_10x4x4;
        break;
    case HANFONT_8X4X4:
        pF1B = _F1B_8x4x4;
    	pF2B = _F2B_8x4x4;
    	pF3B = _F3B_8x4x4;
        break;
    case HANFONT_6X2X1:
        pF1B = _F1B_6x2x1;
    	pF2B = _F2B_6x2x1;
    	pF3B = _F3B_6x2x1;
        break;
    case HANFONT_2X1X2:
        pF1B = _F1B_2x1x2;
    	pF2B = _F2B_2x1x2;
    	pF3B = _F3B_2x1x2;
        break;
    }

	for (i = 0; i < 2350; i++) {
    	THangul _Hangul;
		bool flag = true;
	    byte bitmap32[32];
		int F1, F2, F3, F3B, F2B, F1B;

		_Hangul.HanByte.Byte0 = (byte)(_KS2JohabTable[i] >> 8);
	    _Hangul.HanByte.Byte1 = (byte)(_KS2JohabTable[i]);

	    F1 = _CodeTable[0][_Hangul.HanCode.F1];
	    F2 = _CodeTable[1][_Hangul.HanCode.F2];
	    F3 = _CodeTable[2][_Hangul.HanCode.F3];

	    F3B = pF3B[F2];
	    F2B = pF2B[F1 * 2 + (F3 != 0)];
	    F1B = pF1B[F2 * 2 + (F3 != 0)];

	    if (F1) HanComplete(true, bitmap32, AHanFont->F1[F1B][F1], 32), flag = false;
	    if (F2) HanComplete(flag, bitmap32, AHanFont->F2[F2B][F2], 32), flag = false;
	    if (F3)	HanComplete(flag, bitmap32, AHanFont->F3[F3B][F3], 32), flag = false;

		memcpy(AHanFont->Hangul[i], bitmap32, 32);
	}
}
//------------------------------------------------------------------------------
void CompleteExtKS11172(THanFont *AHanFont)
{
	int i;
	byte *pF1B, *pF2B, *pF3B;

    switch (AHanFont->HanFontType) {
    case HANFONT_10X4X4:
        pF1B = _F1B_10x4x4;
    	pF2B = _F2B_10x4x4;
    	pF3B = _F3B_10x4x4;
        break;
    case HANFONT_8X4X4:
        pF1B = _F1B_8x4x4;
    	pF2B = _F2B_8x4x4;
    	pF3B = _F3B_8x4x4;
        break;
    case HANFONT_6X2X1:
        pF1B = _F1B_6x2x1;
    	pF2B = _F2B_6x2x1;
    	pF3B = _F3B_6x2x1;
        break;
    case HANFONT_2X1X2:
        pF1B = _F1B_2x1x2;
    	pF2B = _F2B_2x1x2;
    	pF3B = _F3B_2x1x2;
        break;
    }

	for (i = 256; i < 17304; i++) {
		if (CP949CodeTable[i].CodeType == CODETABLE_HANGUL) {
			THangul _Hangul;
			bool flag = true;
		    byte bitmap32[32];
			int F1, F2, F3, F3B, F2B, F1B;

			_Hangul.HanByte.Byte0 = (byte)(CP949CodeTable[i].KSSM >> 8);
			_Hangul.HanByte.Byte1 = (byte)(CP949CodeTable[i].KSSM);

			F1 = _CodeTable[0][_Hangul.HanCode.F1];
			F2 = _CodeTable[1][_Hangul.HanCode.F2];
			F3 = _CodeTable[2][_Hangul.HanCode.F3];

			F3B = pF3B[F2];
			F2B = pF2B[F1 * 2 + (F3 != 0)];
			F1B = pF1B[F2 * 2 + (F3 != 0)];

			if (F1) HanComplete(true, bitmap32, AHanFont->F1[F1B][F1], 32), flag = false;
			if (F2) HanComplete(flag, bitmap32, AHanFont->F2[F2B][F2], 32), flag = false;
			if (F3)	HanComplete(flag, bitmap32, AHanFont->F3[F3B][F3], 32), flag = false;

			memcpy(AHanFont->Unicode[i], bitmap32, 32);
		}
	}
    for (i = 0; i < 51; i++) 
		memcpy(AHanFont->Unicode[912 + i], AHanFont->pHangulJamo[i], 32);
}
//------------------------------------------------------------------------------
