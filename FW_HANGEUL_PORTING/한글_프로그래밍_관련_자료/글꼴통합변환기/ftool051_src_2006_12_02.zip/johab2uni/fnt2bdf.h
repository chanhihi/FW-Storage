//---------------------------------------------------------------------------
#ifndef __fnt2bdf_h
#define __fnt2bdf_h
//---------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif 
//-----------------------------------------------------------------------------
#include <stdio.h>
//-----------------------------------------------------------------------------
bool ConvertEngFontToBDF(char *ASaveFileName, char *AWriteMode, TEngFont *AEngFont, char *AFoundryName, char *AFamilyName);
bool ConvertHanFontToBDF(char *ASaveFileName, char *AWriteMode, char *AEncoding, TEngFont *AEngFont, THanFont *AHanFont, TSpcFont *ASpcFont, THanjaFont *AHanjaFont, char *AFoundryName, char *AFamilyName);
void ConvertHanFontToBDF_ksc5601(FILE *fp, THanFont *AHanFont, TSpcFont *ASpcFont, THanjaFont *AHanjaFont, int MSB);
void ConvertHanFontToBDF_iso10646_1(FILE *fp, TEngFont *AEngFont, THanFont *AHanFont, TSpcFont *ASpcFont, THanjaFont *AHanjaFont);
void ConvertHanFontToBDF_johab844_1(FILE *fp, THanFont *AHanFont);
//---------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif 
//-----------------------------------------------------------------------------
#endif
