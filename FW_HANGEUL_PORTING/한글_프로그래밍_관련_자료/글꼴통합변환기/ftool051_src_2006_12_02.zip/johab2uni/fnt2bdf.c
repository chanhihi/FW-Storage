//---------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include "..\hanlib\hanlib.h"
#include "etc.h"
#include "fnt2bdf.h"
//---------------------------------------------------------------------------
typedef struct {
    char	Font[100];
    int		Size_PointSize, Size_Xres, Size_Yres;
    int		FontBoundingBox_FBBx, FontBoundingBox_FBBy,
			FontBoundingBox_Xoff, FontBoundingBox_Yoff;
    char	Foundry[32];
    char	Family_Name[32];
    char	Weight_Name[32];
    char	Slant[2];
    char	SetWidth_Name[32];
    char	Add_Style_Name[32];
    int		Pixel_Size;
    int		Point_Size;
    int		Resolution_X;
    int		Resolution_Y;
    char	Spacing[2];
    int		Average_Width;
    char	CharSet_Registry[32];
    char	CharSet_Encoding[2];
    int		Default_Char;
    int		Font_Ascent;
    int		Font_Descent;
    char    Copyright[256];
    int		Chars;
} TBDFHeader;
//---------------------------------------------------------------------------
static char *GetBDFHeader(TBDFHeader *B);
static char *GetXLFD(TBDFHeader *B);
static void WriteCharBitmap(int AEncoding, byte *ABitmap, int ABitmapSize, FILE *fp);
//---------------------------------------------------------------------------
char *GetBDFHeader(TBDFHeader *B)
{
	static char Header1[8192];

	strcpy(B->Font, GetXLFD(B));

	sprintf(Header1,
		"STARTFONT 2.1"					"\n"
		"FONT %s" 						"\n"
		"SIZE %d %d %d"					"\n"
		"FONTBOUNDINGBOX %d %d %d %d"	"\n"
		"STARTPROPERTIES 18"			"\n"
		"FOUNDRY \"%s\""				"\n"
		"FAMILY_NAME \"%s\""			"\n"
		"WEIGHT_NAME \"%s\""			"\n"
		"SLANT \"%s\""					"\n"
		"SETWIDTH_NAME \"%s\""			"\n"
		"ADD_STYLE_NAME \"%s\""			"\n"
		"PIXEL_SIZE %d"					"\n"
		"POINT_SIZE %d"					"\n"
		"RESOLUTION_X %d"				"\n"
		"RESOLUTION_Y %d"				"\n"
		"SPACING \"%s\""				"\n"
		"AVERAGE_WIDTH %d"				"\n"
		"CHARSET_REGISTRY \"%s\""	 	"\n"
		"CHARSET_ENCODING \"%s\""	 	"\n"
		"DEFAULT_CHAR %d"				"\n"
		"FONT_ASCENT %d"				"\n"
		"FONT_DESCENT %d"				"\n"
		"COPYRIGHT \"%s\"" 			    "\n"
		"ENDPROPERTIES"					"\n"
		"CHARS %d"						"\n",

        //
		B->Font,
		B->Size_PointSize, B->Size_Xres, B->Size_Yres,
		B->FontBoundingBox_FBBx, B->FontBoundingBox_FBBy,
        B->FontBoundingBox_Xoff, B->FontBoundingBox_Yoff,
        //
		B->Foundry,
		B->Family_Name,
		B->Weight_Name,
		B->Slant,
		B->SetWidth_Name,
		B->Add_Style_Name,
		B->Pixel_Size,
		B->Point_Size,
		B->Resolution_X,
		B->Resolution_Y,
		B->Spacing,
		B->Average_Width,
		B->CharSet_Registry,
		B->CharSet_Encoding,
		B->Default_Char,
		B->Font_Ascent,
		B->Font_Descent,
        B->Copyright,
        //
		B->Chars
	);

	return Header1;
}
//---------------------------------------------------------------------------
char *GetXLFD(TBDFHeader *B)
{
	static char XLFD[1024];

	sprintf(XLFD, "-%s-%s-%s-%s-%s--%d-%d-%d-%d-%s-%d-%s-%s",
		B->Foundry,
        B->Family_Name,
        B->Weight_Name,
        B->Slant,
        B->SetWidth_Name,

		B->Pixel_Size,
        B->Point_Size,
        B->Resolution_X,
        B->Resolution_Y,
        B->Spacing,
        B->Average_Width,
        B->CharSet_Registry,
        B->CharSet_Encoding);

    return XLFD;
}
//---------------------------------------------------------------------------
void WriteCharBitmap(int AEncoding, byte *ABitmap, int ABitmapSize, FILE *fp)
{
	int i, DWidth = ABitmapSize / 2;
    int SWidth = DWidth * 96000 / (12 * 96);

    if (ABitmapSize == 16)
        fprintf(fp, "STARTCHAR char0x%02X\n", AEncoding);
    else
        fprintf(fp, "STARTCHAR char0x%04X\n", AEncoding);
	fprintf(fp, "ENCODING %d\n", AEncoding);
	fprintf(fp, "SWIDTH %d 0\n", SWidth);
	fprintf(fp, "DWIDTH %d 0\n", DWidth);
	fprintf(fp, "BBX %d 16 0 0\n", DWidth);
	fprintf(fp, "BITMAP\n");
    if (ABitmapSize == 16)
        for (i = 0; i < 16; i++)
            fprintf(fp, "%02X\n", ABitmap[i]);
    else
        for (i = 0; i < 32; i += 2)
            fprintf(fp, "%02X%02X\n", ABitmap[i], ABitmap[i + 1]);
	fprintf(fp, "ENDCHAR\n");
}
//---------------------------------------------------------------------------
bool ConvertEngFontToBDF(char *ASaveFileName, char *AWriteMode, TEngFont *AEngFont, char *AFoundryName, char *AFamilyName)
{
	int Encoding;
	FILE *fp;
	TBDFHeader B = {
    //  +                            +   +
        "", 16, 96, 96, 8, 16, 0, 0, "", "", "medium", "r", "normal", "",
        16, 120, 96, 96, "m", 80, "iso8859", "1", 127, 16, 0, "", -1
	};//                                                      +   +
	strcpy(B.Foundry, AFoundryName);		//+
	strcpy(B.Family_Name, AFamilyName);		//+
    strcpy(B.Copyright, ExtractFileName(AEngFont->FullFileName));   //+
    B.Chars = AEngFont->CharCount;			//+

    if ((fp = fopen(ASaveFileName, AWriteMode)) == NULL) return false;
	fprintf(fp, "%s", GetBDFHeader(&B));
    for (Encoding = 0; Encoding < AEngFont->CharCount; Encoding++)
        WriteCharBitmap(Encoding, AEngFont->Eng[Encoding], 16, fp);
    fprintf(fp, "ENDFONT\n");
    fclose(fp);

    return true;
}
//------------------------------------------------------------------------------
bool ConvertHanFontToBDF(char *ASaveFileName, char *AWriteMode, char *AEncoding,
    TEngFont *AEngFont, THanFont *AHanFont, TSpcFont *ASpcFont, THanjaFont *AHanjaFont,
    char *AFoundryName, char *AFamilyName)
{
	FILE *fp;
	int MSB = 0;

	TBDFHeader B= {
    //  +                             +   +
		"",	16, 96, 96, 16, 16, 0, 0, "", "", "medium", "r", "normal", "",
        16, 120, 96, 96, "m", 160, "", "", -1, 16, 0, "", -1
    };//                           +   +   +          "   +
	strcpy(B.Foundry, AFoundryName);									//+
	strcpy(B.Family_Name, AFamilyName);							    	//+
    memset(B.Copyright, 0, sizeof(B.Copyright));
    if (AEngFont) {strcat(B.Copyright, ExtractFileName(AEngFont->FullFileName)); strcat(B.Copyright, ", ");}
    if (AHanFont) {strcat(B.Copyright, ExtractFileName(AHanFont->FullFileName)); strcat(B.Copyright, ", ");}
    if (ASpcFont) {strcat(B.Copyright, ExtractFileName(ASpcFont->FullFileName)); strcat(B.Copyright, ", ");}
    if (AHanjaFont) {strcat(B.Copyright, ExtractFileName(AHanjaFont->FullFileName)); strcat(B.Copyright, ", ");}
    B.Copyright[strlen(B.Copyright) - 2] = '\0';

	if (strcmp(AEncoding, "ksc5601.1987-0") == 0) MSB = 0x8080;
    strncpy(B.CharSet_Registry, AEncoding, strlen(AEncoding) - 2);		//+
    strncpy(B.CharSet_Encoding, AEncoding + strlen(AEncoding) - 1, 1);	//+
    if (strcmp(B.CharSet_Registry, "iso10646") == 0) {
        int CharsCount = 0;
        if (AEngFont) CharsCount += 128;
        if (AHanFont) CharsCount += (11172 + 51);
        if (ASpcFont) CharsCount += 988;     // 988 = Ư������937 + �ѱ��ڸ�51
        if (AHanFont && ASpcFont) CharsCount -= 51;
        if (AHanjaFont) CharsCount += 4888;
        B.Default_Char = 12288;										//+
        B.Chars = CharsCount;					                    //+
    } else if (strcmp(B.CharSet_Registry, "ksc5601.1987") == 0) {
        int CharsCount = 0;
        if (AHanFont) CharsCount += (2350 + 51);
        if (ASpcFont) CharsCount += 1128;    // 1128 = Ư������1077 + �ѱ��ڸ�51
        if (AHanFont && ASpcFont) CharsCount -= 51;
        if (AHanjaFont) CharsCount += 4888;
	    B.Default_Char = 0xA1A1 - MSB;								//+
		B.Chars = CharsCount;										//+
    } else if (strcmp(B.CharSet_Registry, "johab844") == 0) {
        B.Default_Char = 0;										    //+
        B.Chars = 11520 / 32;                             //+
    }

    if ((fp = fopen(ASaveFileName, AWriteMode)) == NULL) return false;
	fprintf(fp, "%s", GetBDFHeader(&B));

    if (strcmp(B.CharSet_Registry, "iso10646") == 0)
        ConvertHanFontToBDF_iso10646_1(fp, AEngFont, AHanFont, ASpcFont, AHanjaFont);
    else if (strcmp(B.CharSet_Registry, "ksc5601.1987") == 0)
        ConvertHanFontToBDF_ksc5601(fp, AHanFont, ASpcFont, AHanjaFont, MSB);
    else if (strcmp(B.CharSet_Registry, "johab844") == 0)
        ConvertHanFontToBDF_johab844_1(fp, AHanFont);

    fprintf(fp, "ENDFONT\n");
    fclose(fp);

    return true;
}
//------------------------------------------------------------------------------
void ConvertHanFontToBDF_ksc5601(FILE *fp, THanFont *AHanFont, TSpcFont *ASpcFont, THanjaFont *AHanjaFont, int MSB)
{
    int i, High, Low;
    if (ASpcFont) { // 1. Ư������(0XA1~0XAC : 12������, 0XA1~0XFE : 94������)
        // Ư������ ���� 3��*+����(�׹�° ������)�� 0 ~ 50���� 51���� �ѱ� �ڸ� ��ġ�Ѵ�
        if (AHanFont)
            for (i = 0; i < 51; i++)
                memcpy(ASpcFont->Spc[3][i], AHanFont->pHangulJamo[i], 32);
        for (High = 0xA1; High <= 0xAC; High++)
            for (Low = 0xA1; Low <= 0xFE; Low++)
                WriteCharBitmap(((High << 8) + Low) - MSB, ASpcFont->Spc[High - 0xA1][Low - 0xA1], 32, fp);
    }

    if (AHanFont) { // 2. �ѱ� (0XB0~0XC8 : 25������, 0XA1~0XFE : 94������)
        CompleteKS2350(AHanFont);
        if (!ASpcFont)
            for (i = 0; i < 51; i++)
                WriteCharBitmap((0xA4A1 - MSB) + i, AHanFont->pHangulJamo[i], 32, fp);
        i = 0;                 
        for (High = 0xB0; High <= 0xC8; High++)
            for (Low = 0xA1; Low <= 0xFE; Low++)
                WriteCharBitmap(((High << 8) + Low) - MSB, AHanFont->Hangul[i++], 32, fp);
    }
    if (AHanjaFont) // 3. ���� (0XCA~0XFD : 52������, 0XA1~0XFE : 94������)
        for (High = 0xCA; High <= 0xFD; High++)
            for (Low = 0xA1; Low <= 0xFE; Low++)
                WriteCharBitmap(((High << 8) + Low) - MSB, AHanjaFont->Hanja[High - 0xCA][Low - 0xA1], 32, fp);
}
//------------------------------------------------------------------------------
void ConvertHanFontToBDF_iso10646_1(FILE *fp, TEngFont *AEngFont, THanFont *AHanFont, TSpcFont *ASpcFont, THanjaFont *AHanjaFont)
{
    int i;
    if (AEngFont)
        for (i = 0; i < 128; i++)
            WriteCharBitmap(i, AEngFont->Eng[i], 16, fp);
    if (AHanFont) CompleteExtKS11172(AHanFont);
    for (i = 256; i < 17304; i++) {
        int Page, Offset;
        switch (CP949CodeTable[i].CodeType) {
        case CODETABLE_SPC:
            if (!ASpcFont) continue;
            Page = (CP949CodeTable[i].cp949 >> 8) - 0xA1;
            Offset = (CP949CodeTable[i].cp949 & 0xFF) - 0xA1;
            WriteCharBitmap(CP949CodeTable[i].Unicode, ASpcFont->Spc[Page][Offset], 32, fp);
            break;
        case CODETABLE_CJK:
            if (!AHanjaFont) continue;
            Page = (CP949CodeTable[i].cp949 >> 8) - 0xCA;
            Offset = (CP949CodeTable[i].cp949 & 0xFF) - 0xA1;
            WriteCharBitmap(CP949CodeTable[i].Unicode, AHanjaFont->Hanja[Page][Offset], 32, fp);
            break;
        case CODETABLE_HANGUL:
            if (!AHanFont) continue;
            WriteCharBitmap(CP949CodeTable[i].Unicode, AHanFont->Unicode[i], 32, fp);
            break;
        case CODETABLE_HANGUL_SYLLABLE:
            if (AHanFont)
                WriteCharBitmap(CP949CodeTable[i].Unicode, AHanFont->Unicode[i], 32, fp);
            else if (!AHanFont && ASpcFont) {
                Page = (CP949CodeTable[i].cp949 >> 8) - 0xA1;
                Offset = (CP949CodeTable[i].cp949 & 0xFF) - 0xA1;
                WriteCharBitmap(CP949CodeTable[i].Unicode, ASpcFont->Spc[Page][Offset], 32, fp);
            }
            break;
        }
    }
}
//------------------------------------------------------------------------------
void ConvertHanFontToBDF_johab844_1(FILE *fp, THanFont *AHanFont)
{
    int i, j, Encoding = 0;

    for (i = 0; i < 8; i++)
        for (j = 0; j < 19+1; j++)
            WriteCharBitmap(Encoding++, AHanFont->F1[i][j], 32, fp);
    for (i = 0; i < 4; i++)
        for (j = 0; j < 21+1; j++)
            WriteCharBitmap(Encoding++, AHanFont->F2[i][j], 32, fp);
    for (i = 0; i < 4; i++)
        for (j = 0; j < 27+1; j++)
            WriteCharBitmap(Encoding++, AHanFont->F3[i][j], 32, fp);
}
//------------------------------------------------------------------------------
