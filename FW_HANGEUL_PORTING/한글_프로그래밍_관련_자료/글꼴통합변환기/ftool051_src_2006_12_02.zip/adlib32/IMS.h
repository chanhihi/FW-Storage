//------------------------------------------------------------------------------
#ifndef __IMS_H
#define __IMS_H
//------------------------------------------------------------------------------
#include "bnk.h"
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//------------------------------------------------------------------------------
#pragma pack(push, 1)
typedef struct {
	BYTE	nVerMajor;		// 1 byte
	BYTE	nVerMinor;		// 1 byte
	LONG	nTuneID;		// 4 byte
	char	szTuneName[30];	// 30 byte
	BYTE	nTickBeat;		// 1 byte
	BYTE	nBeatMeasure;	// 1 byte
	LONG	nTotalTick;		// 4 byte
	LONG	cbDataSize;		// 4 byte
	LONG	nrCommand;		// 4 byte
	BYTE	nSrcTickBeat;	// 1 byte
	char	filler[7];		// 7 byte
	BYTE	nSoundMode;		// 1 byte
	BYTE	nPitchBRange;	// 1 byte
	WORD	nBasicTempo;	// 2 byte
	char	filler2[8];		// 8 byte
} TIMSHeader;	// 70 byte

#pragma pack(pop)

//------------------------------------------------------------------------------
/*
typedef struct {
	BYTE ammulti;
	BYTE ksltl;
	BYTE ardr;
	BYTE slrr;
	BYTE fbc;
	BYTE waveform;
} TOpOperator;	// 6 byte

typedef struct {
	//char mode;
	//char voice_number;
	TOpOperator		modulator;	// 6 byte
	TOpOperator		carrier;	// 6 byte
	BYTE			ins[30];	// 30 byte
} TIMSInstData;	// 42 byte

typedef struct {
	int ammulti;
	int ksltl;
	int ardr;
	int slrr;
	int fbc;
	int waveform;
} TOpOperator32;

typedef struct {
	TOpOperator		modulator;
	TOpOperator		carrier;
	int				ins[30];
} TIMSInstData32;
*/
//------------------------------------------------------------------------------
typedef struct {
	char	InstrName[8 + 1];
    int		InstrIndex;		//BNK ���Ͽ����� �ε��� ��ȣ
} TInstrIndex;
//------------------------------------------------------------------------------
typedef struct {
	char			FileName[1024];	// ��θ� ������ ���ϸ�
	int				FileSize;		// Raw ���۷� �о���� ���� ũ��
	BYTE		   *Raw;			// IMS ���� ���� ��ü�� ��°�� �о�� ����
	BYTE		   *RawPtr;
//	----------------------------------------------------------------------------
	TIMSHeader		Header;
	BYTE		   *SongData;
//	----------------------------------------------------------------------------
	int				UsedInstrCount;
	TInstrIndex	   *UsedInstrIndex;
//	----------------------------------------------------------------------------
	TBNKFile	   *BNKFile;
} TIMSFile;
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// ������ ������ ũ�Ⱑ IMSFILE_MAXSIZE (1MB)�� �ʰ��� ���
// �������� IMS ������ �ƴ� ���ɼ��� ���ٰ� ������.
//------------------------------------------------------------------------------

#define IMSFILE_MAXSIZE	(1024 * 1024)	// == 1MB


//------------------------------------------------------------------------------
//	�ֿ� �Լ� ����
//------------------------------------------------------------------------------
TIMSFile *LoadIMSFile(char *IMSFileName);
void FreeIMSFile(TIMSFile *I);
//------------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif	//__IMS_H

