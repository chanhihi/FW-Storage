//------------------------------------------------------------------------------
#ifndef __BNK_H
#define __BNK_H
//------------------------------------------------------------------------------
#include "datatype.h"
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//------------------------------------------------------------------------------
#pragma pack(push, 1)
typedef struct {
	BYTE	nVerMajor;		// 1 byte
	BYTE	nVerMinor;		// 1 byte
	char	signature[6];	// 6 byte
	WORD	nUsedEntry;		// 2 byte
	WORD	nTotalEntry;	// 2 byte
	DWORD	nRecSeekPos;	// 4 byte
	DWORD	nDataSeekPos;	// 4 byte
} TBNKHeader;	// 20 byte

typedef struct {
	// index into data section
	WORD	index;		// 2 byte
	BYTE	bUsed;		// 1 byte
	char	szName[8 + 1];	// NULL terminated instrument name
} TBNKNameRecord;	// 2 + 1 + 9 = 12 byte

typedef struct {
	char KeyScaleLevel;
	char FreqMultiplier;
	char Feedback;
	char AttackRate;
	char SustainLevel;
	char SustainSound;
	char DecayRate;
	char ReleaseRate;
	char OutputLevel;
	char AmplitudeVibrato;
	char FreqVibrato;
	char EnvelopeScale;
	char FmType;			// 0:FM, 1:Additive
} TOpParam;	// 13 byte

typedef struct {
	char		InstType;		// 1 byte
	char		VoiceNum;		// 1 byte
	TOpParam	Op1;			// 13 byte
	TOpParam	Op2;			// 13 byte
	char		Op1WaveForm;	// 1 byte
	char		Op2WaveForm;	// 1 byte
} TBNKInstRecord;	// 30 byte
#pragma pack(pop)


//------------------------------------------------------------------------------
typedef struct {
	int KeyScaleLevel;
	int FreqMultiplier;
	int Feedback;
	int AttackRate;
	int SustainLevel;
	int SustainSound;
	int DecayRate;
	int ReleaseRate;
	int OutputLevel;
	int AmplitudeVibrato;
	int FreqVibrato;
	int EnvelopeScale;
	int FmType;
} TOpParam32;	// 4 byte X 13��

typedef struct {
	int			InstType;
	int			VoiceNum;
	TOpParam32	Op1;
	TOpParam32	Op2;
	int			Op1WaveForm;
	int			Op2WaveForm;
} TBNKInstRecord32;		// 4 byte X 30��

//------------------------------------------------------------------------------
typedef struct {
	char				FileName[1024];	// ��θ� ������ ���ϸ�
	int					FileSize;		// Raw ���۷� �о���� ���� ũ��
	BYTE   			   *Raw;			// BNK ���� ���� ��ü�� ��°�� �о�� ����
    BYTE			   *RawPtr;

	TBNKHeader		    Header;
	TBNKNameRecord	   *NameRecord;
	TBNKInstRecord	   *InstRecord;
	TBNKInstRecord32   *InstRecord32;

	int					NameRecordSize;
	int					InstRecordSize;
	int					InstRecordSize32;
} TBNKFile;


//------------------------------------------------------------------------------
//	�ֿ� �Լ� ����
//------------------------------------------------------------------------------
TBNKFile   *LoadBNKFile(char *BNKFileName);
void		FreeBNKFile(TBNKFile *B);
//------------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif	//__BNK_H
