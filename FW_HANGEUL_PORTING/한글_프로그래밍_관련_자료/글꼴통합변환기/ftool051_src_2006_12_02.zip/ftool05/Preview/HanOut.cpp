//---------------------------------------------------------------------------
#include <vcl.h>
#include <Graphics.hpp>
#pragma hdrstop

#include "..\..\hanlib\hanlib.h"
#include "HanOut.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
void FloodFill(TCanvas *ACanvas, int ALeft, int ATop, int AWidth, int AHeight, TColor AColor)
{
	TRect FullRect;

    FullRect.Left = ALeft;
    FullRect.Top = ATop;
    FullRect.Right = ALeft + AWidth;
    FullRect.Bottom = ATop + AHeight;
    ACanvas->Brush->Color = AColor;
    ACanvas->FillRect(FullRect);
}
//---------------------------------------------------------------------------
void ClearCanvasGridCell(TCanvas *ACanvas, int ACol, int ARow, int AColWidth, int ARowHeight, TColor AColor)
{
	FloodFill(ACanvas, ACol * (AColWidth + 1) + 1, ARow * (ARowHeight + 1) + 1, AColWidth, ARowHeight, AColor);
}
//---------------------------------------------------------------------------
void ClearCanvasGrid(TCanvas *ACanvas, TColor AColor)
{
    ACanvas->Brush->Color = AColor;
    ACanvas->Brush->Style = bsSolid;
    ACanvas->FillRect(ACanvas->ClipRect);
}
//-----------------------------------------------------------------------------
void PutBitmap8(TCanvas *ACanvas, int x, int y, TColor Color, TColor BKColor, byte ABitmap)
{
    for (int i = 0; i < 8; i++) {
		if (ABitmap & 0x80) ACanvas->Pixels[x + i][y] = Color;
        else ACanvas->Pixels[x + i][y] = BKColor;
        ABitmap = ABitmap << 1;
    }
}
//---------------------------------------------------------------------------
void PutBitmap8x16(TCanvas *ACanvas, int x, int y, TColor Color, TColor BKColor, byte *ABitmap16)
{
	for (int i = 0, index = 0; i < 16; i++, index++)
    	PutBitmap8(ACanvas, x, y + i, Color, BKColor, ABitmap16[index]);
}
//---------------------------------------------------------------------------
void PutBitmap8x16InCell(TCanvas *ACanvas, int ACol, int ARow, TColor AColor, TColor BKColor, byte *ABitmap16)
{
	PutBitmap8x16(ACanvas, ACol * (8 + 1) + 1, ARow * (16 + 1) + 1, AColor, BKColor, ABitmap16);
}
//---------------------------------------------------------------------------
void PutBitmap16x16(TCanvas *ACanvas, int x, int y, TColor Color, TColor BKColor, byte *ABitmap32)
{
	for (int i = 0, index = 0; i < 16; i++, index += 2) {
    	PutBitmap8(ACanvas, x, y + i, Color, BKColor, ABitmap32[index]);
    	PutBitmap8(ACanvas, x + 8, y + i, Color, BKColor, ABitmap32[index + 1]);
    }
}
//---------------------------------------------------------------------------
void PutBitmap16x16InCell(TCanvas *ACanvas, int ACol, int ARow, TColor Color, TColor BKColor, byte *bitmap32)
{
	PutBitmap16x16(ACanvas, ACol * (16 + 1) + 1, ARow * (16 + 1) + 1, Color, BKColor, bitmap32);
}
//---------------------------------------------------------------------------
void SetImageColsRows(TImage *AImage, int AColCount, int ARowCount, int AColWidth, int ARowWidth)
{
    AImage->Width = ((AColWidth + 1) * AColCount) + 1;
    AImage->Height = ((ARowWidth + 1) * ARowCount) + 1;
    AImage->Picture->Bitmap->Width = AImage->Width;
    AImage->Picture->Bitmap->Height = AImage->Height;

    AImage->Canvas->Pen->Color = clTeal;

    for (int Row = 0; Row < ARowCount + 1; Row++) {
        AImage->Canvas->MoveTo(0, (ARowWidth + 1) * Row);
        AImage->Canvas->LineTo(AImage->Width, (ARowWidth + 1) * Row);
    }

    for (int Col = 0; Col < AColCount + 1; Col++) {
        AImage->Canvas->MoveTo((AColWidth + 1) * Col, 0);
        AImage->Canvas->LineTo((AColWidth + 1) * Col, AImage->Height);
    }
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
void PutBitmap8Cell(TCanvas *ACanvas, int ACol, int ARow, TColor Color, TColor BKColor, byte ABitmap)
{
    for (int i = 0; i < 8; i++) {
		if (ABitmap & 0x80)
        	ClearCanvasGridCell(ACanvas, ACol + i, ARow, 16, 16, Color);
        else
        	ClearCanvasGridCell(ACanvas, ACol + i, ARow, 16, 16, BKColor);
        ABitmap = ABitmap << 1;
    }
}
//---------------------------------------------------------------------------
void PutBitmap8x16Cell(TCanvas *ACanvas, int ACol, int ARow, TColor Color, TColor BKColor, byte *ABitmap16)
{
	for (int Row = 0, index = 0 ; Row < 16; Row++, index++)
    	PutBitmap8Cell(ACanvas, ACol, ARow + Row, Color, BKColor, ABitmap16[index]);
}
//---------------------------------------------------------------------------
void PutBitmap16x16Cell(TCanvas *ACanvas, int ACol, int ARow, TColor Color, TColor BKColor, byte *ABitmap32)
{
	for (int Row = 0, index = 0; Row < 16; Row++, index += 2) {
    	PutBitmap8Cell(ACanvas, ACol, ARow + Row, Color, BKColor, ABitmap32[index]);
    	PutBitmap8Cell(ACanvas, ACol + 8, ARow + Row, Color, BKColor, ABitmap32[index + 1]);
    }
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void DrawEngFontTable(TCanvas *ACanvas, TEngFont *AEngFont)
{
    int EngIndex = 0;
    for (int Row = 0; Row < AEngFont->CharCount / 32; Row++) {
    	for (int Col = 0; Col < 32; Col++) {
    		PutBitmap8x16InCell(ACanvas, Col, Row, clBlack, clWhite, AEngFont->Eng[EngIndex++]);
        }
    }
}
//---------------------------------------------------------------------------
void DrawHanFontTable(TCanvas *ACanvasF1, TCanvas *ACanvasF2, TCanvas *ACanvasF3, THanFont *AHanFont)
{
    for (int Row = 0; Row < AHanFont->F1BulCount; Row++) {
    	for (int Col = 0; Col < AHanFont->F1Count; Col++)
    		PutBitmap16x16InCell(ACanvasF1, Col, Row, clBlack, clWhite, AHanFont->F1[Row][Col + !AHanFont->F_SKIP]);
    }
    for (int Row = 0; Row < AHanFont->F2BulCount; Row++) {
    	for (int Col = 0; Col < AHanFont->F2Count; Col++)
    		PutBitmap16x16InCell(ACanvasF2, Col, Row, clBlack, clWhite, AHanFont->F2[Row][Col + !AHanFont->F_SKIP]);
    }
    for (int Row = 0; Row < AHanFont->F3BulCount; Row++) {
    	for (int Col = 0; Col < AHanFont->F3Count; Col++)
    		PutBitmap16x16InCell(ACanvasF3, Col, Row, clBlack, clWhite, AHanFont->F3[Row][Col + !AHanFont->F_SKIP]);
    }
}
//---------------------------------------------------------------------------
void DrawSpcFontTable(TCanvas *ACanvas, TSpcFont *ASpcFont, int APage)
{
    int i = 0;

    for (int Row = 0; Row < 1; Row++)
        for (int Col = 1; Col < 16; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, clBlack, clWhite, ASpcFont->Spc[APage][i++]);
    for (int Row = 1; Row < 5; Row++)
        for (int Col = 0; Col < 16; Col++)
            PutBitmap16x16InCell(ACanvas, Col, Row, clBlack, clWhite, ASpcFont->Spc[APage][i++]);
    for (int Row = 5; Row < 6; Row++)
        for (int Col = 0; Col < 15; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, clBlack, clWhite, ASpcFont->Spc[APage][i++]);
}
//---------------------------------------------------------------------------
void DrawHanjaFontTable(TCanvas *ACanvas, THanjaFont *AHanjaFont, int APage)
{
    int i = 0;

    for (int Row = 0; Row < 1; Row++)
        for (int Col = 1; Col < 16; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, clBlack, clWhite, AHanjaFont->Hanja[APage][i++]);
    for (int Row = 1; Row < 5; Row++)
        for (int Col = 0; Col < 16; Col++)
            PutBitmap16x16InCell(ACanvas, Col, Row, clBlack, clWhite, AHanjaFont->Hanja[APage][i++]);
    for (int Row = 5; Row < 6; Row++)
        for (int Col = 0; Col < 15; Col++)
        PutBitmap16x16InCell(ACanvas, Col, Row, clBlack, clWhite, AHanjaFont->Hanja[APage][i++]);
}
//---------------------------------------------------------------------------
void DrawSamboSpcFontTable(TCanvas *ACanvas, TSpcFont *ASpcFont)
{
    int Index = 0;
    for (int Row = 0; Row < 8; Row++)
    	for (int Col = 0; Col < 16; Col++)
            PutBitmap16x16InCell(ACanvas, Col, Row, clBlack, clWhite, ASpcFont->SamboSpc[Index++]);
}
//---------------------------------------------------------------------------
