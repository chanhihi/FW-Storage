//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "..\hanlib\hanlib.h"
#include "Common.h"
#include "HanOut.h"

#include "PreviewFrameUnit.h"   // �̸�����
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "BrowseDr"
#pragma link "CSPIN"
#pragma link "TB2Dock"
#pragma resource "*.dfm"
TPreviewFrame *PreviewFrame;
//---------------------------------------------------------------------------
static TEngFont EngFont1;
static THanFont HanFont1;
static TSpcFont SpcFont1;
static THanjaFont HanjaFont1;
//---------------------------------------------------------------------------
__fastcall TPreviewFrame::TPreviewFrame(TComponent* Owner)
    : TFrame(Owner)
{
}
//---------------------------------------------------------------------------
void TPreviewFrame::InitPreviewFrame()
{
    pg_FontPreview->ActivePageIndex = 0;
    
    SetImageColsRows(img_EngChar16x, 8, 16, 16, 16);
    SetImageColsRows(img_HanChar16x, 16, 16, 16, 16);

    SetImageColsRows(img_EngFont, 32, 8, 8, 16);
    SetImageColsRows(img_HanFontF1, 19+4, 10, 16, 16);
    SetImageColsRows(img_HanFontF2, 21+2, 4, 16, 16);
    SetImageColsRows(img_HanFontF3, 27+4, 4, 16, 16);
    SetImageColsRows(img_SpcFont, 16, 6, 16, 16);
    SetImageColsRows(img_HanjaFont, 16, 6, 16, 16);
    SetImageColsRows(img_SamboSpcFont, 16, 8, 16, 16);

    img_HanFontF2->Top = img_HanFontF1->Top + img_HanFontF1->Height + 8;
    img_HanFontF3->Top = img_HanFontF2->Top + img_HanFontF2->Height + 8;
}
//---------------------------------------------------------------------------
void TPreviewFrame::PreviewBitmapFont(String AFileName, int AFileSize)
{
    if (IsEngFontSize(AFileSize)) {
        if ((AFileSize == 4096) && (IsSamboSpcFont(AFileName.c_str()))) {
            pg_FontPreview->ActivePageIndex = 5;
            if (!LoadSpcFont(&SpcFont1, AFileName.c_str()))
                {ShowErrorMessage("�б� ����!\n\n" + AFileName);return;}
            lb_SamboSpcFontInfo->Clear();
            lb_SamboSpcFontInfo->Items->Add("���� �̸�: " + ExtractFileName(AFileName));
            lb_SamboSpcFontInfo->Items->Add("���� ũ��: " + InsertComma(AFileSize) + " byte");
            lb_SamboSpcFontInfo->Items->Add("���� ����: " + IntToStr(SpcFont1.CharCount));
            DrawSamboSpcFontTable(img_SamboSpcFont->Canvas, &SpcFont1);
        } else {
            if (!LoadEngFont(&EngFont1, AFileName.c_str()))
                {ShowErrorMessage("�б� ����!\n\n" + AFileName); return;}
            pg_FontPreview->ActivePageIndex = 0;
            lb_EngFontInfo->Clear();
            lb_EngFontInfo->Items->Add("���� �̸�: " + ExtractFileName(AFileName));
            lb_EngFontInfo->Items->Add("���� ũ��: " + InsertComma(AFileSize) + " byte");
            lb_EngFontInfo->Items->Add("���� ����: " + IntToStr(EngFont1.CharCount));
            SetImageColsRows(img_EngFont, 32, EngFont1.CharCount / 32, 8, 16);
            DrawEngFontTable(img_EngFont->Canvas, &EngFont1);
        }
    }

    else if (IsHanFontSize(AFileSize)) {
        if (!LoadHanFont(&HanFont1, AFileName.c_str()))
            {ShowErrorMessage("�б� ����!\n\n" + AFileName); return;}
        pg_FontPreview->ActivePageIndex = 1;

        SetImageColsRows(img_HanFontF1, HanFont1.F1Count, HanFont1.F1BulCount, 16, 16);
        SetImageColsRows(img_HanFontF2, HanFont1.F2Count, HanFont1.F2BulCount, 16, 16);
        SetImageColsRows(img_HanFontF3, HanFont1.F3Count, HanFont1.F3BulCount, 16, 16);
        DrawHanFontTable(img_HanFontF1->Canvas, img_HanFontF2->Canvas, img_HanFontF3->Canvas, &HanFont1);
        img_HanFontF2->Top = img_HanFontF1->Top + img_HanFontF1->Height + 8;
        img_HanFontF3->Top = img_HanFontF2->Top + img_HanFontF2->Height + 8;

        lb_HanFontInfo->Clear();
        lb_HanFontInfo->Items->Add("���� �̸�: " + ExtractFileName(AFileName));
        lb_HanFontInfo->Items->Add("���� ũ��: " + InsertComma(AFileSize) + " byte");
        lb_HanFontInfo->Items->Add("��� ũ��: " + IntToStr(AFileSize == 13056 ? 256 : 0) + " byte");
        lb_HanFontInfo->Items->Add("���� ����: " + IntToStr(HanFont1.CharsCount));
        lb_HanFontInfo->Items->Add("�۲� ����: " +
            IntToStr(HanFont1.F1BulCount) + "��" +
            IntToStr(HanFont1.F2BulCount) + "��" +
            IntToStr(HanFont1.F3BulCount) + " ������ �ѱ�"
        );
    }

    else if (IsSpcFontSize(AFileSize)) {
        pg_FontPreview->ActivePageIndex = 2;
        if (!LoadSpcFont(&SpcFont1, AFileName.c_str()))
            {ShowErrorMessage("�б� ����!\n\n" + AFileName); return;}
        lb_SpcFontInfo->Clear();
        lb_SpcFontInfo->Items->Add("���� �̸�: " + ExtractFileName(AFileName));
        lb_SpcFontInfo->Items->Add("���� ũ��: " + InsertComma(AFileSize) + " byte");
        lb_SpcFontInfo->Items->Add("���� ����: " + IntToStr(SpcFont1.CharCount));

        DrawSpcFontTable(img_SpcFont->Canvas, &SpcFont1, spe_SpcFontPage->Value - 1);
    }

    else if (IsHanjaFontSize(AFileSize)) {
        pg_FontPreview->ActivePageIndex = 3;
        if (!LoadHanjaFont(&HanjaFont1, AFileName.c_str()))
            {ShowErrorMessage("�б� ����!\n\n" + AFileName); return;}
        lb_HanjaFontInfo->Clear();
        lb_HanjaFontInfo->Items->Add("���� �̸�: " + ExtractFileName(AFileName));
        lb_HanjaFontInfo->Items->Add("���� ũ��: " + InsertComma(AFileSize) + " byte");
        lb_HanjaFontInfo->Items->Add("���� ����: " + IntToStr(HanjaFont1.CharCount));
        DrawHanjaFontTable(img_HanjaFont->Canvas, &HanjaFont1, spe_HanjaFontPage->Value - 1);
    }

    else if (ExtractFileExt(AFileName).UpperCase() == ".BMP") {
        pg_FontPreview->ActivePageIndex = 4;
        Image1->Picture->LoadFromFile(AFileName);
        Image1->Hint = AFileName;
        pg_Char16x->Width = 1;
    }
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_EngFontMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
    int Col = X / (8 + 1);
    int Row = Y / (16 + 1);
    pg_Char16x->ActivePageIndex = 0;
    PutBitmap8x16Cell(img_EngChar16x->Canvas, 0, 0, clBlack, clWhite, EngFont1.Eng[Row * 32 + Col]);
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_HanFontF1MouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
    int Col = X / (16 + 1);
    int Row = Y / (16 + 1);
    pg_Char16x->ActivePageIndex = 1;
    PutBitmap16x16Cell(img_HanChar16x->Canvas, 0, 0, clBlack, clWhite, HanFont1.F1[Row][Col + !HanFont1.F_SKIP]);
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_HanFontF2MouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
    int Col = X / (16 + 1);
    int Row = Y / (16 + 1);
    pg_Char16x->ActivePageIndex = 1;
    PutBitmap16x16Cell(img_HanChar16x->Canvas, 0, 0, clBlack, clWhite, HanFont1.F2[Row][Col + !HanFont1.F_SKIP]);
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_HanFontF3MouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
    int Col = X / (16 + 1);
    int Row = Y / (16 + 1);
    pg_Char16x->ActivePageIndex = 1;
    PutBitmap16x16Cell(img_HanChar16x->Canvas, 0, 0, clBlack, clWhite, HanFont1.F3[Row][Col + !HanFont1.F_SKIP]);
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_SpcFontMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
    int Col = X / (16 + 1);
    int Row = Y / (16 + 1);

    if ((Row == 0) && (Col == 0)) return;
    if ((Row == 6 - 1) && (Col == 16 - 1)) return;

    pg_Char16x->ActivePageIndex = 1;
    PutBitmap16x16Cell(img_HanChar16x->Canvas, 0, 0, clBlack, clWhite,
        SpcFont1.Spc[spe_SpcFontPage->Value - 1][Row * 16 + Col - 1]);
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_HanjaFontMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
    int Col = X / (16 + 1);
    int Row = Y / (16 + 1);

    if ((Row == 0) && (Col == 0)) return;
    if ((Row == 6 - 1) && (Col == 16 - 1)) return;

    pg_Char16x->ActivePageIndex = 1;
    PutBitmap16x16Cell(img_HanChar16x->Canvas, 0, 0, clBlack, clWhite,
        HanjaFont1.Hanja[spe_HanjaFontPage->Value - 1][Row * 16 + Col - 1]);
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_SamboSpcFontMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
    int Col = X / (16 + 1);
    int Row = Y / (16 + 1);

    pg_Char16x->ActivePageIndex = 1;
    PutBitmap16x16Cell(img_HanChar16x->Canvas, 0, 0, clBlack, clWhite, SpcFont1.SamboSpc[Row * 16 + Col]);
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::spe_HanjaFontPageChange(TObject *Sender)
{
    if (!IsNumString(spe_HanjaFontPage->Text) || (spe_HanjaFontPage->Value < 1))
        {spe_HanjaFontPage->Text = "1"; return;}

    DrawHanjaFontTable(img_HanjaFont->Canvas, &HanjaFont1, spe_HanjaFontPage->Value - 1);
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::spe_SpcFontPageChange(TObject *Sender)
{
    if (!IsNumString(spe_SpcFontPage->Text) || (spe_SpcFontPage->Value < 1))
        {spe_SpcFontPage->Text = "1"; return;}

    DrawSpcFontTable(img_SpcFont->Canvas, &SpcFont1, spe_SpcFontPage->Value - 1);
}
//---------------------------------------------------------------------------
void TPreviewFrame::GetTextMetricProp(TListBox *AListBox, TFont *AFont, TTextMetric *ATextMetric)
{
    AListBox->Clear();
    AListBox->Items->Add(IntToStr(AFont->Size));
    AListBox->Items->Add(IntToStr(ATextMetric->tmHeight          ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmAscent          ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmDescent         ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmInternalLeading ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmExternalLeading ));
    /*
    AListBox->Items->Add(IntToStr(ATextMetric->tmAveCharWidth    ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmMaxCharWidth    ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmWeight          ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmOverhang        ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmDigitizedAspectX));
    AListBox->Items->Add(IntToStr(ATextMetric->tmDigitizedAspectY));
    AListBox->Items->Add(IntToStr(ATextMetric->tmFirstChar       ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmLastChar        ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmDefaultChar     ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmBreakChar       ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmItalic          ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmUnderlined      ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmStruckOut       ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmPitchAndFamily  ));
    AListBox->Items->Add(IntToStr(ATextMetric->tmCharSet         ));
    */
}
//---------------------------------------------------------------------------
void TPreviewFrame::PreviewSystemFont(TFont *AFont)
{
    pb_FontMinSize->Canvas->Font->Assign(AFont);
    pb_FontMaxSize->Canvas->Font->Assign(AFont);

    mm_MinFontTest->Font->Assign(pb_FontMinSize->Canvas->Font);
    mm_MaxFontTest->Font->Assign(pb_FontMaxSize->Canvas->Font);
}
//---------------------------------------------------------------------------
void TPreviewFrame::PreviewSystemFontMinSize(int AFontSize)
{
    pb_FontMinSize->Canvas->Font->Size = AFontSize;
    mm_MinFontTest->Font->Size = AFontSize;

    TTextMetric TextMetric1;
    GetTextMetrics(pb_FontMinSize->Canvas->Handle, &TextMetric1);
    GetTextMetricProp(lb_TextMetricMinValue, pb_FontMinSize->Canvas->Font, &TextMetric1);

    mm_MinFontTest->Lines->Add(mm_MinFontTest->Font->Name + ", " + IntToStr(AFontSize) + " Point");
}
//---------------------------------------------------------------------------
void TPreviewFrame::PreviewSystemFontMaxSize(int AFontSize)
{
    pb_FontMaxSize->Canvas->Font->Size = AFontSize;
    mm_MaxFontTest->Font->Size = AFontSize;

    TTextMetric TextMetric1;
    GetTextMetrics(pb_FontMaxSize->Canvas->Handle, &TextMetric1);
    GetTextMetricProp(lb_TextMetricMaxValue, pb_FontMaxSize->Canvas->Font, &TextMetric1);

    mm_MaxFontTest->Lines->Add(mm_MaxFontTest->Font->Name + ", " + IntToStr(AFontSize) + " Point");
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::lb_TextMetricPropClick(TObject *Sender)
{
    lb_TextMetricMinValue->ItemIndex = lb_TextMetricProp->ItemIndex;
    lb_TextMetricMaxValue->ItemIndex = lb_TextMetricProp->ItemIndex;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::ts_EngFontShow(TObject *Sender)
{
    pg_Char16x->ActivePageIndex = 0;
    pg_FontPreview->Width = img_EngFont->Left + img_EngFont->Width + 16;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::ts_HanFontShow(TObject *Sender)
{
    pg_Char16x->ActivePageIndex = 1;
    pg_FontPreview->Width = img_HanFontF3->Left + img_HanFontF3->Width + 16;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::ts_SpcFontShow(TObject *Sender)
{
    pg_Char16x->ActivePageIndex = 1;
    pg_FontPreview->Width = img_SpcFont->Left + img_SpcFont->Width + 16;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::ts_HanjaFontShow(TObject *Sender)
{
    pg_Char16x->ActivePageIndex = 1;
    pg_FontPreview->Width = img_HanjaFont->Left + img_HanjaFont->Width + 16;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::ts_SamboSpcFontShow(TObject *Sender)
{
    pg_Char16x->ActivePageIndex = 1;
    pg_FontPreview->Width = img_SamboSpcFont->Left + img_SamboSpcFont->Width + 16;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::BMP1Click(TObject *Sender)
{
    if (SavePictureDialog1->Execute()) {
        try {
            CurImage->Picture->SaveToFile(SavePictureDialog1->FileName);
        } catch (Exception& E) {
            ShowMessage(E.Message);
            return;
        }

        ShowMessage(ExtractFileName(SavePictureDialog1->FileName) + " ��Ʈ�� ������ �����Ͽ����ϴ�!");
    }
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_EngFontContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled)
{
    CurImage = img_EngFont;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_HanFontF1ContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled)
{
    CurImage = img_HanFontF1;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_HanFontF2ContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled)
{
    CurImage = img_HanFontF2;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_HanFontF3ContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled)
{
    CurImage = img_HanFontF3;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_SpcFontContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled)
{
    CurImage = img_SpcFont;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_HanjaFontContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled)
{
    CurImage = img_HanjaFont;
}
//---------------------------------------------------------------------------
void __fastcall TPreviewFrame::img_SamboSpcFontContextPopup(TObject *Sender, TPoint &MousePos, bool &Handled)
{
    CurImage = img_SamboSpcFont;
}
//---------------------------------------------------------------------------
