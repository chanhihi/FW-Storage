//---------------------------------------------------------------------------
#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Buttons.hpp>
#include <Classes.hpp>
#include <ComCtrls.hpp>
#include <Controls.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Forms.hpp>
#include <Graphics.hpp>
#include <Grids.hpp>
#include <Menus.hpp>
#include <StdCtrls.hpp>
#include <ValEdit.hpp>
#include "BrowseDr.hpp"
#include "CSPIN.h"
#include "dfsSplitter.hpp"
#include "Animate.hpp"
#include "GIFCtrl.hpp"
#include "TB2Dock.hpp"
#include "TB2ToolWindow.hpp"

#include "Fnt2BDFFrameUnit.h"
#include "Sys2BDFFrameUnit.h"
#include "PreviewFrameUnit.h"
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
    TButton *btn_PlayIMS;
    TButton *btn_StopIMS;
    TGroupBox *GroupBox1;
    TMemo *Memo2;
    TMemo *Memo3;
    TPageControl *PageControl2;
    TRxGIFAnimator *RxGIFAnimator1;
    TRxGIFAnimator *RxGIFAnimator2;
    TSplitter *Splitter1;
    TTBDock *TBDock1;
    TTBToolWindow *TBToolWindow1;
    TTabSheet *ts_About;
    TTabSheet *ts_Fnt2BDF;
    TTabSheet *ts_Sys2BDF;
    TPreviewFrame *PreviewFrame1;
    TFnt2BDFFrame *Fnt2BDFFrame1;
    TSys2BDFFrame *Sys2BDFFrame1;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall PageControl2Changing(TObject *Sender, bool &AllowChange);
    void __fastcall RxGIFAnimator1Click(TObject *Sender);
    void __fastcall RxGIFAnimator2Click(TObject *Sender);
    void __fastcall RxGIFAnimator2FrameChanged(TObject *Sender);
    void __fastcall Splitter1CanResize(TObject *Sender, int &NewSize, bool &Accept);
    void __fastcall Splitter1Moved(TObject *Sender);
    void __fastcall TBToolWindow1DockChanged(TObject *Sender);
    void __fastcall btn_PlayIMSClick(TObject *Sender);
    void __fastcall btn_StopIMSClick(TObject *Sender);
    void __fastcall lv_FileListColumnClick(TObject *Sender, TListColumn *Column);
    void __fastcall lv_FileListCompare(TObject *Sender, TListItem *Item1, TListItem *Item2, int Data, int &Compare);
    void __fastcall ts_AboutShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TMainForm(TComponent* Owner);

	String IMSFileName;
	String BNKFileName;
	TIMSFile *IMSFile1;
	TBNKFile *BNKFile1;
	bool DoPlayIMS;
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
