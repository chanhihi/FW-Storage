//---------------------------------------------------------------------------
#ifndef Fnt2BDFFrameUnitH
#define Fnt2BDFFrameUnitH
//---------------------------------------------------------------------------
#include <Buttons.hpp>
#include <Classes.hpp>
#include <ComCtrls.hpp>
#include <Controls.hpp>
#include <ExtCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
#include <StdCtrls.hpp>
#include "BrowseDr.hpp"
#include "PreviewFrameUnit.h"
//---------------------------------------------------------------------------
class TFnt2BDFFrame : public TFrame
{
__published:	// IDE-managed Components
    TBevel *Bevel1;
    TBitBtn *bitbtn_AboutBDF2BMP;
    TBitBtn *bitbtn_AboutBDF2TTF;
    TBitBtn *bitbtn_BDF2BMP;
    TBitBtn *bitbtn_BDF2TTF;
    TBitBtn *bitbtn_ConvertToBDF;
    TBitBtn *bitbtn_ConvertToBMP;
    TBitBtn *bitbtn_ConvertToTTF;
    TBitBtn *bitbtn_Help;
    TBitBtn *bitbtn_StopConverting;
    TButton *btn_AddToSrcList1;
    TButton *btn_AddToSrcList2;
    TButton *btn_DeleteSrcList1;
    TButton *btn_DeleteSrcList2;
    TButton *btn_SavePath;
    TButton *btn_SelFontPath;
    TComboBox *cbx_Encoding;
    TGroupBox *gb_SelectListType;
    TLabel *Label1;
    TLabel *Label2;
    TLabeledEdit *lbe_CurPath;
    TLabeledEdit *lbe_SavePath;
    TListView *lv_FileList;
    TListView *lv_SrcList1;
    TListView *lv_SrcList2;
    TMemo *mm_ProgressMsg;
    TMenuItem *N1;
    TMenuItem *N2;
    TMenuItem *N7;
    TMenuItem *N8;
    TMenuItem *mi_AddFontList;
    TMenuItem *mi_DeleteDefaultFontList;
    TMenuItem *mi_DeleteFontList;
    TMenuItem *mi_DeleteSourceList;
    TMenuItem *mi_PreviewFont;
    TMenuItem *mi_SelectDefaultFontListAll;
    TMenuItem *mi_SelectFileListAll;
    TMenuItem *mi_SelectSourceListAll;
    TPanel *pn_AddOrDeleteSrcList;
    TPanel *pn_FontPath;
    TPanel *pn_Options;
    TPanel *pn_SavePath;
    TPanel *pn_SrcList;
    TPopupMenu *pm_FileList;
    TPopupMenu *pm_SrcList1;
    TPopupMenu *pm_SrcList2;
    TRadioButton *rb_BDFOnly;
    TRadioButton *rb_BMPOnly;
    TRadioButton *rb_EngFontOnly;
    TRadioButton *rb_HanFontOnly;
    TRadioButton *rb_HanjaFontOnly;
    TRadioButton *rb_SpcFontOnly;
    TRadioButton *rb_TTFOnly;
    TRadioButton *rb_ViewAllFiles;
    TSpeedButton *sbtn_RefreshFileList;
    TSplitter *spl_FontList;
    TSplitter *spl_ProgressMsg;
    TSplitter *spl_SrcList;
    TdfsBrowseDirectoryDlg *dfsBrowseDirectoryDlg1;
    void __fastcall bitbtn_AboutBDF2BMPClick(TObject *Sender);
    void __fastcall bitbtn_AboutBDF2TTFClick(TObject *Sender);
    void __fastcall bitbtn_BDF2BMPClick(TObject *Sender);
    void __fastcall bitbtn_BDF2TTFClick(TObject *Sender);
    void __fastcall bitbtn_ConvertToBDFClick(TObject *Sender);
    void __fastcall bitbtn_ConvertToBMPClick(TObject *Sender);
    void __fastcall bitbtn_ConvertToTTFClick(TObject *Sender);
    void __fastcall bitbtn_HelpClick(TObject *Sender);
    void __fastcall bitbtn_StopConvertingClick(TObject *Sender);
    void __fastcall btn_AddToSrcList1Click(TObject *Sender);
    void __fastcall btn_AddToSrcList2Click(TObject *Sender);
    void __fastcall btn_DeleteSrcList1Click(TObject *Sender);
    void __fastcall btn_DeleteSrcList2Click(TObject *Sender);
    void __fastcall btn_SavePathClick(TObject *Sender);
    void __fastcall btn_SelFontPathClick(TObject *Sender);
    void __fastcall lv_FileListDblClick(TObject *Sender);
    void __fastcall lv_FileListKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
    void __fastcall lv_SrcList1DblClick(TObject *Sender);
    void __fastcall lv_SrcList1KeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
    void __fastcall lv_SrcList2DblClick(TObject *Sender);
    void __fastcall lv_SrcList2KeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
    void __fastcall mi_AddFontListClick(TObject *Sender);
    void __fastcall mi_DeleteDefaultFontListClick(TObject *Sender);
    void __fastcall mi_DeleteFontListClick(TObject *Sender);
    void __fastcall mi_DeleteSourceListClick(TObject *Sender);
    void __fastcall mi_PreviewFontClick(TObject *Sender);
    void __fastcall mi_SelectDefaultFontListAllClick(TObject *Sender);
    void __fastcall mi_SelectFileListAllClick(TObject *Sender);
    void __fastcall mi_SelectSourceListAllClick(TObject *Sender);
    void __fastcall pn_AddOrDeleteSrcListResize(TObject *Sender);
    void __fastcall sbtn_RefreshFileListClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFnt2BDFFrame(TComponent* Owner);

    TPreviewFrame *PreviewFrame1;
    TStringList *SourceList, *SourceList2;

    bool CheckEncoding(int AFontFileSize, String AEncoding);
    void AddBDFCnvtMsg(TMemo *AMemo, String AEncoding, String AOutputName, String AEngFontFileName, String AHanFontFileName, String ASpcFontFileName, String AHanjaFontFileName, int ACurIndex, int ATotalCount);
    void BitmapFontToBDF(String ATarget);
    void ConvertBDF(String ATarget);
    void DisableUserInput();
    void EnableUserInput();
    void InitPreviewFrame();
    void RefreshFileList();
};
//---------------------------------------------------------------------------
extern PACKAGE TFnt2BDFFrame *Fnt2BDFFrame;
//---------------------------------------------------------------------------
#endif
