//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "..\johab2uni\johab2uni.h"

#include "JohabToUni.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
String ConvertJohab2Uni(String AEncoding, String AOutputName,
    String AEngFontFileName, String AHanFontFileName, String ASpcFontFileName, String AHanjaFontFileName)
{
    int argvIndex;
    int result;
    char *argv[8];

    argv[0] = "johab2uni.exe";
    AEncoding = "-" + AEncoding;
    argv[1] = AEncoding.c_str();
    argv[2] = AOutputName.c_str();

    if (AEncoding == "-iso8859-1") {
        argv[3] = AEngFontFileName.c_str();
        result = johab2uni_main(4,  argv);
    } else if (AEncoding == "-johab844-1") {
        argv[3] = AHanFontFileName.c_str();
        result = johab2uni_main(4,  argv);
    } else if (AEncoding.Pos("ksc5601.1987")) {
        argv[3] = AHanFontFileName.c_str();
        argvIndex = 4;
        if (ASpcFontFileName != "") argv[argvIndex++] = ASpcFontFileName.c_str();
        if (AHanjaFontFileName != "") argv[argvIndex++] = AHanjaFontFileName.c_str();
        result = johab2uni_main(argvIndex,  argv);
    } else if (AEncoding == "-iso10646-1") {
        argvIndex = 3;
        if (AEngFontFileName != "") argv[argvIndex++] = AEngFontFileName.c_str();
        if (AHanFontFileName != "") argv[argvIndex++] = AHanFontFileName.c_str();
        if (ASpcFontFileName != "") argv[argvIndex++] = ASpcFontFileName.c_str();
        if (AHanjaFontFileName != "") argv[argvIndex++] = AHanjaFontFileName.c_str();
        result = johab2uni_main(argvIndex,  argv);
    }

    if (result == EXIT_FAILURE) return (String)_johab2uni_msg;
    return "";
}
//---------------------------------------------------------------------------
