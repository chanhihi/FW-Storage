//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "..\..\bdf2bmp06\bdf2bmp.h"

#include "BDFToBMP.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
String ConvertBDF2BMP(String ASaveBMPName, String ALoadBDFName)
{
    char *argv[3];

    argv[0] = "bdf2bmp.exe";
    argv[1] = ALoadBDFName.c_str();
    argv[2] = ASaveBMPName.c_str();

    int result = bdf2bmp_main(3, argv);
    if (result == EXIT_FAILURE) return (String)_bdf2bmp_msg;

    return "";
}
//---------------------------------------------------------------------------
