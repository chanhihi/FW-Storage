//---------------------------------------------------------------------------
#ifndef BDFToTTFH
#define BDFToTTFH
//---------------------------------------------------------------------------
typedef struct {
    String ACopyright;
    String AFontname;
    String AVersion;
    String ATrademark;
    String ACopyrightCP;
    String AFontnameCP;
    String ATrademarkCP;
} TTTFIniInfo;

String  GetBDFProperty(String ABDFFileName, String AProperty);
char    *GetFontNameFromTTF(char *AFontName, char *ATTFFileName);
String  GetTTFFontName(String ATTFFileName);
void    SaveTTFInfoFile(String ASaveFileName, TTTFIniInfo *ATTFIniInfo);
String  ConvertBDF2TTF(String ATTFFileName, String ABDFFileName);
//---------------------------------------------------------------------------
#endif
