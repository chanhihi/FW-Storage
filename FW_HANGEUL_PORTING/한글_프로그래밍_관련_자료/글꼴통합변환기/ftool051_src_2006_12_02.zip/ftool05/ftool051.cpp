//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("Main.cpp", MainForm);
USEFORM("Fnt2BDF\Fnt2BDFFrameUnit.cpp", Fnt2BDFFrame); /* TFrame: File Type */
USEFORM("Sys2BDF\Sys2BDFFrameUnit.cpp", Sys2BDFFrame); /* TFrame: File Type */
USEFORM("Preview\PreviewFrameUnit.cpp", PreviewFrame); /* TFrame: File Type */
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
         Application->Initialize();
         Application->Title = "�۲� ���� ��ȯ�� 0.51";
         Application->CreateForm(__classid(TMainForm), &MainForm);
         Application->Run();
    }
    catch (Exception &exception)
    {
         Application->ShowException(&exception);
    }
    catch (...)
    {
         try
         {
             throw Exception("");
         }
         catch (Exception &exception)
         {
             Application->ShowException(&exception);
         }
    }
    return 0;
}
//---------------------------------------------------------------------------
