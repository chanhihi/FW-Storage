//---------------------------------------------------------------------------
#include <vcl.h>
#include <ComCtrls.hpp>
#pragma hdrstop

#include "Fnt2BDFFrameUnit.h"
#include "Sys2BDFFrameUnit.h"
#include "PreviewFrameUnit.h"

#include "..\adlib32\adlib32.h"
#include "Common.h"
#include "HanOut.h"

#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma link "BrowseDr"
#pragma link "Animate"
#pragma link "GIFCtrl"
#pragma link "TB2Dock"
#pragma link "TB2ToolWindow"

#pragma link "Fnt2BDFFrameUnit"
#pragma link "Sys2BDFFrameUnit"
#pragma link "PreviewFrameUnit"
#pragma resource "*.dfm"

TMainForm *MainForm;
//---------------------------------------------------------------------------
int _SortByColumn = -1;
int _SortOrder = 1;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormCreate(TObject *Sender)
{
    PageControl2->ActivePageIndex = 0;
    // ��Ʈ�� �۲� �� BDF
    Fnt2BDFFrame1->InitPreviewFrame();
    Fnt2BDFFrame1->PreviewFrame1 = PreviewFrame1;
    Fnt2BDFFrame1->pn_AddOrDeleteSrcListResize(Sender);
    Fnt2BDFFrame1->lv_FileList->OnColumnClick = lv_FileListColumnClick;
    Fnt2BDFFrame1->lv_FileList->OnCompare = lv_FileListCompare;
    Fnt2BDFFrame1->lv_SrcList1->OnColumnClick = lv_FileListColumnClick;
    Fnt2BDFFrame1->lv_SrcList1->OnCompare = lv_FileListCompare;
    for (int i = 0; i < 4; i++) {
        TListItem *ListItem1 = Fnt2BDFFrame1->lv_SrcList2->Items->Add();
        ListItem1->Caption = "";
        ListItem1->SubItems->Add("");
        ListItem1->SubItems->Add("");
    }
    // �ý��� �۲� �� BDF
    Sys2BDFFrame1->InitPreviewFrame();
    Sys2BDFFrame1->PreviewFrame1 = PreviewFrame1;
    Sys2BDFFrame1->lv_SrcList->OnColumnClick = lv_FileListColumnClick;
    Sys2BDFFrame1->lv_SrcList->OnCompare = lv_FileListCompare;
    Sys2BDFFrame1->ChangeFont(Sys2BDFFrame1->FontDialog1->Font);
    // �̸�����
    PreviewFrame1->InitPreviewFrame();

    //--------------------------------------------------------------------------
    String IMSFileName = GetTempPathName() + "music10.ims";
    String BNKFileName = GetTempPathName() + "music10.bnk";
    DoPlayIMS = true;

    TResourceStream *ResourceStream1;
    if (!FileExists(IMSFileName)) {
        ResourceStream1 = new TResourceStream((int)HInstance, "IMSFile1", RT_RCDATA);
        ResourceStream1->SaveToFile(IMSFileName);
        delete ResourceStream1;
    }
    if (!FileExists(BNKFileName)) {
        ResourceStream1 = new TResourceStream((int)HInstance, "BNKFile1", RT_RCDATA);
        ResourceStream1->SaveToFile(BNKFileName);
        delete ResourceStream1;
    }

	if (WaveLoop_Init()) InitPlayer();
	BNKFile1 = LoadBNKFile(BNKFileName.c_str());
	IMSFile1 = LoadIMSFile(IMSFileName.c_str());
	SelectIMSBNK(IMSFile1, BNKFile1);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::lv_FileListColumnClick(TObject *Sender, TListColumn *Column)
{
    if (_SortByColumn == Column->Index) _SortOrder *= -1;  //
    else _SortOrder = 1;                                 //
    ((TListView *)Sender)->CustomSort(NULL, Column->Index);
    _SortByColumn = Column->Index;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::lv_FileListCompare(TObject *Sender, TListItem *Item1, TListItem *Item2, int Data, int &Compare)
{
    int FileSize1, FileSize2;
    String SubItem1, SubItem2;
    switch (Data) {
    case 0: // ���� �̸�
        if (Item1->Caption < Item2->Caption) Compare = -1;
        else if (Item1->Caption > Item2->Caption) Compare = 1;
        else Compare = 0;
        break;
    case 1: // ���� ũ��
        FileSize1 = RemoveComma(Item1->SubItems->Strings[0]);
        FileSize2 = RemoveComma(Item2->SubItems->Strings[0]);
        if (FileSize1 < FileSize2) Compare = -1;
        else if (FileSize1 > FileSize2) Compare = 1;
        else Compare = 0;
        break;
    default:
        SubItem1 = Item1->SubItems->Strings[Data - 1];
        SubItem2 = Item2->SubItems->Strings[Data - 1];
        if (SubItem1 < SubItem2) Compare = -1;
        else if (SubItem1 > SubItem2) Compare = 1;
        else Compare = 0;
        break;
    }
    Compare *= _SortOrder;                               //
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::PageControl2Changing(TObject *Sender, bool &AllowChange)
{
    if (_IsWorking) AllowChange = false;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormClose(TObject *Sender, TCloseAction &Action)
{
    switch (_IsWorking) {
    case true:
        ShowMessage2("��ȯ �۾��� �������Դϴ�..................!\n\n"

            "���α׷��� �����Ϸ��� ���� [�ߴ��ϱ�] ��ư�� ������\n"
            "���� �������� ��ȯ �۾��� �ߴ��Ͻñ� �ٶ��ϴ�!\n\n"

            "�� �޽����� �������� �ִ� ���ȿ��� ��ȯ �۾��� �Ͻ� �����˴ϴ�.\n"
            "����Ϸ��� OK ��ư�� �����ʽÿ�!"
        );
        Action = caNone;
        break;
    case false:
        Action = caFree;
        //
        StopPlay();
        FreeIMSFile(IMSFile1);
        FreeBNKFile(BNKFile1);
        YM3812Shutdown(ym3812p);
        WaveLoop_Release();
        break;
    }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::RxGIFAnimator2FrameChanged(TObject *Sender)
{
    if (RxGIFAnimator2->FrameIndex == 0) RxGIFAnimator2->Animate = false;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::RxGIFAnimator1Click(TObject *Sender)
{
    RxGIFAnimator1->Visible = false;
    RxGIFAnimator1->Enabled = false;
    RxGIFAnimator1->Animate = false;
    RxGIFAnimator1->SendToBack();

    RxGIFAnimator2->FrameIndex = 1;
    RxGIFAnimator2->Visible = true;
    RxGIFAnimator2->Enabled = true;
    RxGIFAnimator2->Animate = true;
    RxGIFAnimator2->BringToFront();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::RxGIFAnimator2Click(TObject *Sender)
{
    RxGIFAnimator2->Visible = false;
    RxGIFAnimator2->Enabled = false;
    RxGIFAnimator2->Animate = false;
    RxGIFAnimator2->SendToBack();

    RxGIFAnimator1->Visible = true;
    RxGIFAnimator1->Enabled = true;
    RxGIFAnimator1->Animate = true;
    RxGIFAnimator1->BringToFront();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::btn_PlayIMSClick(TObject *Sender)
{
	InitPlayer();
	ResetIMS(IMSFile1);
	StartPlay();

    RxGIFAnimator2Click(Sender);

    btn_PlayIMS->Enabled = false;
    btn_StopIMS->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::btn_StopIMSClick(TObject *Sender)
{
	StopPlay();
    RxGIFAnimator1Click(Sender);

    btn_PlayIMS->Enabled = true;
    btn_StopIMS->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ts_AboutShow(TObject *Sender)
{
    if (DoPlayIMS) {
        btn_StopIMS->Enabled = true;
        btn_PlayIMS->Enabled = false;
        btn_PlayIMSClick(Sender);

        DoPlayIMS = false;
    }
}
//---------------------------------------------------------------------------
int Splitter1Pos;
void __fastcall TMainForm::Splitter1CanResize(TObject *Sender, int &NewSize, bool &Accept)
{
    if (_IsWorking) return;
    Splitter1Pos = NewSize;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Splitter1Moved(TObject *Sender)
{
    TBToolWindow1->Width = Splitter1Pos;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TBToolWindow1DockChanged(TObject *Sender)
{
    Splitter1->Visible = TBToolWindow1->Docked;
    if (Splitter1->Visible) Splitter1->Left = TBToolWindow1->Width;

    if (TBToolWindow1->Docked) MainForm->Width += TBToolWindow1->Width;
    else MainForm->Width -= TBToolWindow1->Width;

}
//---------------------------------------------------------------------------
