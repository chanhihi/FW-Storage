//---------------------------------------------------------------------------
#ifndef BDFH
#define BDFH
//---------------------------------------------------------------------------
typedef struct {
    String Font;
    String Size_PointSize,
    	   Size_Xres,
           Size_Yres;
    String FontBoundingBox_FBBx,
    	   FontBoundingBox_FBBy,
           FontBoundingBox_Xoff,
           FontBoundingBox_Yoff;
    String Foundry;
    String Family_Name;
    String Weight_Name;
    String Slant;
    String SetWidth_Name;
    String Add_Style_Name;
    String Pixel_Size;
    String Point_Size;
    String Resolution_X;
    String Resolution_Y;
    String Spacing;
    String Average_Width;
    String CharSet_Registry;
    String CharSet_Encoding;
    String Default_Char;
    String Font_Ascent;
    String Font_Descent;
    String CharsCount;
	//--------------------------------------------------------------------------
    String FI_STARTFONT;
    String FI_FONT;
    String FI_SIZE;
    String FI_FONTBOUNDINGBOX;
    String FI_STARTPROPERTIES;
    String FI_FOUNDRY;
    String FI_FAMILY_NAME;
    String FI_WEIGHT_NAME;
    String FI_SLANT;
    String FI_SETWIDTH_NAME;
    String FI_ADD_STYLE_NAME;
    String FI_PIXEL_SIZE;
    String FI_POINT_SIZE;
    String FI_RESOLUTION_X;
    String FI_RESOLUTION_Y;
    String FI_SPACING;
    String FI_AVERAGE_WIDTH;
    String FI_CHARSET_REGISTRY;
    String FI_CHARSET_ENCODING;
    String FI_DEFAULT_CHAR;
    String FI_FONT_ASCENT;
    String FI_FONT_DESCENT;
    String FI_ENDPROPERTIES;
    String FI_CHARS;
} TBDFHeader;

extern TBDFHeader *CurBDFHeader;

bool WriteBDF_Header(String ASaveFileName, String AWriteMode, TBDFHeader *ABDFHeader);
String GetXLFD(TBDFHeader *ABDFHeader);
//---------------------------------------------------------------------------
#endif
