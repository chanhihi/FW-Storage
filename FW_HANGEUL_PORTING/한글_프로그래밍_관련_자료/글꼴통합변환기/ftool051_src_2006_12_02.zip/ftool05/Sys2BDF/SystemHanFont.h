//---------------------------------------------------------------------------
#ifndef SystemHanFontH
#define SystemHanFontH
//---------------------------------------------------------------------------
bool SysHanFontToBDF_ksc5601(String ASaveFileName, String AWriteMode, TFont *AFont, TTextMetric *ATextMetric, String AEncoding, bool ASpcFont, bool AHanFont, bool AHanjaFont);
bool SysHanFontToBDF_iso10646(String ASaveFileName, String AWriteMode, TFont *AFont, TTextMetric *ATextMetric, bool AEngFont, bool ASpcFont, bool AHanFont, bool AHanjaFont);
bool SysHanFontToBDF(String ASaveFileName, String AWriteMode, TFont *AFont, TTextMetric *ATextMetric, String AEncoding, bool AEngFont, bool ASpcFont, bool AHanFont, bool AHanjaFont);
//---------------------------------------------------------------------------
#endif
