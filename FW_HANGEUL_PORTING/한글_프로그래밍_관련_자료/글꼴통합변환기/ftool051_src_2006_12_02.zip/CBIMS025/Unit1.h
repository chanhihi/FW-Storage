//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <ValEdit.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TOpenDialog *OpenDialog1;
	TOpenDialog *OpenDialog2;
	TPageControl *PageControl1;
	TTabSheet *TabSheet1;
	TGroupBox *GroupBox2;
	TLabel *Label7;
	TLabel *BNKFileNameLabel;
	TLabel *Label9;
	TLabel *BNKFileSizeLabel;
	TValueListEditor *ValueListEditor1;
	TButton *BNKOpenButton;
	TGroupBox *GroupBox4;
	TLabel *Label11;
	TLabel *Label12;
	TLabel *IMSFileNameLabel;
	TLabel *IMSFileSizeLabel;
	TValueListEditor *ValueListEditor2;
	TButton *IMSOpenButton;
	TButton *IMSPlayButton;
	TButton *IMSStopButton;
	TTabSheet *TabSheet3;
	TMemo *Memo11;
	TTabSheet *TabSheet4;
	TGroupBox *GroupBox1;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TMemo *Memo2;
	TMemo *Memo3;
	TMemo *Memo4;
	TMemo *Memo5;
	TGroupBox *GroupBox3;
	TLabel *Label5;
	TLabel *Label6;
	TMemo *Memo1;
	TMemo *Memo6;
	TMemo *Memo7;
	TMemo *Memo8;
	TMemo *Memo9;
	TMemo *Memo10;
	TGroupBox *GroupBox5;
	TValueListEditor *ValueListEditor3;
	TButton *ROLOpenButton;
	TButton *ROLPlayButton;
	TLabel *Label8;
	TLabel *Label10;
	TLabel *ROLFileNameLabel;
	TLabel *ROLFileSizeLabel;
	TButton *ROLStopButton;
	TOpenDialog *OpenDialog3;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall BNKOpenButtonClick(TObject *Sender);
	void __fastcall IMSOpenButtonClick(TObject *Sender);
	void __fastcall IMSPlayButtonClick(TObject *Sender);
	void __fastcall IMSStopButtonClick(TObject *Sender);
	void __fastcall ROLOpenButtonClick(TObject *Sender);
	void __fastcall ROLPlayButtonClick(TObject *Sender);
	void __fastcall ROLStopButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
