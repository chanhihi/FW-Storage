//---------------------------------------------------------------------------
#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <ValEdit.hpp>
#include <ComCtrls.hpp>
#include <DBGrids.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TButton *BNKOpenButton;
	TButton *IMSOpenButton;
	TButton *IMSPlayButton;
	TButton *IMSStopButton;
	TButton *ROLOpenButton;
	TButton *ROLPlayButton;
	TButton *ROLStopButton;
	TGroupBox *GroupBox1;
	TGroupBox *GroupBox2;
	TGroupBox *GroupBox3;
	TGroupBox *GroupBox4;
	TGroupBox *GroupBox5;
	TLabel *BNKFileNameLabel;
	TLabel *BNKFileSizeLabel;
	TLabel *IMSFileNameLabel;
	TLabel *IMSFileSizeLabel;
	TLabel *Label10;
	TLabel *Label11;
	TLabel *Label12;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label6;
	TLabel *Label7;
	TLabel *Label8;
	TLabel *Label9;
	TLabel *ROLFileNameLabel;
	TLabel *ROLFileSizeLabel;
	TMemo *Memo10;
	TMemo *Memo11;
	TMemo *Memo1;
	TMemo *Memo2;
	TMemo *Memo3;
	TMemo *Memo4;
	TMemo *Memo5;
	TMemo *Memo6;
	TMemo *Memo7;
	TMemo *Memo8;
	TMemo *Memo9;
	TOpenDialog *OpenDialog1;
	TOpenDialog *OpenDialog2;
	TOpenDialog *OpenDialog3;
	TPageControl *PageControl1;
	TTabSheet *TabSheet1;
	TTabSheet *TabSheet3;
	TTabSheet *TabSheet4;
	TValueListEditor *ValueListEditor1;
	TValueListEditor *ValueListEditor2;
	TValueListEditor *ValueListEditor3;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall BNKOpenButtonClick(TObject *Sender);
	void __fastcall IMSOpenButtonClick(TObject *Sender);
	void __fastcall IMSPlayButtonClick(TObject *Sender);
	void __fastcall IMSStopButtonClick(TObject *Sender);
	void __fastcall ROLOpenButtonClick(TObject *Sender);
	void __fastcall ROLPlayButtonClick(TObject *Sender);
	void __fastcall ROLStopButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
