//---------------------------------------------------------------------------
#ifndef HanOutH
#define HanOutH
//---------------------------------------------------------------------------
#include "hanlib\hanlib.h" // �ѱ� ���̺귯�� 0.17

extern Graphics::TBitmap *EngBitmap;
extern Graphics::TBitmap *HanBitmap;

extern TEngFont *pDefEngFont;
extern THanFont *pDefHanFont;
extern TSpcFont *pDefSpcFont;
extern THanjaFont *pDefHanjaFont;

void PutBitmap8x16(TCanvas *ACanvas, int x, int y, byte *ABitmap16);
void PutBitmap16x16(TCanvas *ACanvas, int x, int y, byte *ABitmap32);
void CompleteHanChar(byte *ABuffer32, byte *AHanByte, THanFont *AHanFont);
void HanTextOut(TCanvas *ACanvas, int ALeft, int ATop, byte *s);
//---------------------------------------------------------------------------
#endif
