//---------------------------------------------------------------------------
#ifndef HanOutH
#define HanOutH
//---------------------------------------------------------------------------
#include "hanlib\hanlib.h" // �ѱ� ���̺귯�� 0.17

#define OVERWRITE   0
#define OVERLAP     1

extern Graphics::TBitmap *EngBitmap;
extern Graphics::TBitmap *HanBitmap;

extern TEngFont *pDefEngFont;
extern THanFont *pDefHanFont;
extern TSpcFont *pDefSpcFont;
extern THanjaFont *pDefHanjaFont;

void SetOutputMode(int mode);
void HanTextOut(TCanvas *ACanvas, int ALeft, int ATop, byte *s);
//---------------------------------------------------------------------------
#endif
