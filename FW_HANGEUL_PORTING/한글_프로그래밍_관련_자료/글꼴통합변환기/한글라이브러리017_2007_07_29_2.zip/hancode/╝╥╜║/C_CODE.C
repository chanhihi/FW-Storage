/*
 *      File C_CODE.C
 *      A Pointer to the Current Code-to-index Conversion Function Set
 *      '95.4.28
 *      Written by Inkeon Lim
 */


#include "hancode.h"


code_t *_code = &_code_KSSM;
