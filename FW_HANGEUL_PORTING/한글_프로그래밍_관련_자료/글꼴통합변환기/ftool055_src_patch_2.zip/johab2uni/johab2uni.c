//---------------------------------------------------------------------------
/*
	johab2uni 0.16

	Date: 2007.07.14
*/
//------------------------------------------------------------------------------
#include <stdio.h>
#include <stdarg.h>
#include "..\hanlib\hanlib.h"
#include "etc.h"
#include "fnt2bdf.h"
//------------------------------------------------------------------------------
#define OPT_ISO8859_1       0
#define OPT_JOHAB844_1      1
#define OPT_KSC5601_1987_0  2
#define OPT_KSC5601_1987_1  3
#define OPT_ISO10646_1      4

static char *_Options1[]= {
	"-e",
	"-j",
	"-k0",
	"-k1",
	"-u",
	NULL
};
static char *_Options2[] = {
	"-iso8859-1",
	"-johab844-1",
	"-ksc5601.1987-0",
	"-ksc5601.1987-1",
	"-iso10646-1", 
	NULL
};

static char *_Encoding;
static char *_Encodings[] = {
	"iso8859-1",
	"johab844-1",
	"ksc5601.1987-0",
	"ksc5601.1987-1",
	"iso10646-1", 
	NULL
};
static int _FilesSize[7] = {-1, };

static TEngFont *_pEngFont = NULL;
static THanFont *_pHanFont = NULL;
static TSpcFont *_pSpcFont = NULL;
static THanjaFont *_pHanjaFont = NULL;

static TEngFont _EngFont1;
static THanFont _HanFont1;
static TSpcFont _SpcFont1;
static THanjaFont _HanjaFont1;

static char *_EngFontFile = NULL;
static char *_HanFontFile = NULL;
static char *_SpcFontFile = NULL;
static char *_HanjaFontFile = NULL;

//---------------------------------------------------------------------------
static void print_msg(char *format, ...);
static int  GetFileSize(FILE *fp);
static int  GetOption(char *AOption);
static void GetSrcFiles(int argc, char* argv[]);
static void PrintUsage(void);
//---------------------------------------------------------------------------
char _johab2uni_msg[4096];
bool _is_johab2uni_error;

void print_msg(char *format, ...)
{
	char s[1024];

	va_list va_list1;
	va_start(va_list1, format);
	vsprintf(s, format, va_list1);
	va_end(va_list1);
#ifdef __FTOOL04__
	strcat(_johab2uni_msg, s);
#else
	printf("%s", s);
#endif
}
//---------------------------------------------------------------------------
void reset_johab2uni_vars(void)
{
	memset(_johab2uni_msg, 0, sizeof(_johab2uni_msg));

	_pEngFont = NULL;
	_pHanFont = NULL;
	_pSpcFont = NULL;
	_pHanjaFont = NULL;

	_EngFontFile = NULL;
	_HanFontFile = NULL;
	_SpcFontFile = NULL;
	_HanjaFontFile = NULL;
}
//---------------------------------------------------------------------------
int GetFileSize(FILE *fp)
{
	int curpos, length;

	curpos = ftell(fp);
	fseek(fp, 0L, SEEK_END);
	length = ftell(fp);
	fseek(fp, curpos, SEEK_SET);

	return length;
}
//---------------------------------------------------------------------------
int GetOption(char *AOption)
{
    int i;
    for (i = 0; _Options1[i] != NULL; i++) {
        if (stricmp(AOption, _Options1[i]) == 0) {
            _Encoding = _Encodings[i];
            return i;
        }
    }
    for (i = 0; _Options2[i] != NULL; i++) {
        if (stricmp(AOption, _Options2[i]) == 0) {
            _Encoding = _Encodings[i];
            return i;
        }
    }

    return -1;
}
//---------------------------------------------------------------------------
void GetSrcFiles(int argc, char* argv[])
{
    int i;

    for (i = 3; i <= argc - 1; i++) {
        FILE *fp = fopen(argv[i], "rb");
        if (fp) {
            _FilesSize[i] = GetFileSize(fp);
            fclose(fp);
        } else _FilesSize[i] = -1;   // �б� ������ ����

		if (IsEngFont(_FilesSize[i])) {
            if (!_EngFontFile) {
                _EngFontFile = argv[i];
				_pEngFont = &_EngFont1;
            }
		} else if (IsHanFont(_FilesSize[i])) {
            if (!_HanFontFile) {
                _HanFontFile = argv[i];
				_pHanFont = &_HanFont1;
            }
		} else if (IsSpcFont(_FilesSize[i])) {
            if (!_SpcFontFile) {
                _SpcFontFile = argv[i];
				_pSpcFont = &_SpcFont1;
            }
		} else if (IsHanjaFont(_FilesSize[i])) {
            if (!_HanjaFontFile) {
                _HanjaFontFile = argv[i];
				_pHanjaFont = &_HanjaFont1;
            }
        } else _FilesSize[i] = -1;   // �������� �ʴ� ������ ��Ʈ
    }

    switch (GetOption(argv[1])) {
    case OPT_ISO8859_1:
        for (i = 3; i <= argc - 1; i++)
            if (!IsEngFont(_FilesSize[i])) _FilesSize[i] = -1;
        break;
    case OPT_KSC5601_1987_0: 
    case OPT_KSC5601_1987_1:
        for (i = 3; i <= argc - 1; i++)
            if (IsEngFont(_FilesSize[i])) _FilesSize[i] = -1;
        break;
    case OPT_JOHAB844_1:
        for (i = 3; i <= argc - 1; i++)
            if (!IsHanFont(_FilesSize[i])) _FilesSize[i] = -1;
        break;
    }
}
//---------------------------------------------------------------------------
void PrintUsage(void)
{
    print_msg(
        "johab2uni 0.15 (Date: 2006-12-02)"                                            "\n"
        "Usage: johab2uni [-option] out-file.bdf engfont hanfont spcfont hanjafont"    "\n"
        "option1:"                                                                     "\n"
        "  -e    iso8859-1 Encoding"                                                   "\n"
        "        ex) johab2uni -e bdffile.bdf eng.fnt"                                 "\n"
        "  -j    johab844-1 Encoding"                                                  "\n"
        "        ex) johab2uni -j bdffile.bdf han.fnt"                                 "\n"
        "  -k0   ksc5601.1987-0 Encoding"                                              "\n"
        "        ex) johab2uni -k0 bdffile.bdf han.fnt kss1.fnt hanja.fnt"             "\n"
        "  -k1   ksc5601.1987-1 Encoding"                                              "\n"
        "        ex) johab2uni -k1 bdffile.bdf han.fnt kss1.fnt hanja.fnt"             "\n"
        "  -u    iso10646-1 Encoding (by cp949 to Unicode table 2.0)"                  "\n"
        "        ex) johab2uni -u bdffile.bdf eng.fnt han.fnt kss1.fnt hanja.fnt"      "\n"
        "engfont: 2048 / 4096 / 4112 byte"                                             "\n"
        "hanfont: 3616 / 3776 / 6176 / 11008 / 11520 / 12224 / 12800 / 13056 byte"     "\n"
        "spcfont: 36096 / 33696 byte"                                                  "\n"
        "hanjafont: 156416 byte"                                                       "\n"
    );
}
//---------------------------------------------------------------------------
void SetLength32(char *s)
{	// ���ڿ��� ���̸� 32 byte�� �ڸ���
	// ������(-) ���ڸ� ����(_) ���ڷ� ġȯ�Ѵ�.
	if (strlen(s) > 32) {
		if (ishangul1st((byte *)s, 31)) s[31] = '\0';
		else s[32] = '\0';
	}
	HyphenToUnderline(s);
}
//---------------------------------------------------------------------------
#ifdef __FTOOL04__
int johab2uni_main(int argc, char* argv[])
#else
int main(int argc, char* argv[])
#endif
{
    int i, Result;
	char BDF_Foundry[256];		// FOUNDRY
	char BDF_FamilyName[256];	// FAMILY_NAME
    char *OutputFile = argv[2];

    if ((argc < 4) || (argc > 7)) {PrintUsage(); return EXIT_FAILURE;}

	reset_johab2uni_vars();

    GetSrcFiles(argc, argv);
    switch (GetOption(argv[1])) {
    case OPT_ISO8859_1:
        if (_EngFontFile) {
            Result = LoadEngFont(_pEngFont, _EngFontFile);
            if (!Result) {print_msg("file open error: %s\n", _EngFontFile); return EXIT_FAILURE;}

			strcpy(BDF_Foundry, "8x16");
			strcpy(BDF_FamilyName, ExtractFileNameOnly(OutputFile));
            RemoveEncodingStr(BDF_FamilyName);
			SetLength32(BDF_FamilyName);
            Result = ConvertEngFontToBDF(OutputFile, "wt", _pEngFont, BDF_Foundry, BDF_FamilyName);
            if (!Result) {print_msg("file write error: %s\n", OutputFile); return EXIT_FAILURE;}
        }
        break;
    case OPT_ISO10646_1:
        if (_EngFontFile) {
            Result = LoadEngFont(_pEngFont, _EngFontFile);
            if (!Result) {print_msg("file open error: %s\n", _EngFontFile); return EXIT_FAILURE;}
        }   // break ����!
    case OPT_KSC5601_1987_0:
    case OPT_KSC5601_1987_1:
        if (_SpcFontFile) {
            Result = LoadSpcFont(_pSpcFont, _SpcFontFile);
            if (!Result) {print_msg("file open error: %s\n", _SpcFontFile); return EXIT_FAILURE;}
        }
        if (_HanjaFontFile) {
            Result = LoadHanjaFont(_pHanjaFont, _HanjaFontFile);
            if (!Result) {print_msg("file open error: %s\n", _HanjaFontFile); return EXIT_FAILURE;}
        }   // break ����!
    case OPT_JOHAB844_1:
        if (_HanFontFile) {
            Result = LoadHanFont(_pHanFont, _HanFontFile);
            if (!Result) {print_msg("file open error: %s\n", _HanFontFile); return EXIT_FAILURE;}
            // 0.53 - start
            if (_pSpcFont != NULL) {
				_pHanFont->pHangulJamo[ 2] = &(_pSpcFont->Spc[3][ 2][0]);		// '��'	(������)	: 0xA4A3
				_pHanFont->pHangulJamo[ 4] = &(_pSpcFont->Spc[3][ 4][0]);		// '��'	(������)	: 0xA4A5
				_pHanFont->pHangulJamo[ 5] = &(_pSpcFont->Spc[3][ 5][0]);		// '��'	(������)	: 0xA4A6
				_pHanFont->pHangulJamo[ 9] = &(_pSpcFont->Spc[3][ 9][0]);		// '��'	(������)	: 0xA4AA
				_pHanFont->pHangulJamo[10] = &(_pSpcFont->Spc[3][10][0]);		// '��'	(������)	: 0xA4AB
				_pHanFont->pHangulJamo[11] = &(_pSpcFont->Spc[3][11][0]);		// '��'	(������)	: 0xA4AC
				_pHanFont->pHangulJamo[12] = &(_pSpcFont->Spc[3][12][0]);		// '��'	(������)	: 0xA4AD
				_pHanFont->pHangulJamo[13] = &(_pSpcFont->Spc[3][13][0]);		// '��'	(������)	: 0xA4AE
				_pHanFont->pHangulJamo[14] = &(_pSpcFont->Spc[3][14][0]);		// '��'	(������)	: 0xA4AF
				_pHanFont->pHangulJamo[15] = &(_pSpcFont->Spc[3][15][0]);		// '��'	(������)	: 0xA4B0
				_pHanFont->pHangulJamo[19] = &(_pSpcFont->Spc[3][19][0]);		// '��'	(������)	: 0xA4B4
            }
            // 0.53 - end
       }

		strcpy(BDF_Foundry, "16x16");
		strcpy(BDF_FamilyName, ExtractFileNameOnly(OutputFile));
        RemoveEncodingStr(BDF_FamilyName);
		SetLength32(BDF_FamilyName);
        Result = ConvertHanFontToBDF(OutputFile, "wt", _Encoding, _pEngFont, _pHanFont, _pSpcFont, _pHanjaFont, BDF_Foundry, BDF_FamilyName);
        if (!Result) {print_msg("file write error: %s\n", OutputFile); return EXIT_FAILURE;}
        break;
    default:
        PrintUsage();
        return EXIT_FAILURE;
    }

    for (i = 3; i <= argc - 1; i++) {
        if (_FilesSize[i] == -1)  {
			print_msg("not supported %s encoding: %s\n", _Encoding, argv[i]);
	        return EXIT_FAILURE;
		}
	}

    return EXIT_SUCCESS;
}
//---------------------------------------------------------------------------
