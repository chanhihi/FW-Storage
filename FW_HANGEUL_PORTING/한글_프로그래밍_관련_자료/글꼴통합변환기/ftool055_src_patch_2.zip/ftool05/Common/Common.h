//---------------------------------------------------------------------------
#ifndef CommonH
#define CommonH
//---------------------------------------------------------------------------
extern char *_WriteMode[2];
extern bool _IsWorking;

#include <ComCtrls.hpp>

String	GetTempFullPathAndFileName(String APrefixString);
String	GetTempPathName(void);
bool	FileMerge_Two2One(String ADestFile, String ASrcFile1, String ASrcFile2);
bool	FileMerge_Three2One(String ADestFile, String ASrcFile1, String ASrcFile2, String ASrcFile3);
void	ShowMessage2(String AMsg);
int		ShowYesNoMsgDlg(String AMsg);
int		ShowErrorMessage(String AErrorMsg);
void	ShellExec(String AFileName);
bool	isFixedPitchFont(TTextMetric *ATextMetric);
int		RemoveComma(String AText);
String	InsertComma(int AValue);
String	ExtractFileNameOnly(String AFileName);
bool	LastCharIsPathDelimiter(String AValue);
String	AddPathDelimiter(String AValue);
bool	IsNumString(String AValue);
int		GetSelectedListCount(TListView *AListView, String AFileExt);
int		GetSelectedListItems(TStringList *AStringList, TListView *AListView, String ADirPath, String AFileExt);
void	GetFileList(TListView *AListView, String ADirPath, String AFileExt, String AFileSize);
bool	IsBitmapFontSize(int AFileSize);
String	GetFontType(int AFileSize);
void	AddCnvtMsg(TMemo *AMemo, String AOutputName, String ABDFFileName, int ACurIndex, int ATotalCount);
String	AddResultMsg(TMemo *AMemo, String ADest, String ASrc, int ACount);
String	AddErrorMsg(TMemo *AMemo, String AErrorMsg);

void    DeleteDir(AnsiString strPath);  // 0.54 �߰�
//---------------------------------------------------------------------------
#endif
