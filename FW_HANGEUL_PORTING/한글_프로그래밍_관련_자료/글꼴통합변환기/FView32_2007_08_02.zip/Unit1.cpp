//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include <dir.h>
#include "Unit1.h"
#include "HanOut.h"     // ĵ������ �ѱ� ����� ���� ���
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

TEngFont *EngFonts[500];
THanFont *HanFonts[500];
int EngFontsCount = 0;
int HanFontsCount = 0;

String EngAlphaStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz 0123456789";
String HanAlphaStr = "�����ٶ󸶹ٻ������īŸ����  �ƾ߾�����������";

int _SortByColumn = -1;
int _SortOrder = 1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    InitHan();  // �ѱ� ����� �ʱ�ȭ
    ListView1->OwnerDraw = false;

    DirectoryListBox1Change(Sender);
}
//---------------------------------------------------------------------------
void TForm1::LoadFonts()
{
    for (int i = 0; i < HanFontsCount; i++) HanFonts[i] = (THanFont *)malloc(sizeof(THanFont));
    for (int i = 0; i < EngFontsCount; i++) EngFonts[i] = (TEngFont *)malloc(sizeof(TEngFont));
    for (int i = 0; i < ListView1->Items->Count; i++) {
        String FontFile = ListView1->Items->Item[i]->Caption;
        String FontKind = ListView1->Items->Item[i]->SubItems->Strings[2];
        if (FontKind == "�ѱ�") {
            int HanFontIndex = StrToInt(ListView1->Items->Item[i]->SubItems->Strings[3]);
            LoadHanFont(HanFonts[HanFontIndex], FontFile.c_str());
        } else if (FontKind == "����") {
            int EngFontIndex = StrToInt(ListView1->Items->Item[i]->SubItems->Strings[3]);
            LoadEngFont(EngFonts[EngFontIndex], FontFile.c_str());
        }
    }
}
//---------------------------------------------------------------------------
void TForm1::FreeFonts()
{
    for (int i = 0; i < HanFontsCount; i++) free(HanFonts[i]);
    for (int i = 0; i < EngFontsCount; i++) free(EngFonts[i]);
}
//---------------------------------------------------------------------------
void TForm1::GetFileList(String ADirPath)
{
    EngFontsCount = 0;
    HanFontsCount = 0;

    String PathName;
    if (ADirPath.Length() == 3)
        PathName = ADirPath + "*.*";
    else
        PathName = ADirPath + "\\*.*";

    ListView1->Items->BeginUpdate();

    struct ffblk ffblk;
    int done = findfirst(PathName.c_str(), &ffblk, 0);
    while (!done) {
        if (IsHanFontSize(ffblk.ff_fsize)) {
            TListItem *ListItem1 = ListView1->Items->Add();
            ListItem1->Caption = ffblk.ff_name;
            ListItem1->SubItems->Add(IntToStr(ffblk.ff_fsize));
            ListItem1->SubItems->Add(HanAlphaStr);
            ListItem1->SubItems->Add("�ѱ�");                   // ����
            ListItem1->SubItems->Add(IntToStr(HanFontsCount));  // index
            HanFontsCount++;
        } else if (IsEngFontSize(ffblk.ff_fsize)) {
            if ((ffblk.ff_fsize == 4096) && (IsSamboSpcFont(ffblk.ff_name)));
            else {
                TListItem *ListItem1 = ListView1->Items->Add();
                ListItem1->Caption = ffblk.ff_name;
                ListItem1->SubItems->Add(IntToStr(ffblk.ff_fsize));
                ListItem1->SubItems->Add(EngAlphaStr);
                ListItem1->SubItems->Add("����");                   // ����
                ListItem1->SubItems->Add(IntToStr(EngFontsCount));  // index
                EngFontsCount++;
            }
        }
        done = findnext(&ffblk);
    }
    ListView1->Items->EndUpdate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ListView1DrawItem(TCustomListView *Sender,
      TListItem *Item, TRect &Rect, TOwnerDrawState State)
{
    TColor PenColor, BrushColor;

    if (State.Contains(odSelected)) {
        PenColor = clWhite;
        BrushColor = clSkyBlue;
        SetOutputMode(OVERLAP);
    } else {
        PenColor = clWindowText;
        BrushColor = clWindow;
        SetOutputMode(OVERWRITE);
   }
    Sender->Canvas->Pen->Color = PenColor;
    Sender->Canvas->Brush->Color = BrushColor;
    Sender->Canvas->FillRect(Rect);
    // �̸�
    Sender->Canvas->TextOutA(Rect.Left, Rect.Top, Item->Caption);
    // ũ��
    Rect.Left += Sender->Column[0]->Width;
    Sender->Canvas->TextOutA(Rect.Left, Rect.Top, Item->SubItems->Strings[0]);
    // �̸�����
    Rect.Left += Sender->Column[1]->Width, Rect.Left++;
    if (Item->SubItems->Strings[2] == "�ѱ�") {
        int HanFontIndex = StrToInt(Item->SubItems->Strings[3]);
        pDefHanFont = HanFonts[HanFontIndex];
        HanTextOut(Sender->Canvas, Rect.Left, Rect.Top, HanAlphaStr.SubString(1, Sender->Column[2]->Width / 16 * 2).c_str());
    } else if (Item->SubItems->Strings[2] == "����") {
        int EngFontIndex = StrToInt(Item->SubItems->Strings[3]);
        pDefEngFont = EngFonts[EngFontIndex];
        HanTextOut(Sender->Canvas, Rect.Left, Rect.Top, EngAlphaStr.SubString(1, Sender->Column[2]->Width / 8).c_str());
    }
    // ����
    Rect.Left += Sender->Column[2]->Width;
    Sender->Canvas->TextOutA(Rect.Left, Rect.Top, Item->SubItems->Strings[2]);
    // �ε���
    Rect.Left += Sender->Column[3]->Width;
    Sender->Canvas->TextOutA(Rect.Left, Rect.Top, Item->SubItems->Strings[3]);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ListView1Editing(TObject *Sender, TListItem *Item,
      bool &AllowEdit)
{
    AllowEdit = false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DirectoryListBox1Change(TObject *Sender)
{
    ListView1->Items->Clear();
    ListView1->OwnerDraw = false;
    FreeFonts();

    GetFileList(DirectoryListBox1->Directory);

    LoadFonts();
    ListView1->OwnerDraw = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
    FreeFonts();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ListView1ColumnClick(TObject *Sender,
      TListColumn *Column)
{
    if (_SortByColumn == Column->Index) _SortOrder *= -1;  
    else _SortOrder = 1;

    ((TListView *)Sender)->CustomSort(NULL, Column->Index);
    _SortByColumn = Column->Index;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ListView1Compare(TObject *Sender, TListItem *Item1,
      TListItem *Item2, int Data, int &Compare)
{
    int FileSize1, FileSize2;
    String SubItem1, SubItem2;
    switch (Data) {
    case 0: // ���� �̸�
        if (Item1->Caption < Item2->Caption) Compare = -1;
        else if (Item1->Caption > Item2->Caption) Compare = 1;
        else Compare = 0;
        break;
    case 1: // ���� ũ��
        FileSize1 = StrToInt(Item1->SubItems->Strings[0]);
        FileSize2 = StrToInt(Item2->SubItems->Strings[0]);
        if (FileSize1 < FileSize2) Compare = -1;
        else if (FileSize1 > FileSize2) Compare = 1;
        else Compare = 0;
        break;
    default:
        SubItem1 = Item1->SubItems->Strings[Data - 1];
        SubItem2 = Item2->SubItems->Strings[Data - 1];
        if (SubItem1 < SubItem2) Compare = -1;
        else if (SubItem1 > SubItem2) Compare = 1;
        else Compare = 0;
        break;
    }
    Compare *= _SortOrder;                              
}
//---------------------------------------------------------------------------

