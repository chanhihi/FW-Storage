//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include <ImgList.hpp>
#include <FileCtrl.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TDirectoryListBox *DirectoryListBox1;
    TDriveComboBox *DriveComboBox1;
    TImageList *ImageList1;
    TListView *ListView1;
    TPanel *Panel1;
    TPanel *Panel2;
    TSplitter *Splitter1;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall ListView1DrawItem(TCustomListView *Sender,
          TListItem *Item, TRect &Rect, TOwnerDrawState State);
    void __fastcall ListView1Editing(TObject *Sender, TListItem *Item,
          bool &AllowEdit);
    void __fastcall DirectoryListBox1Change(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall ListView1ColumnClick(TObject *Sender,
          TListColumn *Column);
    void __fastcall ListView1Compare(TObject *Sender, TListItem *Item1,
          TListItem *Item2, int Data, int &Compare);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
    void LoadFonts();
    void FreeFonts();
    void GetFileList(String ADirPath);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
