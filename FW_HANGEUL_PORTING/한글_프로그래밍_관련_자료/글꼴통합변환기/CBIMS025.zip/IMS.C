#include <alloc.h>
#include <stdio.h>
#include <string.h>
#include "ims.h"


//------------------------------------------------------------------------------
// ������ ������ ũ�Ⱑ IMSFILE_MAXSIZE (1MB)�� �ʰ��� ���
// �������� IMS ������ �ƴ� ���ɼ��� ���ٰ� ������.
//------------------------------------------------------------------------------
#define IMSFILE_MAXSIZE	(1024 * 1024)	// == 1MB


//------------------------------------------------------------------------------
//	���� �Լ� ����
//------------------------------------------------------------------------------
BOOL LoadFromIMSFile(TIMSFile *I);
void FreeFromIMSFile(TIMSFile *I);
BOOL LoadHeader(TIMSFile *I);
BOOL LoadSongData(TIMSFile *I);
void FreeSongData(TIMSFile *I);
void LoadUsedInstCount(TIMSFile *I);
BOOL LoadUsedInstNameList(TIMSFile *I);
void FreeUsedInstNameList(TIMSFile *I);


//------------------------------------------------------------------------------
//	�ֿ� �Լ� ����
//------------------------------------------------------------------------------
TIMSFile *LoadIMSFile(char *IMSFileName)
{
	TIMSFile *I;

	I = (TIMSFile *)malloc(sizeof(TIMSFile));
	if (I == NULL) return NULL;

	memset(I, NULL, sizeof(TIMSFile));

	strcpy(I->FileName, IMSFileName);
	if (LoadFromIMSFile(I) == FALSE) goto FAIL;

	if (LoadHeader(I) == FALSE) goto FAIL;
	if (LoadSongData(I) == FALSE) goto FAIL;
	if (LoadUsedInstNameList(I) == FALSE) goto FAIL;

SUCCESS:
	// IMS ������ �̻� ������ Ȯ���ϴ� ������ ����
//	if (CheckBNKFileSize(B) == FALSE) goto FAIL;
	return I;

FAIL:
	FreeIMSFile(I);	// �Ҵ��� �޸� �ѹ�
	return NULL;
}
//------------------------------------------------------------------------------
void FreeIMSFile(TIMSFile *I)
{
    if (I == NULL) return;

	FreeUsedInstNameList(I);
	FreeSongData(I);

	if (I->Raw != NULL) free(I->Raw);
}
//------------------------------------------------------------------------------
//	���� �Լ� ����
//------------------------------------------------------------------------------
static BOOL LoadFromIMSFile(TIMSFile *I)
{
	FILE *fp;

	fp = fopen(I->FileName, "rb");
	if (fp == NULL) return FALSE;

	fseek(fp, 0, SEEK_END);
	I->FileSize = ftell(fp);

    // IMSFILE_MAXSIZE == 1 MB
	if (I->FileSize > IMSFILE_MAXSIZE) {fclose(fp); return FALSE;}

	I->Raw = (BYTE *)malloc(I->FileSize);
	if (I->Raw == NULL) {fclose(fp); return FALSE;}

	fseek(fp, 0, SEEK_SET);
	fread((BYTE *)(I->Raw), I->FileSize, 1, fp);
	fclose(fp);

	I->RawPtr = I->Raw;	// ����

	return TRUE;
}
//------------------------------------------------------------------------------
static void FreeFromIMSFile(TIMSFile *I)
{
	if (I->Raw != NULL) free(I->Raw);
}
//------------------------------------------------------------------------------
static BOOL LoadHeader(TIMSFile *I)
{
	if (I->Raw == NULL) return FALSE;

	memcpy(&I->Header, I->RawPtr, sizeof(TIMSHeader));
    I->RawPtr += sizeof(TIMSHeader);
    I->RawPtr++;

	return TRUE;
}
//------------------------------------------------------------------------------
static BOOL LoadSongData(TIMSFile *I)
{
	if (I->SongData != NULL) return FALSE;

	I->SongData = (BYTE *)malloc(I->Header.cbDataSize);
	if (I->SongData == NULL) return FALSE;

	memcpy(I->SongData, I->RawPtr, I->Header.cbDataSize);
    I->RawPtr += I->Header.cbDataSize;

	return TRUE;
}
//------------------------------------------------------------------------------
static void FreeSongData(TIMSFile *I)
{
	if (I->SongData != NULL) free(I->SongData);
}
//------------------------------------------------------------------------------
static void LoadUsedInstCount(TIMSFile *I)
{
	WORD UsedInstrCount;

    I->RawPtr++;
    memcpy(&UsedInstrCount, I->RawPtr, sizeof(WORD));
    I->UsedInstrCount = UsedInstrCount;
    I->RawPtr += sizeof(WORD);
}
//------------------------------------------------------------------------------
static BOOL LoadUsedInstNameList(TIMSFile *I)
{
	int i;

	if (I->UsedInstrIndex != NULL) return FALSE;

	LoadUsedInstCount(I);

	I->UsedInstrIndex = (TInstrIndex *)malloc(sizeof(TInstrIndex) * I->UsedInstrCount);
	if (I->UsedInstrIndex == NULL) return FALSE;

    for (i = 0; i < I->UsedInstrCount; i++) {
	    memcpy(I->UsedInstrIndex[i].InstrName, I->RawPtr, 9);
        I->RawPtr += 9;
    }

    return TRUE;
}
//------------------------------------------------------------------------------
static void FreeUsedInstNameList(TIMSFile *I)
{
	if (I->UsedInstrIndex != NULL) free(I->UsedInstrIndex);
}
//------------------------------------------------------------------------------

