#ifndef __WAVELOOP_H_
#define __WAVELOOP_H_

#include <windows.h>
#include <mmsystem.h>

#include "datatype.h"
#include "fmopl.h"
#include "outchip.h"
#include "imsplay.h"
#include "rol.h"

#ifdef __cplusplus
extern "C" {
#endif

#define WAVE_SAMPLING_RATE		44100

extern HWAVEOUT		hWaveOut1;
extern WAVEFORMATEX	WaveFormatEx1;
extern int			RemainSamples;

BOOL WaveLoop_Init(void);
void WaveLoop_Release(void);
BOOL WaveLoop_Prepare(void);
void WaveLoop_Stop(void);
BOOL WaveLoop_IsActive(void);

BOOL PrepareNextWave(void);
void CALLBACK waveOutProc(HWAVEOUT, UINT, DWORD, DWORD, DWORD);

#ifdef __cplusplus
}
#endif

#endif	//__WAVELOOP_H_
