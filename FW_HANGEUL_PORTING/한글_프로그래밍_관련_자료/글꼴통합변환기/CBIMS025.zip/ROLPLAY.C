#include <stdio.h>
#include <string.h>

#include "rol.h"
#include "rolplay.h"
#include "player.h"
#include "waveloop.h"


//------------------------------------------------------------------------------
int TempoIndex = 0;
int NoteIndex[MAXVOICE]	  = {0, };
int InstrIndex[MAXVOICE]  = {0, };
int VolumeIndex[MAXVOICE] = {0, };
int PitchIndex[MAXVOICE]  = {0, };

int	ROLTempo = 120;		// ���� ������ (�⺻�� 120)
int CurrentTick = 0;


//------------------------------------------------------------------------------
void OnTempoEvent(void)
{
    int TimeOfEvents = _R->Tempo[TempoIndex].TimeOfEvents;
    float TempoMultiplier = _R->Tempo[TempoIndex].TempoMultiplier;

	if (TimeOfEvents == CurrentTick) {
    	ROLTempo = _R->Header.BasicTempo * TempoMultiplier;
        TempoIndex++;
    }
}
//------------------------------------------------------------------------------
void OnInstrEvent(int voice)
{
    int Index = InstrIndex[voice];
	int TimeOfEvents = _R->Voice[voice].Instr[Index].TimeOfEvents;

    if (TimeOfEvents == CurrentTick) {
        int InstDataIndex = _R->Voice[voice].InstrIndex[Index];
        int *paramArray = &_R->UsedInstData[InstDataIndex].Instrument.Op1.KeyScaleLevel;

        SetVoiceTimbre(voice, paramArray);
        InstrIndex[voice]++;
    }
}
//------------------------------------------------------------------------------
void OnPitchEvent(int voice)
{
	int Index = PitchIndex[voice];
	int TimeOfEvents = _R->Voice[voice].Pitch[Index].TimeOfEvents;

    if (TimeOfEvents == CurrentTick) {
	    float PitchVariation = _R->Voice[voice].Pitch[Index].PitchVariation;
	    SetVoicePitch(voice, PitchVariation * 0x2000);
		PitchIndex[voice]++;
    }
}
//------------------------------------------------------------------------------
void OnVolumeEvent(int voice)
{
	int Index = VolumeIndex[voice];
	int TimeOfEvents = _R->Voice[voice].Volume[Index].TimeOfEvents;

    if (TimeOfEvents == CurrentTick) {
	    float VolumeMultiplier = _R->Voice[voice].Volume[Index].VolumeMultiplier;
	    SetVoiceVolume(voice, VolumeMultiplier * 127);	// 0x7F == 127
		VolumeIndex[voice]++;
    }
}
//------------------------------------------------------------------------------
void OnNoteEvent(int voice)
{
    int Index = NoteIndex[voice];
    int NoteDuration = _R->Voice[voice].Note[Index].NoteDuration;

    if (NoteDuration == CurrentTick) {
	    int NoteNumber;

    	NoteOff(voice);
        NoteNumber = _R->Voice[voice].Note[Index].NoteNumber;
        if (NoteNumber) NoteOn(voice, NoteNumber);
        NoteIndex[voice]++;
    }
}
//------------------------------------------------------------------------------
void RewindROL(void)
{
	TempoIndex = 0;
	memset(NoteIndex,	0, sizeof(int) * MAXVOICE);
	memset(InstrIndex,	0, sizeof(int) * MAXVOICE);
	memset(VolumeIndex, 0, sizeof(int) * MAXVOICE);
	memset(PitchIndex,	0, sizeof(int) * MAXVOICE);
	CurrentTick = 0;
	ROLTempo = _R->Header.BasicTempo;
}
//------------------------------------------------------------------------------
int OnROLPlayEvent(void)
{
    int i, TickDelay;

    if (TempoIndex < _R->TempoCount) OnTempoEvent();
	for (i = 0; i < _R->VoiceCount; i++) {
		if (InstrIndex[i] < _R->Voice[i].InstrCount) OnInstrEvent(i);
		if (PitchIndex[i] < _R->Voice[i].PitchCount) OnPitchEvent(i);
		if (VolumeIndex[i] < _R->Voice[i].VolumeCount) OnVolumeEvent(i);
        if (CurrentTick < _R->Voice[i].TimeOfLastNote) OnNoteEvent(i);
    	else NoteOff(i);
    }

    TickDelay = 240 / _R->Header.TicksPerBeat;
    CurrentTick++;

    if (CurrentTick >= _R->TimeOfLastNote) RewindROL();
	return TickDelay;
}
//------------------------------------------------------------------------------
void LoadUsedInstData(TROLFile *R, TBNKFile *B)
{
	int i, diff;
    BYTE *p, *raw;

    raw = B->Raw;

    for (i = 0; i < R->UsedInstCount; i++) {
        char *tempptr1 = R->UsedInstData[i].InstName;
        int *tempptr2 = &R->UsedInstData[i].Instrument.InstType;
        int searchTop = 0;
        int searchBottom = B->Header.nUsedEntry - 1;
        int searchMiddle = searchBottom >> 1;
        do {
			char InstName[8 + 1];
            p = raw + B->Header.nRecSeekPos + (searchMiddle * 12) + 3;
            strcpy(InstName, p);
            p += 9;
            diff = stricmp(tempptr1, InstName);
            if (diff != 0) {
                if (diff < 0) searchBottom = searchMiddle - 1;
                else searchTop = searchMiddle + 1;
                searchMiddle = (searchTop + searchBottom) >> 1;
            }
        } while (diff && searchTop <= searchBottom);

        if (diff == 0) {
        	short tempOffset1;
		    int j, tempOffset2;
            p = raw + B->Header.nRecSeekPos + (searchMiddle * 12);
            memcpy(&tempOffset1, p, sizeof(short));
            p += sizeof(short);

            tempOffset2 = tempOffset1;
            p = raw + B->Header.nDataSeekPos + (tempOffset2 * 30);
            for (j = 0; j < 30; j++) *(tempptr2++) = *(p++);
        }
    }
}
//------------------------------------------------------------------------------
BOOL SelectROLBNK(TROLFile *ROLFile, TBNKFile *BNKFile)
{
    if (ROLFile == NULL) return FALSE;

    LoadUsedInstData(ROLFile, BNKFile);
	ROLFile->BNKFile = BNKFile;

	return TRUE;
}
//------------------------------------------------------------------------------
BOOL ResetROL(TROLFile *ROLFile)
{
	int i;

    if (ROLFile == NULL) return FALSE;
    else CurrentROLFile = ROLFile;

	YM3812ResetChip(ym3812p);

	SndOutput(1, 0x20);		// Enable waveform select (bit 5)
    SetMode(!_R->Header.SoundMode);

    for (i = 0; i < _R->VoiceCount; i++) {
    	SetVoiceVolume(i, 0);
        NoteOff(i);
    }

    RewindROL();

    PLAY_MODE = ROL_MODE;
    return TRUE;
}
//------------------------------------------------------------------------------

