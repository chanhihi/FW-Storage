#include <stdio.h>
#include "player.h"
#include "rolplay.h"
#include "imsplay.h"
#include "outchip.h"
#include "fmopl.h"
#include "waveloop.h"

TPLAY_MODE PLAY_MODE = NONE_PLAY_MODE;

TROLFile *CurrentROLFile = NULL;
TIMSFile *CurrentIMSFile = NULL;

//------------------------------------------------------------------------------
void InitPlayer(void)
{
    // 3579545��� ��ġ�� SETFREQ.C ������ �����ϼ���
	ym3812p = YM3812Init(3579545L, WAVE_SAMPLING_RATE);

	SoundWarmInit();
}
//------------------------------------------------------------------------------
void ResetPlayer(void)
{
	switch (PLAY_MODE) {
    case ROL_MODE: ResetROL(CurrentROLFile); break;
    case IMS_MODE: ResetIMS(CurrentIMSFile); break;
    }
}
//------------------------------------------------------------------------------
BOOL StartPlay(void)
{
	if ((CurrentROLFile == NULL) && (CurrentIMSFile == NULL)) return FALSE;

	if (WaveLoop_IsActive()) return FALSE;
	if (WaveLoop_Prepare() == FALSE) return FALSE;

	RemainSamples = 0;

	PrepareNextWave();
	PrepareNextWave();
	waveOutRestart(hWaveOut1);

    return TRUE;
}
//------------------------------------------------------------------------------
void StopPlay(void)
{
	if (PLAY_MODE == NONE_PLAY_MODE) return;

	WaveLoop_Stop();
    ResetPlayer();

	PLAY_MODE = NONE_PLAY_MODE;
}
//------------------------------------------------------------------------------

