//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include "main.h"

#include "bnk.h"
#include "rol.h"
#include "ims.h"
#include "rolplay.h"
#include "imsplay.h"
#include "player.h"
#include "rplay11.h"
#include "waveloop.h"
#include "outchip.h"
#include "fmopl.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

TBNKFile *BNKFile1 = NULL;
TIMSFile *IMSFile1 = NULL;
TROLFile *ROLFile1 = NULL;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
	if (WaveLoop_Init()) InitPlayer();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
	StopPlay();

	FreeROLFile(ROLFile1);
	FreeIMSFile(IMSFile1);
	FreeBNKFile(BNKFile1);

	YM3812Shutdown(ym3812p);
	WaveLoop_Release();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BNKOpenButtonClick(TObject *Sender)
{
	if (WaveLoop_IsActive()) {
		ShowMessage("IMS ���� �߿��� BNK ������ �� �� �����ϴ�!");
		return;
	}

	if (OpenDialog1->Execute()) {
		FreeBNKFile(BNKFile1);
		BNKFile1 = LoadBNKFile(OpenDialog1->FileName.c_str());

		if (IMSFile1 != NULL) {
			FreeIMSFile(IMSFile1);
			IMSFile1 = LoadIMSFile(OpenDialog2->FileName.c_str());
	        SelectIMSBNK(IMSFile1, BNKFile1);
        }

		BNKFileNameLabel->Caption = ExtractFileName(OpenDialog1->FileName);
		BNKFileSizeLabel->Caption = IntToStr(BNKFile1->FileSize) + " byte";

		ValueListEditor1->Strings->Clear();
		ValueListEditor1->Strings->Add("BYTE  nVerMajor;="		+ IntToStr(BNKFile1->Header.nVerMajor)	+ " (0x" + IntToHex(BNKFile1->Header.nVerMajor, 2) + ")");
		ValueListEditor1->Strings->Add("BYTE  nVerMinor;="		+ IntToStr(BNKFile1->Header.nVerMinor)	+ " (0x" + IntToHex(BNKFile1->Header.nVerMinor, 2) + ")");
		ValueListEditor1->Strings->Add("char  signature[6];="	+ AnsiString(BNKFile1->Header.signature).SubString(1, 6));
		ValueListEditor1->Strings->Add("WORD  nUsedEntry;="		+ IntToStr(BNKFile1->Header.nUsedEntry)	+ " (0x" + IntToHex(BNKFile1->Header.nUsedEntry, 4) + ")");
		ValueListEditor1->Strings->Add("WORD  nTotalEntry;="	+ IntToStr(BNKFile1->Header.nTotalEntry)	+ " (0x" + IntToHex(BNKFile1->Header.nTotalEntry, 4) + ")");
		ValueListEditor1->Strings->Add("DWORD nRecSeekPos;="	+ IntToStr(BNKFile1->Header.nRecSeekPos)	+ " (0x" + IntToHex((int)BNKFile1->Header.nRecSeekPos, 8) + ")");
		ValueListEditor1->Strings->Add("DWORD nDataSeekPos;="	+ IntToStr(BNKFile1->Header.nDataSeekPos)	+ " (0x" + IntToHex((int)BNKFile1->Header.nDataSeekPos, 8) + ")");
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IMSOpenButtonClick(TObject *Sender)
{
	if (!BNKFile1) {ShowMessage("BNK ������ �����ϼ���!"); return;}

	if (OpenDialog2->Execute()) {
		FreeIMSFile(IMSFile1);
		IMSFile1 = LoadIMSFile(OpenDialog2->FileName.c_str());
		// IMS �Ǵ� BNK ������ ���� �о��� �� �ݵ�� �Ʒ� �Լ��� ȣ���Ѵ�.
        // IMS ���Ͽ��� ����� BNK ������ �����ϰ� IMS ���Ͽ��� �����
        // �Ǳⵥ������ �ε����� BNK ���Ͽ��� �˻��ؼ� �����Ѵ�.
        SelectIMSBNK(IMSFile1, BNKFile1);

		IMSFileNameLabel->Caption = ExtractFileName(OpenDialog2->FileName);
		IMSFileSizeLabel->Caption = IntToStr(IMSFile1->FileSize) + " byte";

		ValueListEditor2->Strings->Clear();
		ValueListEditor2->Strings->Add("BYTE nVerMajor;="		+ IntToStr(IMSFile1->Header.nVerMajor)	+ " (0x" + IntToHex(IMSFile1->Header.nVerMajor,    2) + ")");
		ValueListEditor2->Strings->Add("BYTE nVerMinor;="		+ IntToStr(IMSFile1->Header.nVerMinor)	+ " (0x" + IntToHex(IMSFile1->Header.nVerMinor,    2) + ")");
		ValueListEditor2->Strings->Add("int  nTuneID;="			+ IntToStr(IMSFile1->Header.nTuneID)		+ " (0x" + IntToHex((int)IMSFile1->Header.nTuneID, 8) + ")");
		ValueListEditor2->Strings->Add("char szTuneName[30];="	+ AnsiString(IMSFile1->Header.szTuneName).SubString(1, 30));
		ValueListEditor2->Strings->Add("BYTE nTickBeat;="		+ IntToStr(IMSFile1->Header.nTickBeat)	+ " (0x" + IntToHex(IMSFile1->Header.nTickBeat,       2) + ")");
		ValueListEditor2->Strings->Add("BYTE nBeatMeasure;="	+ IntToStr(IMSFile1->Header.nBeatMeasure)	+ " (0x" + IntToHex(IMSFile1->Header.nBeatMeasure,    2) + ")");
		ValueListEditor2->Strings->Add("int  nTotalTick;="		+ IntToStr(IMSFile1->Header.nTotalTick)	+ " (0x" + IntToHex((int)IMSFile1->Header.nTotalTick, 8) + ")");
		ValueListEditor2->Strings->Add("int  cbDataSize;="		+ IntToStr(IMSFile1->Header.cbDataSize)	+ " (0x" + IntToHex((int)IMSFile1->Header.cbDataSize, 8) + ")");
		ValueListEditor2->Strings->Add("int  nrCommand;="		+ IntToStr(IMSFile1->Header.nrCommand)	+ " (0x" + IntToHex((int)IMSFile1->Header.nrCommand,  8) + ")");
		ValueListEditor2->Strings->Add("BYTE nSrcTickBeat;="	+ IntToStr(IMSFile1->Header.nSrcTickBeat)	+ " (0x" + IntToHex(IMSFile1->Header.nSrcTickBeat,    2) + ")");
		ValueListEditor2->Strings->Add("char filler[7];="		+ AnsiString(IMSFile1->Header.filler).SubString(1, 7));
		ValueListEditor2->Strings->Add("BYTE nSoundMode;="		+ IntToStr(IMSFile1->Header.nSoundMode)	+ " (0x" + IntToHex(IMSFile1->Header.nSoundMode,   2) + ")");
		ValueListEditor2->Strings->Add("BYTE nPitchBRange;="	+ IntToStr(IMSFile1->Header.nPitchBRange)	+ " (0x" + IntToHex(IMSFile1->Header.nPitchBRange, 2) + ")");
		ValueListEditor2->Strings->Add("WORD nBasicTempo;="		+ IntToStr(IMSFile1->Header.nBasicTempo)	+ " (0x" + IntToHex(IMSFile1->Header.nBasicTempo,  4) + ")");
		ValueListEditor2->Strings->Add("char filler2[8];="		+ AnsiString(IMSFile1->Header.filler2).SubString(1, 8));

        if (PLAY_MODE == NONE_PLAY_MODE)
		    IMSPlayButton->Enabled = true;
        else
		    IMSPlayButton->Enabled = false;
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IMSPlayButtonClick(TObject *Sender)
{
	if (!BNKFile1) {ShowMessage("BNK ������ �����ϼ���!"); return;}
	if (!IMSFile1) {ShowMessage("IMS ������ �����ϼ���!"); return;}

	IMSStopButton->Enabled = true;
    IMSOpenButton->Enabled = false;
    IMSPlayButton->Enabled = false;

    ROLPlayButton->Enabled = false;

	InitPlayer();
	ResetIMS(IMSFile1);

	StartPlay();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IMSStopButtonClick(TObject *Sender)
{
	if (!BNKFile1) {ShowMessage("BNK ������ �����ϼ���!"); return;}
	if (!IMSFile1) {ShowMessage("IMS ������ �����ϼ���!"); return;}

	StopPlay();

	IMSStopButton->Enabled = false;
	IMSPlayButton->Enabled = true;
    IMSOpenButton->Enabled = true;

	if (ROLFile1)
	    ROLPlayButton->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ROLOpenButtonClick(TObject *Sender)
{
	if (!BNKFile1) {ShowMessage("BNK ������ ������ �ֽʽÿ�!"); return;}

	if (OpenDialog3->Execute()) {
		FreeROLFile(ROLFile1);
		ROLFile1 = LoadROLFile(OpenDialog3->FileName.c_str());
		if (ROLFile1 == NULL) {
			ShowMessage(ExtractFileName(OpenDialog3->FileName)
            + " ������ �д� �� ������ �߻��Ͽ����ϴ�!");
			return;
		}

		ROLFileNameLabel->Caption = ExtractFileName(OpenDialog3->FileName);
		ROLFileSizeLabel->Caption = IntToStr(ROLFile1->FileSize) + " byte";

		ValueListEditor3->Strings->Clear();
		ValueListEditor3->Strings->Add("WORD FileVersion_Major;="	+	IntToStr(ROLFile1->Header.FileVersion_Major));
		ValueListEditor3->Strings->Add("WORD FileVersion_Minor;="	+	IntToStr(ROLFile1->Header.FileVersion_Minor));
		ValueListEditor3->Strings->Add("char Filler1[40];="			+	AnsiString(ROLFile1->Header.Filler1).SubString(1, 40));
		ValueListEditor3->Strings->Add("WORD TicksPerBeat;="		+	IntToStr(ROLFile1->Header.TicksPerBeat));
		ValueListEditor3->Strings->Add("WORD BeatsPerMeasure;="		+	IntToStr(ROLFile1->Header.BeatsPerMeasure));
		ValueListEditor3->Strings->Add("WORD Editing_Scale_Y;="		+	IntToStr(ROLFile1->Header.Editing_Scale_Y));
		ValueListEditor3->Strings->Add("WORD Editing_Scale_X;="		+	IntToStr(ROLFile1->Header.Editing_Scale_X));
		ValueListEditor3->Strings->Add("char Filler2;="				+	IntToStr(ROLFile1->Header.Filler2));
		ValueListEditor3->Strings->Add("char SoundMode;="			+	IntToStr(ROLFile1->Header.SoundMode));
		ValueListEditor3->Strings->Add("char Filler3[90];="			+	AnsiString(ROLFile1->Header.Filler3).SubString(1, 90));
		ValueListEditor3->Strings->Add("char Filler4[38];="			+	AnsiString(ROLFile1->Header.Filler4).SubString(1, 38));
		ValueListEditor3->Strings->Add("char Filler5[15];="			+	AnsiString(ROLFile1->Header.Filler5).SubString(1, 15));
		ValueListEditor3->Strings->Add("float BasicTempo;="			+	FloatToStr(ROLFile1->Header.BasicTempo));

        if (PLAY_MODE == NONE_PLAY_MODE)
		    ROLPlayButton->Enabled = true;
        else
		    ROLPlayButton->Enabled = false;
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ROLPlayButtonClick(TObject *Sender)
{
	if (!BNKFile1) {ShowMessage("BNK ������ �����ϼ���!"); return;}
	if (!ROLFile1) {ShowMessage("ROL ������ �����ϼ���!"); return;}

	ROLStopButton->Enabled = true;
    ROLOpenButton->Enabled = false;
    ROLPlayButton->Enabled = false;

    IMSPlayButton->Enabled = false;

	InitPlayer();
	ResetROL(ROLFile1);
    SelectROLBNK(ROLFile1, BNKFile1);

    StartPlay();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ROLStopButtonClick(TObject *Sender)
{
	if (!BNKFile1) {ShowMessage("BNK ������ �����ϼ���!"); return;}
	if (!ROLFile1) {ShowMessage("ROL ������ �����ϼ���!"); return;}

	StopPlay();

	ROLStopButton->Enabled = false;
	ROLPlayButton->Enabled = true;
    ROLOpenButton->Enabled = true;

	if (IMSFile1)
	    IMSPlayButton->Enabled = true;
}
//---------------------------------------------------------------------------




