#include <alloc.h>
#include <stdio.h>
#include <string.h>
#include "bnk.h"


//------------------------------------------------------------------------------
// ������ ������ ũ�Ⱑ BNKFILE_MAXSIZE (1MB)�� �ʰ��� ���
// �������� BNK ������ �ƴ� ���ɼ��� ���ٰ� ������.
//------------------------------------------------------------------------------
#define BNKFILE_MAXSIZE	(1024 * 1024)	// == 1MB


//------------------------------------------------------------------------------
//	���� �Լ� ����
//------------------------------------------------------------------------------
BOOL LoadFromBNKFile(TBNKFile *B);
void FreeFromBNKFile(TBNKFile *B);
BOOL LoadBNKHeader(TBNKFile *B);
BOOL LoadBNKNameRecord(TBNKFile *B);
void FreeBNKNameRecord(TBNKFile *B);
BOOL LoadBNKInstRecord(TBNKFile *B);
void FreeBNKInstRecord(TBNKFile *B);
BOOL LoadBNKInstRecord32(TBNKFile *B);
void FreeBNKInstRecord32(TBNKFile *B);


//------------------------------------------------------------------------------
//	�ֿ� �Լ� ����
//------------------------------------------------------------------------------
TBNKFile *LoadBNKFile(char *BNKFileName)
{
	TBNKFile *B;

	B = (TBNKFile *)malloc(sizeof(TBNKFile));
	if (B == NULL) return NULL;

	memset(B, NULL, sizeof(TBNKFile));

	strcpy(B->FileName, BNKFileName);
	if (LoadFromBNKFile(B) == FALSE) goto FAIL;

	if (LoadBNKHeader(B) == FALSE) goto FAIL;
	if (LoadBNKNameRecord(B) == FALSE) goto FAIL;
	if (LoadBNKInstRecord(B) == FALSE) goto FAIL;
	if (LoadBNKInstRecord32(B) == FALSE) goto FAIL;

	return B;

FAIL:
	FreeBNKFile(B);	// �Ҵ��� �޸� �ѹ�
	return NULL;
}
//------------------------------------------------------------------------------
void FreeBNKFile(TBNKFile *B)
{
    if (B == 0) return;

	FreeBNKInstRecord32(B);
	FreeBNKInstRecord(B);
	FreeBNKNameRecord(B);

	if (B->Raw != NULL) free(B->Raw);

	memset(B, NULL, sizeof(TBNKFile));
	free(B);
}
//------------------------------------------------------------------------------
//	���� �Լ� ����
//------------------------------------------------------------------------------
BOOL LoadFromBNKFile(TBNKFile *B)
{
	FILE *fp;

	fp = fopen(B->FileName, "rb");
	if (fp == NULL) return FALSE;

	fseek(fp, 0, SEEK_END);
	B->FileSize = ftell(fp);
    // BNKFILE_MAXSIZE == 1 MB
	if (B->FileSize > BNKFILE_MAXSIZE) {fclose(fp); return FALSE;}

	B->Raw = (BYTE *)malloc(B->FileSize);
	if (B->Raw == NULL) {fclose(fp); return FALSE;}

	fseek(fp, 0, SEEK_SET);
	fread((BYTE *)(B->Raw), B->FileSize, 1, fp);
	fclose(fp);

	return TRUE;
}
//------------------------------------------------------------------------------
void FreeFromBNKFile(TBNKFile *B)
{
	if (B->Raw != NULL) free(B->Raw);
}
//------------------------------------------------------------------------------
BOOL LoadBNKHeader(TBNKFile *B)
{
	char signature[6 + 1];

	memcpy(&B->Header, B->Raw, sizeof(TBNKHeader));
    strncpy(signature, B->Header.signature, 6);
    signature[6] = NULL;

	if (stricmp(signature, "ADLIB-") != EQUAL_STRING) return FALSE;

	return TRUE;
}
//------------------------------------------------------------------------------
BOOL LoadBNKNameRecord(TBNKFile *B)
{
	if (B->NameRecord != NULL) return FALSE;

	B->NameRecordSize = sizeof(TBNKNameRecord) * B->Header.nTotalEntry;
	B->NameRecord = (TBNKNameRecord *)malloc(B->NameRecordSize);
	if (B->NameRecord == NULL) return FALSE;

	memcpy(B->NameRecord, B->Raw + B->Header.nRecSeekPos, B->NameRecordSize);

	return TRUE;
}
//------------------------------------------------------------------------------
void FreeBNKNameRecord(TBNKFile *B)
{
	if (B->NameRecord != NULL) free(B->NameRecord);
}
//------------------------------------------------------------------------------
BOOL LoadBNKInstRecord(TBNKFile *B)
{
	if (B->InstRecord != NULL) return FALSE;

	B->InstRecordSize = sizeof(TBNKInstRecord) * B->Header.nTotalEntry;
	B->InstRecord = (TBNKInstRecord *)malloc(B->InstRecordSize);
	if (B->InstRecord == NULL) return FALSE;

	memcpy(B->InstRecord, B->Raw + B->Header.nDataSeekPos, B->InstRecordSize);

	return TRUE;
}
//------------------------------------------------------------------------------
void FreeBNKInstRecord(TBNKFile *B)
{
	if (B->InstRecord != NULL) free(B->InstRecord);
}
//------------------------------------------------------------------------------
BOOL LoadBNKInstRecord32(TBNKFile *B)
{
	int i;

	if (B->InstRecord32 != NULL) return FALSE;

	B->InstRecordSize32 = sizeof(TBNKInstRecord32) * B->Header.nTotalEntry;
	B->InstRecord32 = (TBNKInstRecord32 *)malloc(B->InstRecordSize32);
	if (B->InstRecord32 == NULL) return FALSE;

	for (i = 0; i < B->Header.nTotalEntry; i++) {
		B->InstRecord32[i].InstType			  	= B->InstRecord[i].InstType;
		B->InstRecord32[i].VoiceNum			  	= B->InstRecord[i].VoiceNum;
		B->InstRecord32[i].Op1.KeyScaleLevel    = B->InstRecord[i].Op1.KeyScaleLevel;
		B->InstRecord32[i].Op1.FreqMultiplier   = B->InstRecord[i].Op1.FreqMultiplier;
		B->InstRecord32[i].Op1.Feedback         = B->InstRecord[i].Op1.Feedback;
		B->InstRecord32[i].Op1.AttackRate       = B->InstRecord[i].Op1.AttackRate;
		B->InstRecord32[i].Op1.SustainLevel     = B->InstRecord[i].Op1.SustainLevel;
		B->InstRecord32[i].Op1.SustainSound     = B->InstRecord[i].Op1.SustainSound;
		B->InstRecord32[i].Op1.DecayRate        = B->InstRecord[i].Op1.DecayRate;
		B->InstRecord32[i].Op1.ReleaseRate      = B->InstRecord[i].Op1.ReleaseRate;
		B->InstRecord32[i].Op1.OutputLevel      = B->InstRecord[i].Op1.OutputLevel;
		B->InstRecord32[i].Op1.AmplitudeVibrato = B->InstRecord[i].Op1.AmplitudeVibrato;
		B->InstRecord32[i].Op1.FreqVibrato      = B->InstRecord[i].Op1.FreqVibrato;
		B->InstRecord32[i].Op1.EnvelopeScale    = B->InstRecord[i].Op1.EnvelopeScale;
		B->InstRecord32[i].Op1.FmType           = B->InstRecord[i].Op1.FmType;
		B->InstRecord32[i].Op2.KeyScaleLevel    = B->InstRecord[i].Op2.KeyScaleLevel;
		B->InstRecord32[i].Op2.FreqMultiplier   = B->InstRecord[i].Op2.FreqMultiplier;
		B->InstRecord32[i].Op2.Feedback         = B->InstRecord[i].Op2.Feedback;
		B->InstRecord32[i].Op2.AttackRate       = B->InstRecord[i].Op2.AttackRate;
		B->InstRecord32[i].Op2.SustainLevel     = B->InstRecord[i].Op2.SustainLevel;
		B->InstRecord32[i].Op2.SustainSound     = B->InstRecord[i].Op2.SustainSound;
		B->InstRecord32[i].Op2.DecayRate        = B->InstRecord[i].Op2.DecayRate;
		B->InstRecord32[i].Op2.ReleaseRate      = B->InstRecord[i].Op2.ReleaseRate;
		B->InstRecord32[i].Op2.OutputLevel      = B->InstRecord[i].Op2.OutputLevel;
		B->InstRecord32[i].Op2.AmplitudeVibrato = B->InstRecord[i].Op2.AmplitudeVibrato;
		B->InstRecord32[i].Op2.FreqVibrato      = B->InstRecord[i].Op2.FreqVibrato;
		B->InstRecord32[i].Op2.EnvelopeScale    = B->InstRecord[i].Op2.EnvelopeScale;
		B->InstRecord32[i].Op2.FmType           = B->InstRecord[i].Op2.FmType;
		B->InstRecord32[i].Op1WaveForm		  	= B->InstRecord[i].Op1WaveForm;
		B->InstRecord32[i].Op2WaveForm		  	= B->InstRecord[i].Op2WaveForm;
	}

	return TRUE;
}
//------------------------------------------------------------------------------
void FreeBNKInstRecord32(TBNKFile *B)
{
	if (B->InstRecord32 != NULL) free(B->InstRecord32);
}
//------------------------------------------------------------------------------

