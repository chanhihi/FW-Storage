gcc fnt2ksc.c libboree/*.o -Ilibboree -Wall -o fnt2ksc
strip fnt2ksc
