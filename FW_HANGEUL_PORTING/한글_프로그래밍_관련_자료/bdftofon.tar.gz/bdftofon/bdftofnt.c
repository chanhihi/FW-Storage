/* bdftofnt.c
 * Copyright (C) Angus J. C. Duggan, 1995-1999
 * Convert X11 BDF font to MicroSoft .fnt format for inclusion in .fon file
 */

#undef VGA_RESOLUTION
#define EXTRA_GLYPH
#undef FACE_PART_NAME

#pragma pack(1)
#include <windows.h>

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <ctype.h>
#include <fcntl.h>
#include <io.h>
#include "fontinfo.h"

/* Define windows font versions */
#define WINDOWS_2	0x200
#define WINDOWS_3_0	0x300
#define WINDOWS_3_1	0x30a

static int verbose = 1 ;
static char *program ;

static void usage(void)
{
  fprintf(stderr,
          "Copyright (C) Angus J. C. Duggan 1995-1999.\n"
          "Usage: %s [-q] [-c] [infile [outfile]]\n"
          "\n"
          "Options:\n"
          " -q\t\tQuiet; do not print progress (not currently used)\n"
          " -c\t\tForce OEM (console) character set\n"
          "\n"
          "Files:\n"
          " infile\t\tName of input BDF file (stdin if none)\n"
          " outfile\tName of output FNT file (stdout if none)\n"
          "\n"
          "Source code is available from ftp.dcs.ed.ac.uk:/pub/ajcd/bdftofon.tar.gz and\n"
          "ftp.tardis.ed.ac.uk:/users/ajcd/bdftofon.tar.gz\n",
          program);
  fflush(stderr);
  exit(1);
}

#define MAX_LINE 512

typedef struct {
  int xvec, yvec ;
  int bbox[4] ;
  int size ;
  unsigned char *bitmap ;
} FontChar ;

typedef struct {
  char *name ;
  char *xlfd[14] ;
  int bbox[4] ;
  int ascent ;
  int descent ;
  int defaultch ;
  int firstch ;
  int lastch ;
  int nchars ;
  int thischar ;
  int bmwidth ;
  FontChar *chars[256] ;
} Font ;

static void *xalloc(size_t num, size_t size)
{
  void *mem ;

  if ( (mem = calloc(num, size)) == (void *)0 ) {
    fprintf(stderr, "%s: memory exhausted\n", program);
    fflush(stderr);
    exit(1);
  }
  return mem ;
}

static Font *newfont(void)
{
  Font *fnt = (Font *)xalloc(1, sizeof(Font)) ;

  fnt->ascent = -1 ;
  fnt->descent = -1 ;
  fnt->defaultch = -1 ;
  fnt->thischar = -1 ;
  fnt->lastch = -1 ;
  fnt->firstch = 256 ;
  fnt->nchars = 0 ;

  return fnt ;
}

int bdfignore(char *line, FILE *in, Font *fnt)
{
  return 1 ;
}

int bdffontbb(char *line, FILE *in, Font *fnt)
{
  return sscanf(line, "%d %d %d %d\n", &(fnt->bbox[0]),
		&(fnt->bbox[1]), &(fnt->bbox[2]), &(fnt->bbox[3])) == 4 ;
}

int bdffont(char *line, FILE *in, Font *fnt)
{
  char name[MAX_LINE] ;

  if ( sscanf(line, "%s\n", name) != 1 )
    return 0 ;

  if ( ! fnt->name ) {
    fnt->name = (char *)xalloc(strlen(line) + 1, sizeof(char)) ;
    strcpy(fnt->name, name) ;
  }

  if ( name[0] == '-' ) {	/* split out parts of XLFD */
    int index = 0 ;
    char *start = name ;
    char *end = start ;

    do {
      ++start ;
      do {
	++end ;
      } while ( *end && *end != '-' ) ;
      fnt->xlfd[index] = (char *)xalloc(end - start + 1, sizeof(char)) ;
      strncpy(fnt->xlfd[index], start, end - start) ;
      fnt->xlfd[index][end - start] = '\0' ;
      start = end ;
    } while ( *end && ++index < 14 ) ;
  }

  return 1 ;
}

int bdfascent(char *line, FILE *in, Font *fnt)
{
  return sscanf(line, "%d\n", &(fnt->ascent)) == 1 ;
}

int bdfdescent(char *line, FILE *in, Font *fnt)
{
  return sscanf(line, "%d\n", &(fnt->descent)) == 1 ;
}

int bdfdefault(char *line, FILE *in, Font *fnt)
{
  return sscanf(line, "%d\n", &(fnt->defaultch)) == 1 ;
}

int bdfnchars(char *line, FILE *in, Font *fnt)
{
  return sscanf(line, "%d\n", &(fnt->nchars)) == 1 ;
}

int bdfencode(char *line, FILE *in, Font *fnt)
{
  int thischar ;

  if ( sscanf(line, "%d\n", &thischar) != 1 )
    return 0 ;

  fnt->thischar = thischar ;
  if ( thischar > fnt->lastch )
    fnt->lastch = thischar ;
  if ( thischar < fnt->firstch )
    fnt->firstch = thischar ;

  fnt->chars[thischar] = (FontChar *)xalloc(1, sizeof(FontChar)) ;

  return 1 ;
}

int bdfwidth(char *line, FILE *in, Font *fnt)
{
  FontChar *ch ;

  if ( fnt->thischar < 0 || (ch = fnt->chars[fnt->thischar]) == (FontChar *)0 )
    return 0 ;

  return sscanf(line, "%d %d\n", &(ch->xvec), &(ch->yvec)) == 2 ;
}

int bdfcharbb(char *line, FILE *in, Font *fnt)
{
  FontChar *ch ;
  int result ;

  if ( fnt->thischar < 0 || (ch = fnt->chars[fnt->thischar]) == (FontChar *)0 )
    return 0 ;

  result = (sscanf(line, "%d %d %d %d\n", &(ch->bbox[0]), &(ch->bbox[1]),
		   &(ch->bbox[2]), &(ch->bbox[3])) == 4) ;

  if ( result ) {
    if ( ch->bbox[0] > fnt->bbox[0] )
      fnt->bbox[0] = ch->bbox[0] ;
    if ( ch->bbox[1] > fnt->bbox[1] )
      fnt->bbox[1] = ch->bbox[1] ;
  }

  return result ;
}

int bdfbitmap(char *line, FILE *in, Font *fnt)
{
  FontChar *ch ;
  int bmwidth, bmheight ;
  unsigned char *bitmap, *row ;
  char buf[MAX_LINE] ;

  if ( fnt->thischar < 0 || (ch = fnt->chars[fnt->thischar]) == (FontChar *)0 )
    return 0 ;

  bmwidth = (ch->bbox[0] + 7) >> 3 ;
  bmheight = ch->bbox[1] ;

  if ( bmwidth > fnt->bmwidth )
    fnt->bmwidth = bmwidth ;
  ch->size = bmwidth * bmheight ;
  bitmap = (unsigned char *)xalloc(ch->size, sizeof(unsigned char)) ;

  row = bitmap ;
  while ( bmheight-- ) {
    char *hex = buf ;
    int nbytes = bmwidth ;
    unsigned char *col = row ;

    if ( ! fgets(buf, MAX_LINE, in) )
      return 0 ;

    while ( nbytes-- ) {
      int byte ;

      switch ( *hex ) {
      case ' ': case '\t':
	break ;
      case '0': case '1': case '2': case '3': case '4':
      case '5': case '6': case '7': case '8': case '9':
	byte = *hex - '0' ;
	break ;
      case 'a': case 'b': case 'c': case 'd': case 'e': case 'f':
	byte = *hex - 'a' + 10 ;
	break ;
      case 'A': case 'B': case 'C': case 'D': case 'E': case 'F':
	byte = *hex - 'A' + 10 ;
	break ;
      default:
	return 0 ;
      }
      hex++ ;
      byte <<= 4 ;
      switch ( *hex ) {
      case ' ': case '\t':
	break ;
      case '0': case '1': case '2': case '3': case '4':
      case '5': case '6': case '7': case '8': case '9':
	byte |= *hex - '0' ;
	break ;
      case 'a': case 'b': case 'c': case 'd': case 'e': case 'f':
	byte |= *hex - 'a' + 10 ;
	break ;
      case 'A': case 'B': case 'C': case 'D': case 'E': case 'F':
	byte |= *hex - 'A' + 10 ;
	break ;
      default:
	return 0 ;
      }
      hex++ ;
      *col = byte ;
      col += ch->bbox[1] ;	/* Next column */
    }
    row++ ; /* Next row */
  }

  ch->bitmap = bitmap ;

  return 1 ;
}

struct {
  char *name ;
  int (*function)(char *, FILE *, Font *) ;
} dispatch[] = {
  { "STARTFONT", bdfignore },
  { "FONT", bdffont },
  { "SIZE", bdfignore },
  { "FONTBOUNDINGBOX", bdffontbb },
  { "STARTPROPERTIES", bdfignore },
  { "FONT_ASCENT", bdfascent },
  { "FONT_DESCENT", bdfdescent },
  { "DEFAULT_CHAR", bdfdefault },
  { "ENDPROPERTIES", bdfignore },
  { "CHARS", bdfnchars },
  { "ENDPROPERTIES", bdfignore },
  { "STARTCHAR", bdfignore },
  { "ENCODING", bdfencode },
  { "SWIDTH", bdfignore },
  { "DWIDTH", bdfwidth },
  { "BBX", bdfcharbb },
  { "BITMAP", bdfbitmap },
  { "ENDCHAR", bdfignore },
  { "ENDFONT", bdfignore },
  { (char *)0, bdfignore },
} ;

int readbdf(FILE *in, Font *fnt)
{
  static char line[MAX_LINE] ;
  while ( fgets(line, MAX_LINE, in) ) {
    int index, len ;
    char *eow ;

    for ( eow = line; *eow && ! isspace(*eow) ; eow++ ) ;
    len = eow - line ;

    for ( index = 0 ; dispatch[index].name ; index++ ) {
      if ( strlen(dispatch[index].name) == len &&
	   strncmp(dispatch[index].name, line, len) == 0 ) {
	if ( ! (*(dispatch[index].function))(eow, in, fnt) ) {
	  fprintf(stderr, "%s: can't parse line %s\n", program, line);
	  fflush(stderr);
	  exit(1);
	}
	break ;
      }
    }
    
  }
  return 1 ;
}

struct writefntopt {
  int oem ;	/* Force oem charset? */
} ;

int writefnt(FILE *out, Font *fnt, int version, char *name, struct writefntopt *options)
{
  FONTFILEHEADER *fhead = (FONTFILEHEADER *)xalloc(1, sizeof(FONTFILEHEADER)) ;
  FONTINFO *finfo = &(fhead->dffi) ;
  int defaultch = fnt->defaultch ;
  long rastersz = 0 ;
  long headersz = 0 ;
  long tablesz = 0 ;
  char *xlfd ;
  int maxwidth = 0 ;
  int avgwidth = 0 ;
  int totwidth = 0 ;
  int samewidth = 1 ;
  int index ;

  if ( defaultch < 0 )
    fnt->defaultch = defaultch = fnt->firstch ;

  if ( defaultch < 0 )	/* No characters! */
    return 0 ;
  
  rastersz = fnt->chars[defaultch]->size ;

  /* Fill in gaps from first to last character, and calculate raster size */
  fnt->nchars = fnt->lastch - fnt->firstch + 1 ;
  for ( index = fnt->firstch ; index <= fnt->lastch ; index++ ) {
    FontChar *ch = fnt->chars[index] ;
    int width ;
    if ( ch == (FontChar *)0 )
      ch = fnt->chars[index] = fnt->chars[defaultch] ;
    rastersz += ch->size ;
    width = ch->bbox[0] ;
    if ( totwidth == 0 )
      maxwidth = totwidth = width ;
    else {
      totwidth += width ;
      if ( width > maxwidth ) {
	maxwidth = width ;
	samewidth = 0 ;
      } else if ( width < maxwidth )
	samewidth = 0 ;
    }
  }
  avgwidth = totwidth / fnt->nchars ;

  if ( ! samewidth )	/* Can't deal width variable width fonts yet */
    return 0 ;

#ifdef FACE_PART_NAME
  {
    int len = 0 ;

    for ( index = 1 ; index <= 6 ; index++ )
      len += (fnt->xlfd[index] && *(fnt->xlfd[index])) ?
	strlen(fnt->xlfd[index]) + 1 : 0 ;

    name = xalloc(len, 1) ;

    len = 0 ;
    for ( index = 1 ; index <= 6 ; index++ )
      if ( fnt->xlfd[index] && *(fnt->xlfd[index]) ) {
	if ( len != 0 )
	  name[len++] = '-' ;

	strcpy(name + len, fnt->xlfd[index]) ;
	len += strlen(fnt->xlfd[index]) ;
      }
  }
#else

  if ( name == NULL && fnt->xlfd[1] && *(fnt->xlfd[1]) ) 
    name = fnt->xlfd[1] ;

  if ( name == NULL )
    name = "UNKNOWN" ;

#endif

  if ( version == WINDOWS_2 ) {
    /* Older fonts have smaller header and different table sizes */
    headersz = (char *)&(finfo->dfFlags) - (char *)fhead;
    tablesz = (fnt->nchars + 1) * sizeof(RASTERGLYPHENTRY) ;
  } else { /* Windows 3.1 fonts */
    headersz = sizeof(FONTFILEHEADER) ;
    tablesz = fnt->nchars * sizeof(RASTERGLYPHENTRY3) ;
#ifdef EXTRA_GLYPH
    tablesz += sizeof(RASTERGLYPHENTRY3) ;
#endif
  }

  fhead->dfVersion = version ;
  fhead->dfSize = headersz + tablesz + rastersz +
    strlen(name) + 1 ; /* size of entire file in bytes */
  strcpy(fhead->dfCopyright, "Created by bdftofon, (C) AJCD 1995") ;

  finfo->dfType = PF_RASTER_TYPE ;
  finfo->dfPoints = fnt->xlfd[6] ? atoi(fnt->xlfd[6]) : fnt->ascent ;	/* well, it's near enough */
#ifdef VGA_RESOLUTION
  finfo->dfVertRes = 96 ;		/* Standard VGA */
  finfo->dfHorizRes = 96 ;		/* Standard VGA */
#else
  finfo->dfVertRes = fnt->xlfd[8] ? atoi(fnt->xlfd[8]) : fnt->xlfd[9] ? atoi(fnt->xlfd[9]) : 96 ;
  finfo->dfHorizRes = fnt->xlfd[9] ? atoi(fnt->xlfd[9]) : fnt->xlfd[8] ? atoi(fnt->xlfd[8]) : 96 ;
#endif
  finfo->dfAscent = fnt->bbox[1] + fnt->bbox[3] + 1 ;
  finfo->dfInternalLeading = 1 ;
  finfo->dfExternalLeading = 0 ;
  finfo->dfItalic = (xlfd = fnt->xlfd[3]) &&
    (strcmp(xlfd, "i") == 0 || strcmp(xlfd, "o") == 0) ;
  finfo->dfUnderline = 0 ;
  finfo->dfStrikeOut = 0 ;
  finfo->dfWeight = (xlfd = fnt->xlfd[2]) ?
    (strcmp(xlfd, "medium") == 0 ? 400 :
     strcmp(xlfd, "bold") == 0 ? 700 :
     strcmp(xlfd, "light") == 0 ? 200 : 400) : 400 ;
  finfo->dfCharSet = !options->oem &&
    (xlfd = fnt->xlfd[12]) && strcmp(xlfd, "iso8859") == 0 ?
    DF_CHARSET_ANSI : DF_CHARSET_OEM ;
  finfo->dfPixWidth = samewidth ? maxwidth : 0 ;
  finfo->dfPixHeight = fnt->bbox[1] ;
  finfo->dfPitchAndFamily = samewidth ? FF_MODERN : (FF_ROMAN | FF_VARIABLE) ;
  finfo->dfAvgWidth = avgwidth ;
  finfo->dfMaxWidth = maxwidth ;
  finfo->dfFirstChar = fnt->firstch ;
  finfo->dfLastChar = fnt->lastch ;
  finfo->dfDefaultChar = fnt->defaultch ;
  finfo->dfBreakChar = 0 ;	/* relative to firstchar */
  finfo->dfWidthBytes = fnt->bmwidth ;
  finfo->dfDevice = (long)NULL ;
  finfo->dfFace = headersz + tablesz + rastersz ; /* offset to face name */
  finfo->dfBitsPointer = (long)NULL ;
  finfo->dfBitsOffset = headersz + tablesz ;	/* offset to bitmap */
  if ( version != WINDOWS_2 )
    finfo->dfFlags = samewidth ? FSF_FIXED : FSF_PROPORTIONAL ;

  /* write font header struct */
  if ( fwrite((void *)fhead, headersz, 1, out) < 1 )
    return 0 ;

  /* char width table */
  if ( version == WINDOWS_2 ) {
    short offset = (short)(headersz + tablesz) ;
    RASTERGLYPHENTRY glyph ;

    for ( index = fnt->firstch ; index <= fnt->lastch ; index++ ) {
      FontChar *ch = fnt->chars[index] ;

      glyph.rgeWidth = ch->bbox[0] ;
      glyph.rgeOffset = offset ;

      if ( fwrite((void *)&glyph, sizeof(RASTERGLYPHENTRY), 1, out) < 1 )
	return 0 ;

      offset += ch->size ;
    }

    glyph.rgeWidth = fnt->chars[defaultch]->bbox[0] ;
    glyph.rgeOffset = offset ;
    if ( fwrite((void *)&glyph, sizeof(RASTERGLYPHENTRY), 1, out) < 1 )
      return 0 ;
  } else {
    long offset = headersz + tablesz ;
    RASTERGLYPHENTRY3 glyph ;

    for ( index = fnt->firstch ; index <= fnt->lastch ; index++ ) {
      FontChar *ch = fnt->chars[index] ;

      glyph.rgeWidth = ch->bbox[0] ;
      glyph.rgeOffset = offset ;

      if ( fwrite((void *)&glyph, sizeof(RASTERGLYPHENTRY3), 1, out) < 1 )
	return 0 ;

      offset += ch->size ;
    }

#ifdef EXTRA_GLYPH
    glyph.rgeWidth = fnt->chars[defaultch]->bbox[0] ;
    glyph.rgeOffset = offset ;
    if ( fwrite((void *)&glyph, sizeof(RASTERGLYPHENTRY3), 1, out) < 1 )
      return 0 ;
#endif
  }

  /* write bitmap data */
  for ( index = fnt->firstch ; index <= fnt->lastch ; index++ ) {
    FontChar *ch = fnt->chars[index] ;

    if ( fwrite((void *)ch->bitmap, ch->size, 1, out) < 1 )
      return 0 ;
  }

  /* Write default char */
#ifndef EXTRA_GLYPH
  if ( version == WINDOWS_2 )
#endif
  {
    FontChar *ch = fnt->chars[defaultch] ;

    if ( fwrite((void *)ch->bitmap, ch->size, 1, out) < 1 )
      return 0 ;
  }

  /* write face name */
  if ( fwrite((void *)name, strlen(name) + 1, 1, out) < 1 )
    return 0 ;

  (void)free(fhead) ;

  return 1 ;
}

void main(int argc, char *argv[])
{
  FILE *infile = stdin;
  FILE *outfile = stdout;
  Font *thisfont = newfont() ;
  char *name = NULL ;
  int version = WINDOWS_3_0 ;
  struct writefntopt woptions = { 0 } ;

  for (program = *argv++ ; --argc ; argv++) {
    if (argv[0][0] == '-') {
      switch (argv[0][1]) {
      case 'q':	/* quiet */
	verbose = 0;
	break;
      case 'c':	/* OEM (console) charset */
	woptions.oem = 1 ;
	break;
      case '2':	/* windows 2.0 */
	if ( argv[0][2] == '\0' && strcmp(argv[0], "-2.0") == 0 )
	  version = WINDOWS_2 ;
	else
	  usage() ;
	break;
      case '3':	/* windows 3.0 */
	if ( argv[0][2] == '\0' || strcmp(argv[0], "-3.0") == 0 )
	  version = WINDOWS_3_0 ;
	else if ( strcmp(argv[0], "-3.1") == 0 )
	  version = WINDOWS_3_1 ;
	else
	  usage() ;
	break;
      default:
	usage();
      }
    } else if (infile == stdin) {
      if ((infile = fopen(*argv, "r")) == NULL) {
	fprintf(stderr, "%s: can't open input file %s\n", program, *argv);
	fflush(stderr);
	exit(1);
      }
    } else if (outfile == stdout) {
      if ((outfile = fopen(*argv, "wb")) == NULL) {
	fprintf(stderr, "%s: can't open output file %s\n", program, *argv);
	fflush(stderr);
	exit(1);
      }
    } else if (name == NULL) {
      name = *argv ;
    } else usage();
  }
  if ( outfile == stdout ) {
    int fd = fileno(stdout) ;
    if ( setmode(fd, O_BINARY) < 0 ) {
      fprintf(stderr, "%s: can't reset stdout to binary mode\n", program);
      exit(1);
    }
  }

  if ( ! readbdf(infile, thisfont) ) {
    fprintf(stderr, "%s: problem reading BDF font file\n", program);
    exit(1);
  }

  if ( ! writefnt(outfile, thisfont, version, name, &woptions) ) {
    fprintf(stderr, "%s: problem writing FON font file\n", program);
    exit(1);
  }

  fclose(stdin) ;
  fclose(stdout) ;
}

