/* Windows font info structures; can't find these in source tree */

typedef struct tagFONTINFO {
    short dfType;
    short dfPoints;
    short dfVertRes;
    short dfHorizRes;
    short dfAscent;
    short dfInternalLeading;
    short dfExternalLeading;
    char  dfItalic;
    char  dfUnderline;
    char  dfStrikeOut;
    short dfWeight;
    char  dfCharSet;
    short dfPixWidth;
    short dfPixHeight;
    char  dfPitchAndFamily;
    short dfAvgWidth;
    short dfMaxWidth;
    char  dfFirstChar;
    char  dfLastChar;
    char  dfDefaultChar;
    char  dfBreakChar;
    short dfWidthBytes;
    long  dfDevice;
    long  dfFace;
    long  dfBitsPointer;
    long  dfBitsOffset;
    char  dfReserved;
    /* The following fields present only for Windows 3.x fonts */
    long  dfFlags;
    short dfAspace;
    short dfBspace;
    short dfCspace;
    long  dfColorPointer;
    long  dfReserved1[4];
} FONTINFO;

#define PF_RASTER_TYPE (0x0000)
#define PF_VECTOR_TYPE (0x0001)
#define PF_BITS_IS_ADDRESS (0x0004)
#define PF_DEVICE_REALIZED (0x0080)

#define DF_CHARSET_ANSI 0
#define DF_CHARSET_SYMBOL 2
#define DF_CHARSET_OEM 255

#define FF_VARIABLE 0x01
#define FF_ROMAN (0x10)
#define FF_SWISS (0x20)
#define FF_MODERN (0x30)
#define FF_SCRIPT (0x40)
#define FF_DECORATIVE (0x50)

#define FSF_FIXED (0x0001)
#define FSF_PROPORTIONAL (0x0002)
#define FSF_ABCFIXED (0x0004)
#define FSF_ABCPROPORTIONAL (0x0008)
#define FSF_1COLOR (0x0010)
#define FSF_16COLOR (0x0020)
#define FSF_256COLOR (0x0040)
#define FSF_RGBCOLOR (0x0080)

typedef struct tagVECTORGLYPHENTRY {
    short rgeOffset;   /* offset to vectors relative to segment start */
    short rgeWidth;    /* width of character in pixels */
} VECTORGLYPHENTRY;

typedef struct tagFONTFILEHEADER {
    short dfVersion;
    long  dfSize;
    char  dfCopyright[60];
    FONTINFO dffi;
} FONTFILEHEADER;

typedef struct tabRASTERGLYPHENTRY {
  short rgeWidth;
  short rgeOffset;
} RASTERGLYPHENTRY ;

typedef struct tabRASTERGLYPHENTRY3 {
  short rgeWidth;
  long rgeOffset;
} RASTERGLYPHENTRY3 ;
