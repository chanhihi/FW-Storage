#!/usr/local/bin/perl

$font = 1 ;
print "\#include <windows.h>\n" ;

foreach (@ARGV) {
   print $font++, " FONT $_\n" if /.*\.fnt$/ ;
}
